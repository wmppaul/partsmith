from pathlib import Path
import json,hashlib,shutil,tarfile,io
r=Path.cwd();w=r/'.build/mendelssohn-complete-2026-10-03';d=r/'Tests/quality_control/mendelssohn-complete-workflow-2026-10-03';d.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
val=json.load(open(w/'validation.json'));m=json.load(open(w/'final-parts/manifest.json'));truth=json.load(open(w/'source-map.json'))
foreign={
 'soprano':{},
 'alto':{67:'Small fragments of upper Soprano lyrics remain above the staff.',74:'Faint upper-voice fragments remain.'},
 'tenor':{67:'Small upper-voice lyric fragments remain.',89:'Faint upper-voice fragments remain.'},
 'bass':{16:'A small Organ slur fragment remains below the lyrics.',23:'An Organ slur fragment remains below the lyrics.',37:'Small upper Alto lyric fragments remain.',45:'Upper Alto lyrics and a lower Organ slur fragment remain.',52:'A substantial upper Alto lyric line remains.',59:'Upper Alto lyric fragments remain.',67:'High Organ slur and beam fragments overlap the Bass lyric range; lower Organ staff/notes removed by the reviewed edge.',89:'Upper Tenor lyric fragments remain.'},
 'organ':{16:'Clipped Bass lyrics remain above the upper manual.',23:'Bass lyric line remains above the upper manual.',30:'Faint Bass lyric fragments remain.',45:'Bass lyric line remains.',52:'Faint Bass lyric fragments remain.',59:'Faint Bass lyric fragments remain.',67:'Bass lyric line and a separate Bass slur remain above the Organ; own bar68 slur is complete after repair.',74:'Faint Bass lyric fragments remain.',82:'Faint Bass lyric fragments remain.',89:'Faint Bass lyric fragments remain.',96:'Bass lyric line remains above the upper manual.'}}
rows=[]
for p in m['parts']:
 for b in p['placements']:
  rest=b.get('generatedRest');rows.append({'id':b['id'],'part':p['id'],'sourcePage':b['sourcePage'],'system':b['system'],'outputPage':b['outputPage'],'bars':[b['startBarNumber'],b['startBarNumber']+b['barCount']-1],'originalBandReferences':b['sourceBandIDs'],'kind':b['kind'],'targetPreservation':'Source-confirmed absent duration retained; no printed staff replaced.' if rest else 'No remaining target omission observed in original-source versus final-output review.','neighboringNotation':'None; generated rest.' if rest else foreign[p['id']].get(b['startBarNumber'],'No material foreign notation observed beyond source structural bracket/line continuation.'),'readability':'Printed source notation at native consistent scale; no output page clipping/overlap observed.' if not rest else 'Native counted-rest symbol and starting-bar label visible.'})
review={'scope':'All six original source pages and all eight final native PDF pages visually compared; all49 printed music rows and four rendered rest groups reviewed. This is a source-based visual judgment, not automatic note recognition or a claim of perfectly clean extraction.','sourceSHA256':m['sourceSHA256'],'manifestSHA256':h(w/'final-parts/manifest.json'),'sourceCropObligationsSHA256':h(w/'source-obligations.json'),'manualCorrectionsSHA256':h(w/'manual-corrections.json'),'rows':rows,'pageTurns':{'soprano':'One page; no turn.','alto':'One page; no turn.','tenor':'One page; no turn.','bass':'51→52 crosses a continuing vocal phrase; unresolved.','organ':'29→30 and 66→67 occur during continuous playing; unresolved.'},'nativeBehaviorLimit':'Manual instrument/system initialization, source-count confirmation, verified direction copies and three crop corrections were required. No claim of unattended Auto completion.'}
write(w/'final-review.json',review)
for name in ['input-bindings.json','production-source-hashes.json','source-obligations.json','manual-corrections.json','validation.json','baseline-review.json','final-review.json','final-render-index.json','render-index.json','reviewed-overrides.json','final-overrides.json','profile.json','source-map.json','export.log','final-export.log','build-final.log']:
 shutil.copy2(w/name,d/name)
archive=d/'native-workflow-evidence.tar.gz';members={}
paths=[]
for sub in ['Core','source-review','crop-review','output-review','final-output-review']:
 paths +=[(p, str(p.relative_to(w))) for p in sorted((w/sub).rglob('*')) if p.is_file()]
for rid in ['p1-s1-bass','p4-s2-bass','p4-s2-organ']:paths.append((w/'final-crop-review'/(rid+'.png'),'final-crop-review/'+rid+'.png'))
for p in (w/'parts').glob('*.pdf'):paths.append((p,'initial-parts/'+p.name))
paths += [(w/'parts/manifest.json','initial-parts/manifest.json'),(w/'parts/plan.json','initial-parts/plan.json')]
for p in (w/'parts').glob('*.partsmithproject/project.json'):paths.append((p,'initial-parts/'+str(p.relative_to(w/'parts'))))
for n in ['export.swift','initial-export.swift','prepare_review.py','render_review.py','render_final_review.py','prepare_final.py','validate_final.py','freeze_report.py','inventory.json','andante-source-context.png']:
 paths.append((w/n,n))
for p in sorted((r/'.build/variable-layout-output-audit-2026-10-03/mendelssohn-source').glob('*.png')):paths.append((p,'original-source/'+p.name))
with tarfile.open(archive,'w:gz') as tar:
 for p,n in paths:
  data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mtime=0;tar.addfile(info,io.BytesIO(data));members[n]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(members)
 for n,v in members.items():assert hashlib.sha256(tar.extractfile(n).read()).hexdigest()==v['sha256']
write(d/'archive-members.json',members)
(d/'README.md').write_text('''# Complete Mendelssohn native draft

All six original pages of *Verleih uns Frieden gnädiglich*, the Benjamin Righetti choir-and-organ arrangement (CPDL63797), are represented in five editable native parts. The complete source has **14 systems, 77 physical staves and bars 1–102**. Source SHA256: `e5d9e40c209ccae77ea2a610e81db5e3435df3a848da47b51bb644a72b710706`.

This is **assisted initialization and review**, not unattended Auto success. The existing production native inventory was reused without another detector or matcher run. Original labels, braces, aligned measure anchors and the previously frozen full source map establish all identities and bar counts. The Organ always retains both manuals and pedal; separate choir and Organ brackets are one physical system. Current native `ScoreDetectionReview`, `addScoreParts`, generated-rest editing, layout and PDF export produced the result. No production source was changed.

| Part | Original item references | Final rendered rows | Pages | Joined absent passage |
|---|---:|---:|---:|---|
| Soprano | 14 | 7 | 1 | Bars 8–66: 59 bars |
| Alto | 14 | 11 | 1 | Bars 8–36: 29 bars |
| Tenor | 14 | 7 | 1 | Bars 8–66: 59 bars |
| Bass | 14 | 14 | 2 | Bars 8–15: 8 bars |
| Organ | 14 | 14 | 3 | None |

The document retains **49 original music rows and 21 original generated-rest records**, all 70 references exactly once and in source order. Native joining renders those as 49 music rows and four rest groups. Every part’s timeline is continuous from 1 through 102. The printed seven-bar opening staves, their 3/4 meter, later lead-in rests and final printed rests remain original-source crops. No meter or tempo change occurs inside the joined absence spans.

Opening Andante is already printed for Soprano and Organ. Only Alto, Tenor and Bass receive the verified original source word `[126,329,162,342]`; all three copies are complete. Remaining lyrics, vocal dynamics and Organ registrations are kept in their own source strips.

The initial native export had one observed target loss: Organ physical page 4/system 2 (bar 68) clipped the crest of an upper-manual slur. The original filled cubic path establishes its actual top at approximately 582.57 pt including stroke. The reviewed top is 581.4 pt. Two further source-reviewed Bass bottom edges remove the duplicate Organ Andante beneath its first staff and reduce excess Organ material beneath the bar 67 lyrics. `manual-corrections.json` freezes all three changes and independent local source obligations before the final render. All other 46 music rectangles and all three copied source rectangles remain unchanged.

All six full original pages, all 11 initial pages and all 8 final pages were viewed. The final slur is complete; the two Bass cuts retain full target notes and lyric descenders. No remaining target omission was observed. An independent reviewer also inspected the full source and final outputs; its separate receipt is linked when finalized. Neighboring lyrics, slur and beam fragments still remain, especially in Bass and Organ. The Bass bar 67 crop cannot remove every high Organ fragment with a horizontal cut while keeping the Bass lyric line. This is a preservation draft, not a clean extraction or performance-ready edition.

Soprano, Alto and Tenor now need no page turn. Bass still turns at 51→52 across a continuing vocal phrase; Organ turns at 29→30 and 66→67 during continuous playing. Those turns remain unresolved.

Validation verifies all identities, every original reference, all five 102-bar timelines, source embedding, PDF page counts/hashes, the three changed crops, complete tempo copies, page containment and all 25 frozen production Core hashes. The project was encoded with the native ISO-8601 envelope, decoded, initialized as a new `PartsmithDocument`, then re-encoded byte-identically and exported from the reopened document. This tests the model codec and native document/export path, not an app Open-panel click. An initial harness comparison incorrectly compared subsecond in-memory timestamps to the codec’s second-precision saved dates; the final check compares canonical saved bytes without altering score data.

`native-workflow-evidence.tar.gz` contains the frozen Core and private runner, reused inventory, six original page renders, initial/final full output renders, source contexts and the initial PDFs/project JSON. Binaries and duplicate original PDFs are omitted. Its member hashes were verified after creation. The final delivery has its own file hashes and keeps the immutable original PDF embedded in the editable project.
''')
print('archive verified',len(members),'members',archive.stat().st_size,'bytes')
