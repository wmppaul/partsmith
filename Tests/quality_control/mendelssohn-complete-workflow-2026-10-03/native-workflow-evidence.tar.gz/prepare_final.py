from pathlib import Path
import json,hashlib,shutil
w=Path('.build/mendelssohn-complete-2026-10-03');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.load(open(w/'parts/manifest.json'));over=json.load(open(w/'reviewed-overrides.json'))
changes=[('organ',4,2,'top',581.4,'Restore the complete original upper-manual bar68 slur crest. Original drawing546 cubic true minimum y582.60; 0.06pt stroke gives582.57.','[175.9,582.4,242.0,590.4]'),('bass',1,1,'bottom',524.0,'Keep the complete Bass initial staff/rests through516.36 and clear blank below it; exclude duplicate Organ Andante beginning530.434 and Organ slurs.','[52,495,560,518]'),('bass',4,2,'bottom',599.0,'Retain all Bass lyrics through the independently measured597.6546 text extent; remove lower Organ staff/notes while retaining overlapping upper Organ fragments.','[329.0,586.0,554.0,598.0]')]
receipts=[]
for pid,p,s,edge,value,why,guard in changes:
 old=next(b['sourceRect'] for part in m['parts'] if part['id']==pid for b in part['placements'] if b['sourcePage']==p and b['system']==s);new=list(old);new[1 if edge=='top' else 3]=value
 band=next(b for b in over[p-1]['systems'][s-1]['bands'] if b['partID']==pid);band['rect']=new
 receipts.append({'part':pid,'page':p,'system':s,'before':old,'after':new,'reason':why,'independentLocalSourceObligation':json.loads(guard),'scope':'Original full source and fixed local obligation, not a whole-band segmentation oracle.'})
json.dump(over,open(w/'final-overrides.json','w'),indent=2,ensure_ascii=False)
json.dump({'sourceSHA256':m['sourceSHA256'],'initialManifestSHA256':h(w/'parts/manifest.json'),'changes':receipts,'restJoining':{'sourceVerifiedNoTempoMeterChangesDuringAbsence':True,'spans':{'soprano':[8,66,59],'alto':[8,36,29],'tenor':[8,66,59],'bass':[8,15,8]},'allOriginalPrintedMusicRowsRemain':49,'allOriginalGeneratedRestRecordsRemain':21,'originalTotalReferences':70}},open(w/'manual-corrections.json','w'),indent=2,ensure_ascii=False)
shutil.copy2(w/'export.swift',w/'initial-export.swift')
code=(w/'export.swift').read_text()
code=code.replace('var generatedRest: ScoreGeneratedRest?\n    }','var generatedRest: ScoreGeneratedRest?\n        var sourceBandIDs: [String]\n        var startBarNumber: Int?\n        var barCount: Int?\n    }',1)
code=code.replace('guard let pdf = document.pdfDocument','''if args.contains("--join-rests") {
            for part in document.project.parts {
                let rows = document.project.bands.filter { $0.partID == part.id }
                for (index, row) in rows.enumerated() {
                    guard let rest = row.generatedRest else { continue }
                    let preceding = index > 0 ? rows[index - 1].generatedRest : nil
                    let join = preceding?.endBarNumber.map { $0 + 1 == rest.startBarNumber } ?? false
                    precondition(document.updateBandGeneratedRest(row.id, barCount: rest.barCount, joinWithPrevious: join))
                }
            }
            precondition(document.project.bands.count == 70)
        }
        guard let pdf = document.pdfDocument''')
code=code.replace('layout.pages.flatMap(\\.placements).map(\\.bandID) == stored.map(\\.id)','layout.pages.flatMap(\\.placements).flatMap(\\.sourceBandIDs) == stored.map(\\.id)')
code=code.replace('generatedRest: band.generatedRest))','''generatedRest: placed.generatedRest.map { ScoreGeneratedRest(barCount: $0.barCount, startBarNumber: $0.startBarNumber) },
                        sourceBandIDs: placed.sourceBandIDs.map { byID[$0]!.id },
                        startBarNumber: placed.generatedRest?.startBarNumber ?? band.startBarNumber,
                        barCount: placed.generatedRest?.barCount ?? band.barCount))''')
(w/'export.swift').write_text(code)
print('Frozen three source-reviewed crop changes and four verified rest spans before final output.')
