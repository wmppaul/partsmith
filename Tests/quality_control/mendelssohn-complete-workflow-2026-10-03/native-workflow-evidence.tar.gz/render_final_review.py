from pathlib import Path
import json,hashlib
import pymupdf as f
from PIL import Image,ImageDraw
w=Path('.build/mendelssohn-complete-2026-10-03');m=json.load(open(w/'final-parts/manifest.json'));source=f.open(m['source']);ob=json.load(open(w/'source-obligations.json'))['rows'];rows={x['id']:x for x in ob};out=w/'final-output-review';out.mkdir(exist_ok=True);contexts=w/'final-crop-review';contexts.mkdir(exist_ok=True);rendered=[];index=[]
for part in m['parts']:
 doc=f.open(w/'final-parts'/part['file']);folder=out/part['id'];folder.mkdir(exist_ok=True)
 for i,p in enumerate(doc):
  path=folder/f'page-{i+1:03}.png';p.get_pixmap(matrix=f.Matrix(1.7,1.7)).save(path);rendered.append({'part':part['id'],'page':i+1,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for b in part['placements']:
  if b['generatedRest'] if 'generatedRest' in b else False:continue
  rid=f'p{b["sourcePage"]}-s{b["system"]}-{part["id"]}';o=rows[rid];rect=b['sourceRect'];context=o['sourceContextBounds'];c=[min(context[0],rect[0]),min(context[1],rect[1])-4,max(context[2],rect[2]),max(context[3],rect[3])+4];c=[max(0,c[0]),max(0,c[1]),min(source[b['sourcePage']-1].rect.width,c[2]),min(source[b['sourcePage']-1].rect.height,c[3])];z=2.3
  pix=source[b['sourcePage']-1].get_pixmap(matrix=f.Matrix(z,z),clip=f.Rect(c));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);draw=ImageDraw.Draw(im);draw.line([(0,(rect[1]-c[1])*z),(im.width,(rect[1]-c[1])*z)],fill='red',width=2);draw.line([(0,(rect[3]-c[1])*z),(im.width,(rect[3]-c[1])*z)],fill='red',width=2)
  canvas=Image.new('RGB',(im.width,im.height+25),'white');canvas.paste(im,(0,25));ImageDraw.Draw(canvas).text((8,5),f'{rid} bars {o["start"]}-{o["start"]+o["count"]-1}; red = actual crop',fill='black');path=contexts/(rid+'.png');canvas.save(path)
  index.append({'id':rid,'crop':rect,'context':c,'path':str(path),'sourcePage':b['sourcePage'],'outputPage':b['outputPage'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
json.dump({'sourceSHA256':m['sourceSHA256'],'manifestSHA256':hashlib.sha256((w/'final-parts/manifest.json').read_bytes()).hexdigest(),'outputPages':rendered,'cropContexts':index},open(w/'final-render-index.json','w'),indent=2)
print('rendered',len(rendered),'pages and',len(index),'source crop contexts')
print([(p['id'],p['outputPages']) for p in m['parts']])
