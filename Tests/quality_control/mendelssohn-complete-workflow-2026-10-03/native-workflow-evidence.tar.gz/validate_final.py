from pathlib import Path
import json,hashlib,math
import pymupdf as f
w=Path('.build/mendelssohn-complete-2026-10-03');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.load(open(w/'parts/manifest.json'));new=json.load(open(w/'final-parts/manifest.json'));truth=json.load(open(w/'source-map.json'));fix=json.load(open(w/'manual-corrections.json'));plans=json.load(open(w/'final-parts/plan.json'));bands=[b for p in plans['pages'] for b in p['assignments']];assert len(bands)==70
project=json.load(open(w/'final-parts'/new['project']/'project.json'))['project'];assert len(project['bands'])==70;assert h(w/'final-parts'/new['project']/'source.pdf')==new['sourceSHA256'];assert all(not b.get('exclusions') for b in project['bands'])
parts=[];changes=[]
for p in new['parts']:
 plan=[b for b in bands if b['partID']==p['id']];out=p['placements'];refs=[x for b in out for x in b['sourceBandIDs']];assert refs==[b['id'] for b in plan];assert len(set(refs))==14
 expected=[]
 for pg in truth['pages']:
  for sy in pg['systems']:
   expected.append((pg['pageNumber']-1,sy['systemNumber']-1,sy['startBarNumber'],sy['barCount'],sy['partStaffRanksOneBased'].get(p['id'],[])))
 for b,e in zip(plan,expected):
  assert (b['pageIndex'],b['systemIndex'],b['startBarNumber'],b['barCount'])==e[:4]
  assert b['candidateIDs']==[n-1 for n in e[4]]
 n=1
 for b in out:
  assert b['startBarNumber']==n;n+=b['barCount']
  rect=b['destinationRect'];assert all(math.isfinite(x) for x in rect)
  assert 0<=rect[0]<rect[2]<=612+1e-8 and 0<=rect[1]<rect[3]<=792+1e-8
 assert n==103
 bef=next(x for x in old['parts'] if x['id']==p['id']);by={b['id']:b for b in bef['placements']}
 for b in out:
  if b.get('generatedRest'):continue
  a=by[b['id']]
  if any(abs(x-y)>1e-8 for x,y in zip(a['sourceRect'],b['sourceRect'])):changes.append({'id':b['id'],'part':p['id'],'before':a['sourceRect'],'after':b['sourceRect']})
  assert len(a['sourceMarkings'])==len(b['sourceMarkings'])
  assert all(all(abs(x-y)<1e-8 for x,y in zip(am['sourceRect'],bm['sourceRect'])) for am,bm in zip(a['sourceMarkings'],b['sourceMarkings']))
  for sm in b['sourceMarkings']:assert sm['sourceRect']==[126,329,162,342]
 doc=f.open(w/'final-parts'/p['file']);assert len(doc)==p['outputPages'];assert h(w/'final-parts'/p['file'])==p['sha256']
 parts.append({'id':p['id'],'file':p['file'],'sha256':p['sha256'],'outputPages':p['outputPages'],'renderedRows':len(out),'originalItemReferences':len(refs),'barsCovered':[1,102],'restRows':[{'start':b['generatedRest']['startBarNumber'],'count':b['generatedRest']['barCount'],'sourceRows':b['sourceBandIDs']} for b in out if b.get('generatedRest')]})
assert len(changes)==3
for c in fix['changes']:
 p=next(x for x in new['parts'] if x['id']==c['part']);b=next(x for x in p['placements'] if x['sourcePage']==c['page'] and x['system']==c['system']);a=b['sourceRect'];g=c['independentLocalSourceObligation'];assert a[0]<=g[0] and a[1]<=g[1] and a[2]>=g[2] and a[3]>=g[3]
core=json.load(open(w/'production-source-hashes.json'));current={p:h(Path(p))==sha for p,sha in core.items()};assert all(current.values())
res={'scope':'Current native review/apply, user-level rest-joining API, canonical save/decode/reopen and native export of all parts; saved native analysis reused without detector/matcher rerun.','sourceSHA256':new['sourceSHA256'],'baselineManifestSHA256':h(w/'parts/manifest.json'),'finalManifestSHA256':h(w/'final-parts/manifest.json'),'inputBindingsSHA256':h(w/'input-bindings.json'),'manualCorrectionsSHA256':h(w/'manual-corrections.json'),'coreCurrentMatches':current,'nativeAnalyzerSHA256':core['Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'],'sourceMusicRows':49,'originalGeneratedRestRows':21,'renderedGeneratedRestRows':4,'renderedTotalRows':53,'originalRefsPreserved':70,'completeAllFiveTimelines':True,'nativeCodecReencodedSavedProjectBytesEqual':True,'codecScope':'Uses ISO-8601 project envelope decoder and PartsmithDocument initialization; no app UI open-panel click claimed. Timestamps use the codec’s second precision.','noExclusions':True,'copiedVerifiedAndanteCount':3,'sourceCropChanges':changes,'localSourceObligationsContained':3,'parts':parts,'knownRemainingLimitations':['Manual source identities/counts and three local crop corrections; not unattended Auto identity/crop success.','Residual foreign lyrics and slur/beam fragments, especially Bass bar67 and Organ rows.','Bass page turn51→52 splits a continuing vocal phrase. Organ turns29→30 and66→67 occur during continuous playing; no performance-safe turn claim.','Generated rests use native typography and do not engrave the original source’s exact style. Printed opening staves retain the3/4 meter.']}
json.dump(res,open(w/'validation.json','w'),indent=2,ensure_ascii=False)
print('verified70 original references, five102-bar timelines,53 rendered rows,8 pages,3 exact reviewed crops,3 complete tempo copies,25 current Core hashes')
