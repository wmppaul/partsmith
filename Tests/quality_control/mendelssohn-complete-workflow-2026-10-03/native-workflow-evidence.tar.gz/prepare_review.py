from pathlib import Path
import json,hashlib
import pymupdf as f
from PIL import Image,ImageDraw
r=Path.cwd();w=r/'.build/mendelssohn-complete-2026-10-03';d=json.load(open(w/'source-map.json'));doc=f.open(r/d['sourcePath']);out=w/'source-review';out.mkdir(exist_ok=True)
rows=[]
for p in d['pages']:
 page=doc[p['pageNumber']-1];st=p['sourceStaffs']
 for s in p['systems']:
  for pid,ranks in s['partStaffRanksOneBased'].items():
   a,b=st[ranks[0]-1],st[ranks[-1]-1];top=a['lineYs'][0];bot=b['lineYs'][-1]
   bounds=[35,max(0,top-26),565,min(p['height'],bot+(23 if pid!='organ' else 18))]
   if p['pageNumber']==1:bounds[0]=40
   rid=f'p{p["pageNumber"]}-s{s["systemNumber"]}-{pid}'
   page.get_pixmap(matrix=f.Matrix(2.3,2.3),clip=f.Rect(bounds)).save(out/(rid+'.png'))
   rows.append({'id':rid,'page':p['pageNumber'],'system':s['systemNumber'],'part':pid,'start':s['startBarNumber'],'count':s['barCount'],'staffRanks':ranks,'sourceContextBounds':bounds,'sourceStaffCoreBounds':[a['left'],top,b['right'],bot],'sourceObligations':['All original clefs, keys, notes/rests, stems/beams, slurs/ties, articulations and dynamics belonging to this part.']+(['Complete lyrics for this voice.'] if pid!='organ' else ['Both manuals and pedal, complete registrations and clef changes.']),'sourceContextSHA256':hashlib.sha256((out/(rid+'.png')).read_bytes()).hexdigest()})
json.dump({'scope':'Frozen source-only contexts and obligations before first native output. Context bounds aid inspection; they are not proposed crops or a claim to fully segmented target pixels. Original full pages remain authoritative.','sourceSHA256':d['sourceSHA256'],'rows':rows},open(w/'source-obligations.json','w'),indent=2)
print('source contexts',len(rows))
