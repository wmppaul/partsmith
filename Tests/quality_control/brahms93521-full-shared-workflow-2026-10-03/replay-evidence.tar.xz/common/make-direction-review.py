from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import pymupdf as fitz,json,hashlib
w=Path('.build/brahms93521-full-production-workflow-draft-2026-10-03');parts=w/'production-crop-draft-parts';out=w/'direction-review';out.mkdir(exist_ok=True)
a=json.loads((w/'recognized-inventory.json').read_text());plan=json.loads((w/'workflow-result.json').read_text())['plan'];man=json.loads((parts/'manifest.json').read_text());by={x['pageIndex']:x for x in plan['pages']};targets={}
for page in a['pages']:
 for kind in ['sharedHeadings','sharedNavigation','sharedEndings']:
  for mark in page.get(kind) or []:
   owner=next(b for b in by[page['pageIndex']]['assignments'] if mark['anchorStaffID'] in b['candidateIDs'])
   targets.setdefault((page['pageIndex'],owner['systemIndex']),[]).append({'kind':kind,'mark':mark})
original=fitz.open(a['source']);corrected=fitz.open(parts/man['reviewSourceFile']);pdfs={p['id']:fitz.open(parts/p['file']) for p in man['parts']};font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',18)
def render(doc,pn,rect,path):
 page=doc[pn];clip=fitz.Rect(rect)&page.rect;pix=page.get_pixmap(matrix=fitz.Matrix(3,3),clip=clip,alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.save(path);return im,list(clip)
def label(im,text,width=1440):
 im=im.resize((width,round(im.height*width/im.width)));box=Image.new('RGB',(width,im.height+26),'white');ImageDraw.Draw(box).text((5,3),text,font=font,fill='black');box.paste(im,(0,26));return box
index=[]
for (pn,sy),marks in sorted(targets.items()):
 page=a['pages'][pn];bands=[b for b in by[pn]['assignments'] if b['systemIndex']==sy];ids={i for b in bands for i in b['candidateIDs']};staves=[s for s in page['staves'] if s['id'] in ids];top=min(s['staffLineFractions'][0] for s in staves)-.025;bottom=max(s['staffLineFractions'][4] for s in staves)+.025
 for obj in marks:top=min(top,obj['mark']['bounds'][1]-.008);bottom=max(bottom,obj['mark']['bounds'][3]+.008)
 rect=[0,max(0,top)*page['pageHeight'],page['pageWidth'],min(1,bottom)*page['pageHeight']];sheet=[];entries=[]
 for name,doc in [('original',original),('corrected',corrected)]:
  path=out/f'p{pn+1}-s{sy+1}-source-{name}.png';im,clip=render(doc,pn,rect,path);sheet.append(label(im,f'SOURCE {name} page{pn+1} system{sy+1}'));entries.append({'kind':name,'path':str(path),'clip':clip,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for part in man['parts']:
  placement=next(x for x in part['placements'] if x['sourcePage']==pn+1 and x['system']==sy+1);r=fitz.Rect(placement['destinationRect'])
  for m in placement['sourceMarkings']:r|=fitz.Rect(m['destinationRect'])
  r=fitz.Rect(0,r.y0-12,pdfs[part['id']][placement['outputPage']-1].rect.width,r.y1+12)
  path=out/f'p{pn+1}-s{sy+1}-{part["id"]}.png';im,clip=render(pdfs[part['id']],placement['outputPage']-1,r,path);sheet.append(label(im,f'OUTPUT {part["name"]} page{placement["outputPage"]} — source page{pn+1} system{sy+1}'));entries.append({'kind':'output','partID':part['id'],'file':part['file'],'outputPage':placement['outputPage'],'path':str(path),'clip':clip,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 canvas=Image.new('RGB',(1440,sum(x.height+10 for x in sheet)),'#ddd');y=0
 for im in sheet:canvas.paste(im,(0,y));y+=im.height+10
 path=out/f'p{pn+1}-s{sy+1}-comparison.png';canvas.save(path);index.append({'sourcePage':pn+1,'system':sy+1,'directions':marks,'entries':entries,'comparison':str(path),'comparisonSHA256':hashlib.sha256(path.read_bytes()).hexdigest()})
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n');print('source systems',len(index),'output strips',len(index)*4)
