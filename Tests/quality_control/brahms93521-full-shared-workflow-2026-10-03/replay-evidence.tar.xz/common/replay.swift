import AppKit
import CryptoKit
import Foundation
import PDFKit
struct Inventory: Codable {
    var source: String
    var sourceSHA256: String
    var pages: [ScorePageAnalysis]
    var rectifications: [PageRectification]?
}
struct Issue: Codable { var pageIndex: Int; var message: String }
struct Reference: Codable {
    var pageIndex: Int; var anchorStaffID: Int; var bounds: [Double]
    var correlation: Double; var templatePageIndex: Int; var templateBounds: [Double]
}
struct PageRecord: Codable {
    var pageIndex: Int; var staffCount: Int; var headingStageCompleted: Bool
    var navigationStageCompleted: Bool; var headings: [String]; var navigation: [String]
    var endingPairIDs: [String]; var issues: [Issue]
}
struct Report: Codable {
    var inputSHA256: String; var sourceSHA256: String; var profileSHA256: String
    var elapsedSeconds: Double; var issues: [Issue]; var references: [Reference]
    var pages: [PageRecord]; var plan: ScoreExtractionPlan; var autoSkippedPageIndices: [Int]
}
@main struct FullWorkflowReplay {
    static func hash(_ data: Data) -> String { SHA256.hash(data:data).map { String(format:"%02x",$0) }.joined() }
    static func main() throws {
        if CommandLine.arguments[1] == "export" { try ExportScorePlan.main(); return }
        let work=URL(fileURLWithPath:CommandLine.arguments[1])
        let data=try Data(contentsOf:work.appendingPathComponent("inventory-input.json"))
        var inventory=try JSONDecoder().decode(Inventory.self,from:data)
        let profileData=try Data(contentsOf:work.appendingPathComponent("profile.json"))
        let profile=try JSONDecoder().decode(ScoreExtractionProfile.self,from:profileData)
        let source=try Data(contentsOf:URL(fileURLWithPath:inventory.source))
        precondition(hash(source)==inventory.sourceSHA256)
        guard let pdf=PDFDocument(data:source) else { fatalError("Cannot read immutable source PDF") }
        precondition(pdf.pageCount==39 && inventory.pages.map(\.pageIndex)==Array(0..<39))
        let originals=inventory.pages
        let start=Date()
        let result=ScoreSharedDirectionWorkflow.run(pdf:pdf,analyses:originals,profile:profile,
            rectifications:inventory.rectifications ?? [],progress:{ p in
                print("\(p.phase.rawValue) \(p.completedPages)/\(p.totalPages)");fflush(stdout)
            },isCancelled:{false})
        // Recognition may add metadata only; source/staff/component evidence is immutable.
        for (old,new) in zip(originals,result.analyses) {
            var stripped=new;stripped.sharedHeadings=old.sharedHeadings
            stripped.sharedNavigation=old.sharedNavigation;stripped.sharedEndings=old.sharedEndings
            precondition(stripped==old,"Recognition changed original source analysis")
        }
        precondition(result.analyses.count==originals.count)
        inventory.pages=result.analyses
        let review=ScoreDetectionReview.initial(profile:profile,analyses:result.analyses,
            sourcePDFData:source,rectifications:inventory.rectifications ?? [],
            directionIssues:result.issues,directionReferences:result.references)
        precondition(review.plan.canApply && review.plan.bands.count==604,"Full source-band scope changed")
        let issues=result.issues.map { Issue(pageIndex:$0.pageIndex,message:$0.message) }
        let records=result.analyses.map { page in
            PageRecord(pageIndex:page.pageIndex,staffCount:page.staves.count,
                headingStageCompleted:page.sharedHeadings != nil,navigationStageCompleted:page.sharedNavigation != nil,
                headings:(page.sharedHeadings ?? []).map(\.recognizedText),
                navigation:(page.sharedNavigation ?? []).map(\.recognizedText),
                endingPairIDs:Array(Set((page.sharedEndings ?? []).map(\.pairID))).sorted(),
                issues:issues.filter{$0.pageIndex==page.pageIndex})
        }
        let report=Report(inputSHA256:hash(data),sourceSHA256:hash(source),profileSHA256:hash(profileData),
            elapsedSeconds:Date().timeIntervalSince(start),issues:issues,
            references:result.references.map { Reference(pageIndex:$0.pageIndex,anchorStaffID:$0.match.anchorStaffID,
                bounds:$0.match.bounds,correlation:$0.match.correlation,templatePageIndex:$0.match.templatePageIndex,
                templateBounds:$0.match.templateBounds) },pages:records,plan:review.plan,
            autoSkippedPageIndices:review.autoSkippedPageIndices.sorted())
        let encoder=JSONEncoder();encoder.outputFormatting=[.prettyPrinted,.sortedKeys,.withoutEscapingSlashes]
        try encoder.encode(inventory).write(to:work.appendingPathComponent("recognized-inventory.json"),options:.atomic)
        try encoder.encode(report).write(to:work.appendingPathComponent("workflow-result.json"),options:.atomic)
        print("COMPLETE: \(result.analyses.count) pages, \(review.plan.bands.count) bands, \(issues.count) direction issues, \(result.references.count) linked destinations, \(report.elapsedSeconds) seconds")
        fflush(stdout)
    }
}
