from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,hashlib
p=Path('.build/brahms-case176-2026-10-03');result={}
for variant in ['baseline','candidate-v2']:
 d=p/variant;source=np.array(Image.open(d/'case176-source.pgm'))<190;line=np.array(Image.open(d/'after-lines-true.pgm'))<190;final=np.array(Image.open(d/'after-connectors-true.pgm'))<190
 comps=json.load(open(d/'components.json'));musical=np.array(Image.open(d/'case176-middle-owner.pgm'))<190
 # Actual eight-connected component containing source stem pixel(601,240).
 seen={(601,240)};queue=list(seen);head=0
 while head<len(queue):
  x,y=queue[head];head+=1
  for dy in [-1,0,1]:
   for dx in [-1,0,1]:
    xx,yy=x+dx,y+dy
    if 0<=xx<720 and 0<=yy<760 and final[yy,xx] and (xx,yy) not in seen:seen.add((xx,yy));queue.append((xx,yy))
 bbox=[min(x for x,y in seen),min(y for x,y in seen),max(x for x,y in seen)+1,max(y for x,y in seen)+1]
 match=[c for c in comps if all(abs(v-n)<1e-6 for v,n in zip([c['bounds'][0]*720,c['bounds'][1]*760,c['bounds'][2]*720,c['bounds'][3]*760],bbox))]
 assert len(match)==1
 topPixels=sorted([[x,y] for x,y in seen if y==bbox[1]])
 points=[]
 for y in range(212,215):
  for x in range(600,603):
   owners=[c['staffIDs'] for c in comps if c['bounds'][0]*720<=x and c['bounds'][1]*760<=y and c['bounds'][2]*720>x and c['bounds'][3]*760>y]
   points.append({'xy':[x,y],'source':bool(source[y,x]),'musicalOwner1':bool(musical[y,x]),'afterLines':bool(line[y,x]),'afterConnectors':bool(final[y,x]),'componentOwners':owners})
 crop=next(a for page in json.load(open(d/'plan.json'))['pages'] for a in page['assignments'] if a['partID']=='p1')
 result[variant]={'driverComponentBounds':bbox,'driverOwners':match[0]['staffIDs'],'driverComponentArea':len(seen),'highestComponentPixels':topPixels,'highestPixelsHaveSourceMusicalOwner1':any(musical[y,x] for x,y in topPixels),'topClearance':18,'derivedTop':bbox[1]-18,'actualCropTop':crop['topFraction']*760,'newlyLostPixelsThroughAnalysis':points}
 mask=np.full((760,720,3),255,dtype=np.uint8);mask[source]=[180,180,180]
 for x,y in seen:mask[y,x]=[30,110,210]
 for y in range(212,215):
  for x in range(600,603):mask[y,x]=[225,20,130]
 im=Image.fromarray(mask).crop((360,170,630,405)).resize((810,705));dr=ImageDraw.Draw(im)
 for y,col in [(bbox[1],(10,120,10)),(bbox[1]-18,(200,10,10))]:dr.line((0,(y-170)*3,810,(y-170)*3),fill=col,width=2)
 im.save(d/'component-source-map.png')
(p/'component-ownership-map.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
