from pathlib import Path
import json,hashlib,zipfile,shutil
p=Path('.build/brahms-case176-2026-10-03');r=Path('Tests/quality_control/brahms-case176-ownership-2026-10-03');r.mkdir(exist_ok=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for v in ['baseline','candidate-v2']:
 shutil.copy2(p/v/'component-source-map.png',r/(v+'-component-source-map.png'))
shutil.copy2(p/'component-ownership-map.json',r/'component-ownership-map.json')
a=json.load(open(p/'baseline/diagnostic.json'))[0];b=json.load(open('.build/ownership-alternatives-2026-10-03/results297.json'))[176];assert a==b
c=json.load(open(p/'candidate-v2/diagnostic.json'))[0];d=json.load(open('.build/brahms-numbered-lines-2026-10-03/candidate-v2/controls297.json'))[176];assert c==d
if (p/'baseline-deep/diagnostic.json').exists():assert json.load(open(p/'baseline-deep/diagnostic.json'))[0]==b
bindings={str(f):sha(f) for f in [Path('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'),Path('Partsmith/Core/Detection/ScoreExtractionPlanner.swift'),Path('Tests/quality_control/brahms-numbered-lines-2026-10-03/manifest.json'),Path('.build/brahms-numbered-lines-2026-10-03/controls297.swift'),Path('.build/brahms-numbered-lines-2026-10-03/candidate-v2/Core/Detection/NativeScorePageAnalyzer.swift')]}
(r/'bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
files=[f for f in p.rglob('*') if f.is_file() and f.suffix in ['.json','.pgm','.png','.py','.sh','.log']]
files += [p/'diagnostic.swift'] + [p/v/'Core/Detection/NativeScorePageAnalyzer.swift' for v in ['baseline','candidate-v2','baseline-deep']]
with zipfile.ZipFile(r/'diagnostic-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(set(files)):z.write(f,str(f.relative_to(p)))
with zipfile.ZipFile(r/'diagnostic-evidence.zip') as z:
 assert z.testzip() is None
 m={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
(r/'archive-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(len(m),(r/'diagnostic-evidence.zip').stat().st_size)
