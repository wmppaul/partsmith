import Foundation
final class ActualUIState {
 var profile: ScoreExtractionProfile
 var review: ScoreDetectionReview?
 var selectedPage=0, correctionSystem=1
 var printedPartIDs=Set<String>(), systemStaffCounts:[String:Int]=[:], selectedStaves=Set<Int>()
 var systemFirstBar="", systemBarCount=""
 var templateFocusBounds:[Double]?, templateFocusID=UUID(), selectionAnchor:Int?, assignmentStatus:String?, errorMessage:String?
 var selectedSuggestions:[ScoreSystemTemplateMatcher.Suggestion]=[],starts:[String:String]=[:],counts:[String:String]=[:]
 init(_ profile:ScoreExtractionProfile,_ review:ScoreDetectionReview) { self.profile=profile;self.review=review;printedPartIDs=Set(profile.parts.map(\.id)) }
var currentAnalysis: ScorePageAnalysis? { review?.analyses.first { $0.pageIndex == selectedPage } }
var currentPlan: ScorePagePlan? { review?.plan.pages.first { $0.pageIndex == selectedPage } }
var expectedSelectedStaffCount: Int {
        profile.parts.filter { printedPartIDs.contains($0.id) }.reduce(0) { $0 + (systemStaffCounts[$1.id] ?? $1.staffCount) }
    }
func selectTemplateSuggestion(_ suggestion: ScoreSystemTemplateMatcher.Suggestion) {
        templateFocusBounds = suggestion.sourceBounds
        templateFocusID = UUID()
        selectedStaves = Set(suggestion.candidateIDs)
        printedPartIDs = suggestion.presentPartIDs
        systemStaffCounts = suggestion.staffCounts
        correctionSystem = suggestion.systemIndex + 1
        systemFirstBar = ""
        systemBarCount = ""
        selectionAnchor = nil
        assignmentStatus = "Matching layout highlighted: " + profile.parts.filter { suggestion.presentPartIDs.contains($0.id) }.map(\.name).joined(separator: ", ")
    }
func loadSystemAssignment() {
        guard let review else { return }
        let correction = pageOverride(review)
        guard let system = correction.systems.first(where: { $0.systemIndex == correctionSystem - 1 }) else { return }
        selectedStaves = Set(system.bands.flatMap { $0.candidateIDs ?? [] })
        let music = system.bands.filter { ($0.kind ?? "music") == "music" }
        printedPartIDs = Set(music.map(\.partID))
        systemStaffCounts = [:]
        for band in music {
            if let count = band.candidateIDs?.count, (1...4).contains(count) {
                systemStaffCounts[band.partID] = count
            }
        }
        systemFirstBar = system.startBarNumber.map(String.init) ?? ""
        systemBarCount = system.barCount.map(String.init) ?? ""
        selectionAnchor = nil
        assignmentStatus = nil
    }
func assignSystemSelection() {
        guard var value = review, let analysis = currentAnalysis else { return }
        let firstText = systemFirstBar.trimmingCharacters(in: .whitespacesAndNewlines)
        let countText = systemBarCount.trimmingCharacters(in: .whitespacesAndNewlines)
        guard firstText.isEmpty || Int(firstText).map({ $0 > 0 }) == true,
              countText.isEmpty || Int(countText).map({ (1...999).contains($0) }) == true else {
            errorMessage = "Use a positive first bar and a bar count from 1 to 999."
            return
        }
        do {
            let correction = try ScoreSystemAssignment.assign(page: analysis, profile: profile,
                pagePlan: currentPlan, existingOverride: value.overrides.first(where: { $0.pageIndex == selectedPage }),
                systemIndex: correctionSystem - 1, candidateIDs: selectedStaves.sorted(), presentPartIDs: printedPartIDs,
                startBarNumber: Int(firstText), barCount: Int(countText),
                staffCounts: systemStaffCounts.filter { printedPartIDs.contains($0.key) })
            value.overrides.removeAll { $0.pageIndex == selectedPage }
            value.overrides.append(correction)
            value.replan()
            review = value
            let restParts = profile.parts.count - printedPartIDs.count
            assignmentStatus = "System \(correctionSystem) assigned." + (restParts > 0 ? " Added \(countText)-bar rests for \(restParts) absent instruments." : "")
            correctionSystem = min(32, correctionSystem + 1)
            selectedStaves.removeAll(); selectionAnchor = nil
            // A repeated instrument layout does not imply a repeated measure count.
            if let first = Int(firstText), let count = Int(countText), first <= Int.max - count {
                systemFirstBar = String(first + count)
            } else { systemFirstBar = "" }
            systemBarCount = ""
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }
func pageOverride(_ review: ScoreDetectionReview) -> ScorePageOverride {
        guard let page = review.analyses.first(where: { $0.pageIndex == selectedPage }) else {
            return ScorePageOverride(pageIndex: selectedPage, reason: "Instrument assignments reviewed in Auto Extract.", systems: [])
        }
        return ScoreSystemAssignment.pageOverride(page: page,
            pagePlan: review.plan.pages.first { $0.pageIndex == selectedPage },
            existingOverride: review.overrides.first { $0.pageIndex == selectedPage })
    }
func stillMatches(_ before: ScoreDetectionReview, _ after: ScoreDetectionReview) -> Bool {
        before.profile == after.profile && before.sourcePDFData == after.sourcePDFData &&
            before.rectifications == after.rectifications && before.analyses == after.analyses &&
            before.overrides == after.overrides && before.selectedPageIndices == after.selectedPageIndices &&
            before.excludedPageReasons == after.excludedPageReasons
    }
func validNumber(_ value: String, required: Bool, maximum: Int) -> Bool {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return !required }
        return Int(trimmed).map { $0 > 0 && $0 <= maximum } ?? false
    }
func makeChoices() -> [ScoreSystemAssignmentChoice] {
let choices = selectedSuggestions.map {
            ScoreSystemAssignmentChoice(pageIndex: $0.pageIndex, systemIndex: $0.systemIndex,
                candidateIDs: $0.candidateIDs, presentPartIDs: $0.presentPartIDs,
                startBarNumber: Int((starts[$0.id] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)),
                barCount: Int((counts[$0.id] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)),
                staffCounts: $0.staffCounts)
        }
return choices
}
}
@main enum Run {
 static var checks=0
 static func ok(_ condition:@autoclosure()->Bool,_ message:String) { checks+=1;precondition(condition(),message);print("PASS \(message)") }
 static func main() throws {
 let profile=ScoreExtractionProfile(parts:[ScorePartDefinition(id:"voice",name:"Voice",staffCount:1),ScorePartDefinition(id:"piano",name:"Piano",staffCount:2)],requiresSystemAssignment:true)
 let staves=[0.12,0.18,0.24,0.40,0.47,0.54,0.68,0.75,0.82].enumerated().map { i,y in ScoreObservedStaff(StaffBandCandidate(id:i,staffLineFractions:(0..<5).map{y+Double($0)*0.005},topFraction:y-0.01,bottomFraction:y+0.03,confidence:1,warnings:[])) }
 let page=ScorePageAnalysis(pageIndex:0,pageWidth:600,pageHeight:800,imageWidth:1800,imageHeight:2400,staves:staves,warnings:[])
 let initial=ScoreDetectionReview.initial(profile:profile,analyses:[page],overrides:[],selectedPageIndices:[0],sourcePDFData:Data("immutable".utf8),rectifications:[])
 let s=ActualUIState(profile,initial)
 ok(s.expectedSelectedStaffCount==3,"initial expected count uses profile defaults")
 s.systemStaffCounts=["voice":2,"piano":1];s.selectedStaves=[0,1,2]
 ok(s.expectedSelectedStaffCount==3 && s.profile==profile,"local 2+1 grouping leaves profile unchanged")
 s.assignSystemSelection()
 ok(s.errorMessage==nil,"actual Assign action accepts local divisi")
 let first=s.review!.overrides[0].systems[0]
 ok(first.bands.first{$0.partID=="voice"}!.candidateIDs==[0,1] && first.bands.first{$0.partID=="piano"}!.candidateIDs==[2],"actual Assign passes counts and maps successive physical staves")
 ok(s.correctionSystem==2 && s.systemStaffCounts==["voice":2,"piano":1] && s.systemBarCount.isEmpty,"next system keeps counts while clearing duration")
 s.systemStaffCounts=["voice":4,"piano":4];s.printedPartIDs=[];s.correctionSystem=1;s.loadSystemAssignment()
 ok(s.selectedStaves==[0,1,2] && s.printedPartIDs==["voice","piano"] && s.systemStaffCounts==["voice":2,"piano":1],"Load reconstructs actual saved divisi groups")
 let suggestion=ScoreSystemTemplateMatcher.Suggestion(pageIndex:0,systemIndex:1,candidateIDs:[3,4,5],presentPartIDs:["voice","piano"],templatePageIndex:0,templateSystemIndex:0,confidence:.sourceSupported,reasons:[],sourceBounds:[0,0.35,1,0.6],requiresMeasureCount:false,staffCounts:["voice":2,"piano":1])
 s.systemFirstBar="777";s.systemBarCount="88";s.selectTemplateSuggestion(suggestion)
 ok(s.selectedStaves==[3,4,5] && s.systemStaffCounts==suggestion.staffCounts && s.correctionSystem==2,"Show transfers selected staves and exact template grouping")
 ok(s.systemFirstBar.isEmpty && s.systemBarCount.isEmpty,"Show never copies a template's duration")
 s.assignSystemSelection();ok(s.errorMessage==nil && s.review!.overrides[0].systems[1].bands.first{$0.partID=="voice"}!.candidateIDs==[3,4],"Show then Assign preserves divisi")
 var silent=suggestion;silent.systemIndex=2;silent.candidateIDs=[6,7,8];silent.presentPartIDs=["piano"];silent.staffCounts=["piano":3];silent.requiresMeasureCount=true
 s.selectTemplateSuggestion(silent);s.systemStaffCounts["voice"]=4;s.systemFirstBar="20";s.systemBarCount="5";s.assignSystemSelection()
 ok(s.errorMessage==nil,"unchecked stale count is filtered by actual Assign call")
 let third=s.review!.overrides[0].systems[2]
 ok(third.bands.first{$0.partID=="piano"}!.candidateIDs==[6,7,8] && third.omittedParts?.first?.partID=="voice" && third.barCount==5,"silent layout keeps actual grouped staves and explicit duration")
 s.correctionSystem=3;s.loadSystemAssignment()
 ok(s.printedPartIDs==["piano"] && s.systemStaffCounts==["piano":3] && s.systemBarCount=="5" && s.selectedStaves==[6,7,8],"Load excludes generated rest from printed roster and restores count")
 ok(s.profile==profile && s.review!.profile==profile,"all UI state transitions leave global profile exact")
 let b=ActualUIState(profile,initial);b.selectedSuggestions=[suggestion];let choices=b.makeChoices()
 ok(choices.count==1 && choices[0].staffCounts==["voice":2,"piano":1],"actual batch mapping includes staff counts")
 var seedSuggestion=suggestion;seedSuggestion.systemIndex=0;seedSuggestion.candidateIDs=[0,1,2];b.selectedSuggestions=[seedSuggestion]
 let applied=try ScoreSystemAssignmentBatch.applying(b.makeChoices(),to:initial)
 ok(applied.profile==profile && applied.overrides[0].systems[0].bands.first{$0.partID=="voice"}!.candidateIDs==[0,1],"batch UI mapping reaches native grouping without profile mutation")
 var changed=initial;changed.profile.parts[0].staffCount=2
 ok(!b.stillMatches(initial,changed),"profile change rejects stale matcher result")
 changed=initial;changed.overrides=s.review!.overrides
 ok(!b.stillMatches(initial,changed),"assignment change rejects stale matcher result")
 ok(!b.validNumber("",required:true,maximum:999) && b.validNumber("5",required:true,maximum:999),"silent-layout Apply remains gated by explicit valid duration")
 print("\(checks) extracted UI state controls passed")
 }
}
