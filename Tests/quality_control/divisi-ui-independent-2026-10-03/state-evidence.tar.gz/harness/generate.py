from pathlib import Path
import json,hashlib
w=Path('.build/divisi-ui-independent-2026-10-03');base=Path('.build/divisi-assignment-release-2026-10-03');v=base/'Partsmith/Features/Project/ScoreExtractionView.swift';p=base/'Partsmith/Features/Project/ScoreSystemTemplatePanel.swift';vs=v.read_text();ps=p.read_text();records=[]
def extract(s,start):
 pos=s.index(start);first=s.index('{',pos);depth=0
 for i in range(first,len(s)):
  if s[i]=='{':depth+=1
  if s[i]=='}':
   depth-=1
   if not depth:
    x=s[pos:i+1];records.append({'signature':start,'sha256':hashlib.sha256(x.encode()).hexdigest(),'bytes':len(x.encode())});return x.replace('private ','',1)
 raise ValueError(start)
methods='\n'.join(extract(vs,x) for x in ['private var currentAnalysis:','private var currentPlan:','private var expectedSelectedStaffCount:','private func selectTemplateSuggestion(','private func loadSystemAssignment()','private func assignSystemSelection()','private func pageOverride('])
methods+='\n'+extract(ps,'private func stillMatches(')+'\n'+extract(ps,'private func validNumber(')
choices=extract(ps,'let choices = selectedSuggestions.map');methods+='\nfunc makeChoices() -> [ScoreSystemAssignmentChoice] {\n'+choices+'\nreturn choices\n}'
head='''import Foundation
final class ActualUIState {
 var profile: ScoreExtractionProfile
 var review: ScoreDetectionReview?
 var selectedPage=0, correctionSystem=1
 var printedPartIDs=Set<String>(), systemStaffCounts:[String:Int]=[:], selectedStaves=Set<Int>()
 var systemFirstBar="", systemBarCount=""
 var templateFocusBounds:[Double]?, templateFocusID=UUID(), selectionAnchor:Int?, assignmentStatus:String?, errorMessage:String?
 var selectedSuggestions:[ScoreSystemTemplateMatcher.Suggestion]=[],starts:[String:String]=[:],counts:[String:String]=[:]
 init(_ profile:ScoreExtractionProfile,_ review:ScoreDetectionReview) { self.profile=profile;self.review=review;printedPartIDs=Set(profile.parts.map(\\.id)) }
'''
tests='''
}
@main enum Run {
 static var checks=0
 static func ok(_ condition:@autoclosure()->Bool,_ message:String) { checks+=1;precondition(condition(),message);print("PASS \\(message)") }
 static func main() throws {
 let profile=ScoreExtractionProfile(parts:[ScorePartDefinition(id:"voice",name:"Voice",staffCount:1),ScorePartDefinition(id:"piano",name:"Piano",staffCount:2)],requiresSystemAssignment:true)
 let staves=[0.12,0.18,0.24,0.40,0.47,0.54,0.68,0.75,0.82].enumerated().map { i,y in ScoreObservedStaff(StaffBandCandidate(id:i,staffLineFractions:(0..<5).map{y+Double($0)*0.005},topFraction:y-0.01,bottomFraction:y+0.03,confidence:1,warnings:[])) }
 let page=ScorePageAnalysis(pageIndex:0,pageWidth:600,pageHeight:800,imageWidth:1800,imageHeight:2400,staves:staves,warnings:[])
 let initial=ScoreDetectionReview.initial(profile:profile,analyses:[page],overrides:[],selectedPageIndices:[0],sourcePDFData:Data("immutable".utf8),rectifications:[])
 let s=ActualUIState(profile,initial)
 ok(s.expectedSelectedStaffCount==3,"initial expected count uses profile defaults")
 s.systemStaffCounts=["voice":2,"piano":1];s.selectedStaves=[0,1,2]
 ok(s.expectedSelectedStaffCount==3 && s.profile==profile,"local 2+1 grouping leaves profile unchanged")
 s.assignSystemSelection()
 ok(s.errorMessage==nil,"actual Assign action accepts local divisi")
 let first=s.review!.overrides[0].systems[0]
 ok(first.bands.first{$0.partID=="voice"}!.candidateIDs==[0,1] && first.bands.first{$0.partID=="piano"}!.candidateIDs==[2],"actual Assign passes counts and maps successive physical staves")
 ok(s.correctionSystem==2 && s.systemStaffCounts==["voice":2,"piano":1] && s.systemBarCount.isEmpty,"next system keeps counts while clearing duration")
 s.systemStaffCounts=["voice":4,"piano":4];s.printedPartIDs=[];s.correctionSystem=1;s.loadSystemAssignment()
 ok(s.selectedStaves==[0,1,2] && s.printedPartIDs==["voice","piano"] && s.systemStaffCounts==["voice":2,"piano":1],"Load reconstructs actual saved divisi groups")
 let suggestion=ScoreSystemTemplateMatcher.Suggestion(pageIndex:0,systemIndex:1,candidateIDs:[3,4,5],presentPartIDs:["voice","piano"],templatePageIndex:0,templateSystemIndex:0,confidence:.sourceSupported,reasons:[],sourceBounds:[0,0.35,1,0.6],requiresMeasureCount:false,staffCounts:["voice":2,"piano":1])
 s.systemFirstBar="777";s.systemBarCount="88";s.selectTemplateSuggestion(suggestion)
 ok(s.selectedStaves==[3,4,5] && s.systemStaffCounts==suggestion.staffCounts && s.correctionSystem==2,"Show transfers selected staves and exact template grouping")
 ok(s.systemFirstBar.isEmpty && s.systemBarCount.isEmpty,"Show never copies a template's duration")
 s.assignSystemSelection();ok(s.errorMessage==nil && s.review!.overrides[0].systems[1].bands.first{$0.partID=="voice"}!.candidateIDs==[3,4],"Show then Assign preserves divisi")
 var silent=suggestion;silent.systemIndex=2;silent.candidateIDs=[6,7,8];silent.presentPartIDs=["piano"];silent.staffCounts=["piano":3];silent.requiresMeasureCount=true
 s.selectTemplateSuggestion(silent);s.systemStaffCounts["voice"]=4;s.systemFirstBar="20";s.systemBarCount="5";s.assignSystemSelection()
 ok(s.errorMessage==nil,"unchecked stale count is filtered by actual Assign call")
 let third=s.review!.overrides[0].systems[2]
 ok(third.bands.first{$0.partID=="piano"}!.candidateIDs==[6,7,8] && third.omittedParts?.first?.partID=="voice" && third.barCount==5,"silent layout keeps actual grouped staves and explicit duration")
 s.correctionSystem=3;s.loadSystemAssignment()
 ok(s.printedPartIDs==["piano"] && s.systemStaffCounts==["piano":3] && s.systemBarCount=="5" && s.selectedStaves==[6,7,8],"Load excludes generated rest from printed roster and restores count")
 ok(s.profile==profile && s.review!.profile==profile,"all UI state transitions leave global profile exact")
 let b=ActualUIState(profile,initial);b.selectedSuggestions=[suggestion];let choices=b.makeChoices()
 ok(choices.count==1 && choices[0].staffCounts==["voice":2,"piano":1],"actual batch mapping includes staff counts")
 var seedSuggestion=suggestion;seedSuggestion.systemIndex=0;seedSuggestion.candidateIDs=[0,1,2];b.selectedSuggestions=[seedSuggestion]
 let applied=try ScoreSystemAssignmentBatch.applying(b.makeChoices(),to:initial)
 ok(applied.profile==profile && applied.overrides[0].systems[0].bands.first{$0.partID=="voice"}!.candidateIDs==[0,1],"batch UI mapping reaches native grouping without profile mutation")
 var changed=initial;changed.profile.parts[0].staffCount=2
 ok(!b.stillMatches(initial,changed),"profile change rejects stale matcher result")
 changed=initial;changed.overrides=s.review!.overrides
 ok(!b.stillMatches(initial,changed),"assignment change rejects stale matcher result")
 ok(!b.validNumber("",required:true,maximum:999) && b.validNumber("5",required:true,maximum:999),"silent-layout Apply remains gated by explicit valid duration")
 print("\\(checks) extracted UI state controls passed")
 }
}
'''
(w/'state.swift').write_text(head+methods+tests);(w/'extraction.json').write_text(json.dumps({'scope':'Original UI method bodies extracted without behavioral edits; private access removed for test invocation. No SwiftUI hosting or click automation is claimed.','sources':{str(v):hashlib.sha256(v.read_bytes()).hexdigest(),str(p):hashlib.sha256(p.read_bytes()).hexdigest()},'methods':records},indent=2)+'\n')
print(len(records),'actual method bodies extracted')
