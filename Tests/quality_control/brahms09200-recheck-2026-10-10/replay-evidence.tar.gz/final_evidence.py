from pathlib import Path
import json,hashlib,tarfile,shutil
import pymupdf as f
from PIL import Image,ImageDraw,ImageFont
R=Path.cwd();W=R/'.build/brahms09200-recheck-2026-10-10';Q=R/'Tests/quality_control/brahms09200-recheck-2026-10-10';m=json.load(open(W/'parts/manifest.json'));source=f.open(R/m['source']);font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17)
def rimg(page,r):
 r=f.Rect(r);r &= page.rect;z=1120/r.width;p=page.get_pixmap(matrix=f.Matrix(z,z),clip=r,alpha=False);return Image.frombytes('RGB',(p.width,p.height),p.samples)
def cap(im,t):
 c=Image.new('RGB',(1120,im.height+26),'white');c.paste(im,(0,26));ImageDraw.Draw(c).text((4,3),t,font=font,fill='black');return c
def sheet(name,ims):
 c=Image.new('RGB',(1120,sum(i.height+5 for i in ims)),'#ddd');y=0
 for im in ims:c.paste(im,(0,y));y+=im.height+5
 c.save(Q/name)
for pg,sy in [(21,3),(23,4),(24,2),(22,1)]:
 p=m['parts'][0];ref=next(x for x in p['placements'] if x['sourcePage']==pg and x['system']==sy);rect=f.Rect(ref['sourceRect']);rect.y0-=10;ims=[cap(rimg(source[pg-1],rect),f'Brahms 09200 original source p{pg} s{sy}, Violin I reference')]
 for p in m['parts'][1:]:
  row=next(x for x in p['placements'] if x['sourcePage']==pg and x['system']==sy);rect=f.Rect(row['destinationRect']);pdf=f.open(W/'parts'/p['file'])
  for c in row['sourceMarkings']:rect|=f.Rect(c['destinationRect'])
  rect.y0-=5;rect.y1+=5;ims.append(cap(rimg(pdf[row['outputPage']-1],rect),f"Current native Auto: {p['name']} output p{row['outputPage']}"))
 sheet(f'direction-p{pg:02d}s{sy}.png',ims)
# Preserve replay inputs, output geometry and current source snapshot; PDFs remain in scratch.
a=W/'evidence';a.mkdir(exist_ok=True)
for name in ['worker.swift','audit.py','cross93521.py','review_new93521.py','review_seven_trims.py','final93521_details.py','final_cross93521_receipt.py','final_evidence.py','profile.json','inventory.json','plan.json','summary.json','native-auto.log','suggested-source-header.json']:
 if (W/name).exists():shutil.copy2(W/name,a/name)
for p in (R/'Partsmith/Core').rglob('*.swift'):
 d=a/p.relative_to(R);d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
for p in [R/'tools/export_score_plan.swift',R/'tools/review_score_output.py']:
 d=a/p.relative_to(R);d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
for name in ['manifest.json','plan.json']:
 d=a/'parts'/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(W/'parts'/name,d)
proj=next((W/'parts').glob('*.partsmithproject/project.json'));shutil.copy2(proj,a/'parts'/'project.json')
files={str(p.relative_to(a)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(a.rglob('*')) if p.is_file()}
(Q/'replay-archive-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
with tarfile.open(Q/'replay-evidence.tar.gz','w:gz') as t:
 for p in sorted(a.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(a)))
with tarfile.open(Q/'replay-evidence.tar.gz') as t:
 for name,sha in files.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha
print('Archived',len(files),'members; read-back verified')
