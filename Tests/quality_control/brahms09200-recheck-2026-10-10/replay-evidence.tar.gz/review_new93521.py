from pathlib import Path
import json,hashlib
import pymupdf as f
from PIL import Image,ImageDraw,ImageFont
W=Path('.build/brahms-recheck-2026-10-10/assisted-cue-correction');Q=Path('Tests/quality_control/brahms09200-recheck-2026-10-10/cross93521')
source=f.open('output/pdf/auto-qc-2026-10-03/brahms-quartet-93521-viola-in-tempo-repair/rectified-review-source.pdf')
manifest=json.load(open(W/'placements.json'));baseline=json.load(open('.build/brahms-recheck-2026-10-10/assisted-reexport/placements.json'));adds=json.load(open('Tests/quality_control/brahms-recheck-2026-10-10/manual-cue-additions.json'))['additions'];font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',14)
byband={};pdfs={};receipt=[]
approved=json.load(open('output/pdf/auto-qc-2026-10-04/brahms-quartet-93521-reviewed-trims/manifest.json'))['parts']
for p,b,expected in zip(manifest,baseline,approved):
 assert p['name']==b['name'] and p['bandCount']==b['bandCount']==151
 assert all(max(abs(x-y) for x,y in zip(a['sourceRect'],e['sourceRect']))<1e-8 for a,e in zip(p['placements'],expected['placements']))
 pdf=f.open(W/p['file']);pdfs[p['name']]=pdf
 for a,old in zip(p['placements'],b['placements']):
  assert a['bandID']==old['bandID'] and a['sourcePage']==old['sourcePage']
  byband[a['bandID']]=(p,a)
 for pg,page in enumerate(pdf,1):
  items=[x['destinationRect'] for row in p['placements'] if row['outputPage']==pg for x in [{'destinationRect':row['destinationRect']}]+row['sourceMarkings']]
  assert all(f.Rect(r) in page.rect for r in items)
  items.sort(key=lambda x:x[1]);assert all(a[3]<=b[1]+1e-6 for a,b in zip(items,items[1:])),(p['name'],pg,'collision')
 assert len(pdf)==p['outputPages']

def box(page,r,scale):
 r=f.Rect(r);r.x0-=.7;r.x1+=.7;r.y0-=.7;r.y1+=.7
 pix=page.get_pixmap(matrix=f.Matrix(scale,scale),clip=r,alpha=False);return Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
def tile(im,label,w=270,h=151):
 im.thumbnail((w-8,h-24));t=Image.new('RGB',(w,h),'white');t.paste(im,(4,23));ImageDraw.Draw(t).text((4,3),label,font=font,fill='black');return t
rows=[]
for k in range(0,len(adds),3):
 group=adds[k:k+3];assert len(group)==3 and len({(x['oracleID'],tuple(x['sourceRect'])) for x in group})==1
 g=group[0];src=g['sourceRect'];tiles=[tile(box(source[g['sourcePage']-1],src,7),f'Source p{g["sourcePage"]} s{g["system"]}: {g["text"]}')]
 for x in group:
  p,row=byband[x['bandID']];assert row['sourcePage']==x['sourcePage']
  c=[c for c in row['sourceMarkings'] if max(abs(a-b) for a,b in zip(c['sourceRect'],src))<1e-8];assert len(c)==1
  c=c[0];actual=c['sourceRect'];ratio=(c['destinationRect'][2]-c['destinationRect'][0])/(actual[2]-actual[0]);assert abs((c['destinationRect'][3]-c['destinationRect'][1])/(actual[3]-actual[1])-ratio)<1e-5
  tiles.append(tile(box(pdfs[p['name']][row['outputPage']-1],c['destinationRect'],7/ratio),f'{p["name"]} out p{row["outputPage"]}'))
  receipt.append({'oracleID':x['oracleID'],'part':p['name'],'sourcePage':x['sourcePage'],'system':x['system'],'outputPage':row['outputPage'],'oracleSourceRect':src,'actualSourceRect':actual,'destinationRect':c['destinationRect']})
 can=Image.new('RGB',(1080,151),'#ddd')
 for i,t in enumerate(tiles):can.paste(t,(270*i,0))
 rows.append(can)
for k in range(0,len(rows),8):
 can=Image.new('RGB',(1080,len(rows[k:k+8])*156),'#ddd')
 for i,r in enumerate(rows[k:k+8]):can.paste(r,(0,i*156))
 can.save(Q/f'added-cues-{k+1:02d}-{min(len(rows),k+8):02d}.png')
(Q/'assisted-added-cue-receipt.json').write_text(json.dumps({'sourceHash':hashlib.sha256(Path(source.name).read_bytes()).hexdigest(),'mode':'independent crossreview: assisted corrections, not fresh Auto','all604MainSourceCropRectanglesMatchLatestApprovedOct4Project':True,'allCopiedAndMusicRectanglesWithinOutputPages':True,'allOutputRectanglesWithoutVerticalCollisions':True,'newCueDestinations':receipt},indent=2)+'\n')
print('Reviewed destination bindings',len(receipt),'groups',len(rows))
