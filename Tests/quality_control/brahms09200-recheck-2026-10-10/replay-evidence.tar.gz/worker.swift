import AppKit
import Combine
import CryptoKit
import Foundation
import PDFKit

struct Inventory: Codable {
    var source: String
    var sourceSHA256: String
    var rectifications: [PageRectification]
    var pages: [ScorePageAnalysis]
}
@main enum Recheck {
    static let out = URL(fileURLWithPath: ".build/brahms09200-recheck-2026-10-10")
    static func write<T: Encodable>(_ value: T, _ name: String) throws {
        let e = JSONEncoder(); e.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        try e.encode(value).write(to: out.appendingPathComponent(name), options: .atomic)
    }
    static func main() throws {
        let path = "sample_scores/medium_skewed/05_brahms_string_quartet_no3_op67_imslp_09200.pdf"
        let data = try Data(contentsOf: URL(fileURLWithPath: path))
        let hash = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        precondition(hash == "ff883e06db2bc69c5de0c45fa447795201805ecf7210b76c50168b64f0570689")
        let profile = try JSONDecoder().decode(ScoreExtractionProfile.self, from: Data(contentsOf: out.appendingPathComponent("profile.json")))
        let doc = PartsmithDocument(sourcePDFData: data)
        doc.project.pageCount = doc.pdfDocument!.pageCount
        doc.saveScoreProfile(profile)
        let original = doc.project
        let start = Date()
        var complete = false, result: ScoreDetectionReview?
        let observer = doc.$scoreDetectionProgress.sink { p in
            guard let p else { return }
            print("\(p.directionPhase?.rawValue ?? "staves") \(p.completedPages)/\(p.totalPages)")
            fflush(stdout)
        }
        defer { observer.cancel() }
        doc.detectScore(profile: profile, findSourceHeader: true, copySharedDirections: true) {
            result = $0; complete = true
        }
        let deadline = Date().addingTimeInterval(900)
        while !complete && Date() < deadline { RunLoop.main.run(until: Date().addingTimeInterval(0.01)) }
        guard let review = result, complete else { fatalError("Auto did not complete") }
        precondition(doc.project == original)
        precondition(review.plan.canApply)
        try write(Inventory(source: URL(fileURLWithPath: path).path, sourceSHA256: hash,
                            rectifications: review.rectifications, pages: review.analyses), "inventory.json")
        try write(review.plan, "plan.json")
        try write(review.suggestedSourceHeader, "suggested-source-header.json")
        let summary: [String: String] = ["sourceSHA256": hash, "parts": String(profile.parts.count),
            "sourcePages": String(review.analyses.count), "bands": String(review.plan.bands.count),
            "copies": String(review.plan.bands.reduce(0) { $0 + $1.sourceMarkings.count }),
            "issues": String(review.directionIssues.count), "elapsedSeconds": String(Date().timeIntervalSince(start)),
            "projectUnchanged": String(doc.project == original), "canApply": String(review.plan.canApply),
            "rectifications": String(review.rectifications.count)]
        try write(summary, "summary.json")
        for issue in review.directionIssues { print("ISSUE page\(issue.pageIndex + 1): \(issue.message)") }
        print("DONE \(summary)")
    }
}
