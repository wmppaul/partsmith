from pathlib import Path
import pymupdf as f,json,hashlib
from PIL import Image,ImageDraw,ImageFont
W=Path('.build/brahms-recheck-2026-10-10');Q=Path('Tests/quality_control/brahms09200-recheck-2026-10-10/cross93521');Q.mkdir(exist_ok=True)
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',19)
old=json.load(open('output/pdf/auto-qc-2026-10-03/brahms-quartet-93521-viola-in-tempo-repair/manifest.json'))
source=f.open('output/pdf/auto-qc-2026-10-03/brahms-quartet-93521-viola-in-tempo-repair/rectified-review-source.pdf')
raw=f.open('sample_scores/medium_skewed/06_brahms_string_quartet_no3_op67_imslp_93521.pdf')
data={};stats={};imgs=[]
for mode in ['fresh-corrected-auto','fresh-raw-auto','assisted-reexport']:
 parts=json.load(open(W/mode/'placements.json'));project=json.load(open(next((W/mode).glob('*.partsmithproject/project.json'))))['project']
 if mode=='assisted-reexport':
  keys={p['name']:[(x['sourcePage'],x['system']) for x in p['placements']] for p in old['parts']}
 else:
  plan=json.load(open(W/mode/'plan.json'));names={p['id']:p['name'] for p in plan['parts']};keys={p['name']:[] for p in parts}
  for page in plan['pages']:
   for a in page['assignments']:keys[names[a['partID']]].append((page['pageIndex']+1,a['systemIndex']+1))
 oracle=json.load(open('Tests/quality_control/brahms93521/shared-directions-corrected.json'));expected=[(x['pageNumber'],i+1) for x in oracle['coverage'] for i in range(x['systemsReviewed'])]
 assert len(project['bands'])==604 and len(parts)==4
 hashes={}
 for p in parts:
  pdf=f.open(W/mode/p['file']);assert len(p['placements'])==151 and len(pdf)==p['outputPages'];assert keys[p['name']]==expected
  hashes[p['file']]=hashlib.sha256((W/mode/p['file']).read_bytes()).hexdigest()
  for row in p['placements']:
   d=row['destinationRect'];s=row['sourceRect'];assert f.Rect(d) in pdf[row['outputPage']-1].rect
   assert abs((d[2]-d[0])/(s[2]-s[0])-(d[3]-d[1])/(s[3]-s[1]))<1e-7
  data[mode,p['name']]={(pg,sy):(pdf,row) for (pg,sy),row in zip(keys[p['name']],p['placements'])}
 stats[mode]={'systemsPerPart':151,'bands':604,'outputPages':{p['name']:p['outputPages'] for p in parts},'sha256':hashes,'orderCoverage':'all 151 source identities compared to independently source-reviewed coverage oracle'}

def render(page,rect,width=1160,bounds=None):
 rect=f.Rect(rect);rect &= page.rect
 pix=page.get_pixmap(matrix=f.Matrix(width/rect.width,width/rect.width),clip=rect,alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
 if bounds:
  d=ImageDraw.Draw(im)
  for y in [bounds[1],bounds[3]]:d.line((0,(y-rect.y0)*width/rect.width,im.width,(y-rect.y0)*width/rect.width),fill=(0,80,240),width=3)
 return im

def caption(im,text):
 can=Image.new('RGB',(1160,im.height+30),'white');can.paste(im,(0,30));ImageDraw.Draw(can).text((4,3),text,font=font,fill='black');return can

def out(mode,name,pg,sy):
 pdf,row=data[mode,name][pg,sy];rect=f.Rect(row['destinationRect'])
 for c in row['sourceMarkings']:rect |= f.Rect(c['destinationRect'])
 rect.y0-=6;rect.y1+=6
 return caption(render(pdf[row['outputPage']-1],rect),f'{mode}: {name}; source p{pg} s{sy}, output p{row["outputPage"]}')
def context(mode,name,pg,sy):
 pdf,row=data[mode,name][pg,sy];r=f.Rect(row['sourceRect']);r.y0-=9;r.y1+=9
 return caption(render(raw[pg-1] if mode=='fresh-raw-auto' else source[pg-1],r,bounds=row['sourceRect']),f'Source p{pg} s{sy} {name}; blue marks crop edges ({mode})')
def sheet(name,ims):
 can=Image.new('RGB',(1160,sum(x.height+6 for x in ims)),'#ddd');y=0
 for im in ims:can.paste(im,(0,y));y+=im.height+6
 can.save(Q/name)
sheet('viola-in-tempo-p08s2.png',[context('assisted-reexport','Viola',8,2),out('fresh-corrected-auto','Viola',8,2),out('assisted-reexport','Viola',8,2)])
sheet('viola-forte-p34s4.png',[context('fresh-corrected-auto','Viola',34,4),context('fresh-raw-auto','Viola',34,4),out('fresh-corrected-auto','Viola',34,4),out('fresh-raw-auto','Viola',34,4),out('assisted-reexport','Viola',34,4)])
for pg,sy,label in [(28,2,'navigation'),(28,3,'coda'),(6,3,'ending1'),(6,4,'ending2'),(37,2,'ending-pair')]:
 refrow=data['fresh-corrected-auto','Violin I'][pg,sy][1];rr=f.Rect(refrow['sourceRect']);rr.y0=max(0,rr.y0-12);rr.y1+=8
 ims=[caption(render(source[pg-1],rr),f'Upper source p{pg} s{sy}: Violin I reference')]
 if pg==28 and sy==2:ims.append(context('fresh-corrected-auto','Violoncello',pg,sy))
 ims.extend(out('fresh-corrected-auto',n,pg,sy) for n in ['Violin I','Violin II','Viola','Violoncello'])
 sheet(f'{label}-p{pg:02d}s{sy}.png',ims)
(Q/'structural-receipt.json').write_text(json.dumps(stats,indent=2)+'\n')
