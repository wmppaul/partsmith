exec(open('.build/brahms09200-recheck-2026-10-10/review_new93521.py').read())
old=json.load(open('output/pdf/auto-qc-2026-10-03/brahms-quartet-93521-viola-in-tempo-repair/manifest.json'));p=next(p for p in manifest if p['name']=='Viola');oldp=next(p for p in old['parts'] if p['id']=='viola')
rows=[]
for pg,sy in [(8,2),(34,4)]:
 i=next(i for i,x in enumerate(oldp['placements']) if x['sourcePage']==pg and x['system']==sy);row=p['placements'][i];pdf=pdfs['Viola'];r=f.Rect(row['destinationRect']);r.y0-=4;r.y1+=4
 z=1160/r.width;pix=pdf[row['outputPage']-1].get_pixmap(matrix=f.Matrix(z,z),clip=r,alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);t=Image.new('RGB',(1160,im.height+30),'white');t.paste(im,(0,30));ImageDraw.Draw(t).text((5,3),f'Final assisted cue corrections: Viola source p{pg} s{sy}, output p{row["outputPage"]}',font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17),fill='black');rows.append(t)
can=Image.new('RGB',(1160,sum(x.height+6 for x in rows)),'#ddd');y=0
for im in rows:can.paste(im,(0,y));y+=im.height+6
can.save(Q/'final-assisted-viola-repairs.png')
expected=[(x['pageNumber'],i+1) for x in json.load(open('Tests/quality_control/brahms93521/shared-directions-corrected.json'))['coverage'] for i in range(x['systemsReviewed'])]
mapband={x['bandID']:key for pp in manifest for key,x in zip(expected,pp['placements'])}
for x in adds:assert mapband[x['bandID']]==(x['sourcePage'],x['system'])
print('All 72 additions map to correct source system identity')
