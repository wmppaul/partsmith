from pathlib import Path
import json,hashlib,math
import pymupdf as fitz
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT=Path.cwd();W=ROOT/'.build/brahms09200-recheck-2026-10-10';Q=ROOT/'Tests/quality_control/brahms09200-recheck-2026-10-10'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,data):p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def inside(a,b,eps=.001):return a[0]<=b[0]+eps and a[1]<=b[1]+eps and a[2]>=b[2]-eps and a[3]>=b[3]-eps
manifest=json.loads((W/'parts/manifest.json').read_text());mapping=json.loads((ROOT/'Tests/full_scores/brahms-quartet-tight-map.json').read_text())
source=fitz.open(ROOT/manifest['source']);assert sha(Path(source.name))==mapping['sourceSHA256']==manifest['sourceSHA256']
lookup={(p['pageIndex']+1,s['systemIndex']+1,b['partID']):b for p in mapping['pages'] for s in p['systems'] for b in s['bands']}
expected=[(p['pageIndex']+1,s['systemIndex']+1) for p in mapping['pages'] for s in p['systems']]
parts=[];failures=[];fragments=[];outputImages=[]
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',15)
for part in manifest['parts']:
    pdf=fitz.open(W/'parts'/part['file']);placements=part['placements']
    assert [(p['sourcePage'],p['system']) for p in placements]==expected
    assert part['bandCount']==120 and len(pdf)==part['outputPages']
    issues=[];neighborLines=0;neighborBands=0;contexts=[]
    for p in placements:
        s,d=p['sourceRect'],p['destinationRect'];ref=lookup[p['sourcePage'],p['system'],part['id']]
        assert len(p['staffLineYs'])==1 and len(p['staffLineYs'][0])==5
        assert all(s[1]<=y<=s[3] for y in p['staffLineYs'][0])
        assert inside(list(pdf[p['outputPage']-1].rect),d)
        assert abs((d[2]-d[0])/(s[2]-s[0])-(d[3]-d[1])/(s[3]-s[1]))<1e-6
        pageMap=mapping['pages'][p['sourcePage']-1]
        neighborYs=[line[1] for sy in pageMap['systems'] for b in sy['bands'] if (sy['systemIndex']+1,b['partID'])!=(p['system'],part['id']) for line in b['staffLineRects']]
        retained=sum(s[1]<=y<=s[3] for y in neighborYs)
        if retained: neighborBands+=1;neighborLines+=retained
        for g in ref['protectedRegions']:
            if not inside(s,g['rect']):
                a=np.asarray(source[p['sourcePage']-1].get_pixmap(matrix=fitz.Matrix(4,4),clip=fitz.Rect(g['rect']),colorspace=fitz.csGRAY).samples,dtype=np.uint8) if False else None
                failures.append({'part':part['id'],'page':p['sourcePage'],'system':p['system'],'sourceRect':s,'guard':g['rect'],'description':g['description']})
        for g in ref.get('requiredSourceFragments',[]):
            if not any(inside(r,g['rect']) for r in [s]+[m['sourceRect'] for m in p['sourceMarkings']]):
                fragments.append({'part':part['id'],'page':p['sourcePage'],'system':p['system'],'kind':g['kind'],'description':g['description'],'rect':g['rect']})
        ctx=fitz.Rect(s);ctx.y0=max(0,ctx.y0-13);ctx.y1=min(source[p['sourcePage']-1].rect.height,ctx.y1+13)
        pix=source[p['sourcePage']-1].get_pixmap(matrix=fitz.Matrix(1.7,1.7),clip=ctx,alpha=False)
        image=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
        draw=ImageDraw.Draw(image)
        for y in [s[1],s[3]]:draw.line((0,(y-ctx.y0)*1.7,image.width,(y-ctx.y0)*1.7),fill=(0,90,230),width=2)
        canvas=Image.new('RGB',(image.width,image.height+23),'white');canvas.paste(image,(0,23));ImageDraw.Draw(canvas).text((5,2),f"{part['name']} source p{p['sourcePage']} s{p['system']} | output p{p['outputPage']}",font=font,fill='black')
        contexts.append(canvas)
    contextDir=W/'context'/part['id'];contextDir.mkdir(parents=True,exist_ok=True)
    for offset in range(0,len(contexts),10):
        group=contexts[offset:offset+10];sheet=Image.new('RGB',(max(i.width for i in group),sum(i.height for i in group)+len(group)*5),'#eeeeee');y=0
        for im in group:sheet.paste(im,(0,y));y+=im.height+5
        sheet.save(contextDir/f'systems-{offset+1:03d}-{offset+len(group):03d}.png')
    for index,page in enumerate(pdf):
        pix=page.get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
        im.thumbnail((459,660));can=Image.new('RGB',(459,683),'white');can.paste(im,(0,23));ImageDraw.Draw(can).text((5,2),f"{part['name']} output p{index+1}",font=font,fill='black');outputImages.append(can)
    parts.append({'id':part['id'],'name':part['name'],'sourceSystems':len(placements),'outputPages':len(pdf),'systemsPerOutputPage':part['systemsPerPage'],'copies':sum(len(p['sourceMarkings']) for p in placements),'staffHeightPoints':[(p['staffLineYs'][0][-1]-p['staffLineYs'][0][0])*(p['destinationRect'][2]-p['destinationRect'][0])/(p['sourceRect'][2]-p['sourceRect'][0]) for p in placements],'neighborStaffTopLinesRetained':neighborLines,'bandsContainingNeighborStaffTopLines':neighborBands,'sha256':sha(W/'parts'/part['file'])})
pagesDir=Q/'output-contact';pagesDir.mkdir(exist_ok=True)
for offset in range(0,len(outputImages),8):
    sheet=Image.new('RGB',(459*4,683*2),'#ddd')
    for j,im in enumerate(outputImages[offset:offset+8]):sheet.paste(im,((j%4)*459,(j//4)*683))
    sheet.save(pagesDir/f'pages-{offset+1:03d}-{min(len(outputImages),offset+8):03d}.png')
write(Q/'structure-and-guard-review.json',{'sourceSHA256':manifest['sourceSHA256'],'sourcePages':len(source),'expectedSystems':len(expected),'expectedPhysicalStaves':480,'parts':parts,'guardRectanglesNotFullyContained':failures,'requiredFragmentsNotFullyContained':fragments,'notes':['Source guard rectangles include a1–2point safety margin; noncontainment is a visual-review prompt, not proof of missing notation.','Neighbor metrics count another staff\'s top line, not individual neighboring notes.','Required shared fragments include printed bar numbers and rehearsal letters that current Auto does not fully propagate.']})
write(Q/'output-bindings.json',{str(p.relative_to(ROOT)):sha(p) for p in sorted((W/'parts').rglob('*')) if p.is_file()})
print('PARTS',[(p['id'],p['outputPages'],p['sourceSystems']) for p in parts]);print('GUARD PROMPTS',len(failures));print('SHARED PROMPTS',len(fragments));print('OUTPUT PAGES',len(outputImages))
