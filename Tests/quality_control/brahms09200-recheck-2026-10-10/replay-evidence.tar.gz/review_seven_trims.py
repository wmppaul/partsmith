from pathlib import Path
import json,hashlib
import pymupdf as f
from PIL import Image,ImageDraw,ImageFont
W=Path('.build/brahms-recheck-2026-10-10/assisted-cue-correction');Q=Path('Tests/quality_control/brahms09200-recheck-2026-10-10/cross93521')
old=json.load(open('.build/brahms-recheck-2026-10-10/assisted-reexport/placements.json'));parts=json.load(open(W/'placements.json'));approved=json.load(open('output/pdf/auto-qc-2026-10-04/brahms-quartet-93521-reviewed-trims/manifest.json'))['parts'];changes=json.load(open('output/pdf/auto-qc-2026-10-04/brahms-quartet-93521-reviewed-trims/proposed-edits-before-output.json'))['changes']
source=f.open('output/pdf/auto-qc-2026-10-04/brahms-quartet-93521-reviewed-trims/rectified-review-source.pdf');raw=f.open('sample_scores/medium_skewed/06_brahms_string_quartet_no3_op67_imslp_93521.pdf');by={x['bandID']:(p,x) for p in parts for x in p['placements']};prior={x['bandID']:x for p in old for x in p['placements']};declared={c['bandUUID']:c for c in changes};font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',17)
diff=[]
for p,b,t in zip(parts,old,approved):
 assert p['name']==b['name']==t['name'];assert len(p['placements'])==len(b['placements'])==len(t['placements'])==151
 for x,y,z in zip(p['placements'],b['placements'],t['placements']):
  assert x['bandID']==y['bandID'] and x['sourcePage']==y['sourcePage']==z['sourcePage']
  assert max(abs(a-b) for a,b in zip(x['sourceRect'],z['sourceRect']))<1e-8
  if x['sourceRect']!=y['sourceRect']:
   c=declared[x['bandID']];assert max(abs(a-b) for a,b in zip(x['sourceRect'],c['newRect']))<1e-8;diff.append(x['bandID'])
assert set(diff)==set(declared)
def render(page,r,edges=None):
 r=f.Rect(r);r &= page.rect;z=1160/r.width;pix=page.get_pixmap(matrix=f.Matrix(z,z),clip=r,alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
 if edges:
  d=ImageDraw.Draw(im)
  for color,ys in edges:
   for y in ys:d.line((0,(y-r.y0)*z,im.width,(y-r.y0)*z),fill=color,width=3)
 return im
def cap(im,label):
 c=Image.new('RGB',(1160,im.height+29),'white');c.paste(im,(0,29));ImageDraw.Draw(c).text((4,3),label,font=font,fill='black');return c
receipt=[]
for c in changes:
 p,row=by[c['bandUUID']];pg=c['sourcePage'];rr=f.Rect(c['oldRect']);rr.y0-=8;rr.y1+=8
 pdf=f.open(W/p['file']);r=f.Rect(row['destinationRect']);r.y0-=4;r.y1+=4
 ims=[cap(render(raw[pg-1],rr),f'Immutable original context: {c["id"]}; no crop boundaries on raw scan'),cap(render(source[pg-1],rr,[('#888888',[c['oldRect'][1],c['oldRect'][3]]),('#0055ff',[row['sourceRect'][1],row['sourceRect'][3]])]),f'Corrected source: old edges grey; final approved edges blue ({c["id"]})'),cap(render(pdf[row['outputPage']-1],r),f'Final actual native PDF: {p["name"]} output p{row["outputPage"]}')]
 sheet=Image.new('RGB',(1160,sum(im.height+6 for im in ims)),'#ddd');y=0
 for im in ims:sheet.paste(im,(0,y));y+=im.height+6
 sheet.save(Q/f'trim-{c["id"]}.png')
 receipt.append({'id':c['id'],'part':p['name'],'sourcePage':pg,'outputPage':row['outputPage'],'bandID':row['bandID'],'oldSourceRect':prior[row['bandID']]['sourceRect'],'finalSourceRect':row['sourceRect'],'approvedFrozenTargetEnvelope':c['frozenTargetEnvelope'],'sourceObligation':c['sourceObligation']})
(Q/'seven-trims-receipt.json').write_text(json.dumps({'originalSourceSHA256':hashlib.sha256(Path(raw.name).read_bytes()).hexdigest(),'correctedSourceSHA256':hashlib.sha256(Path(source.name).read_bytes()).hexdigest(),'all604SourceCropRectanglesMatchLatestApprovedOct4Project':True,'exactlySevenMainSourceEdgesDifferFromPreviousAssistedReexport':True,'bandIDsAndOrderUnchanged':True,'changes':receipt},indent=2)+'\n')
print('All604 current source rectangles match approved Oct4; seven declared trims rendered')
