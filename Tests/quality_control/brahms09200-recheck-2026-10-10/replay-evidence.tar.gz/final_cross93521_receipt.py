from pathlib import Path
import json,hashlib
R=Path.cwd();W=R/'.build/brahms-recheck-2026-10-10/assisted-cue-correction';Q=R/'Tests/quality_control/brahms09200-recheck-2026-10-10/cross93521'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.load(open(W/'placements.json'));old=json.load(open(R/'.build/brahms-recheck-2026-10-10/assisted-reexport/placements.json'))
original=R/'sample_scores/medium_skewed/06_brahms_string_quartet_no3_op67_imslp_93521.pdf';project=next(W.glob('*.partsmithproject'));assert digest(original)==digest(project/'source.pdf')=='662aabfdecb2d125151c984fe1dc866ea068668ee9bb74f23f286f552603c14a'
old_count=total_count=unchanged=changed=0
for part,base in zip(manifest,old):
 assert part['name']==base['name'] and len(part['placements'])==len(base['placements'])==151
 assert digest(W/part['file'])==part['sha256']
 for row,b in zip(part['placements'],base['placements']):
  assert row['bandID']==b['bandID'] and row['sourcePage']==b['sourcePage']
  if max(abs(x-y) for x,y in zip(row['sourceRect'],b['sourceRect']))<1e-8:unchanged+=1
  else:changed+=1
  total_count+=len(row['sourceMarkings']);old_count+=len(b['sourceMarkings'])
  for copy in b['sourceMarkings']:
   matches=[x for x in row['sourceMarkings'] if x['isBelow']==copy['isBelow'] and max(abs(a-b) for a,b in zip(x['sourceRect'],copy['sourceRect']))<1e-8]
   assert len(matches)==1
assert (unchanged,changed,old_count,total_count)==(597,7,42,114)
p=Q/'assisted-added-cue-receipt.json';data=json.load(open(p));assert len(data['newCueDestinations'])==72
for x in data['newCueDestinations']:assert max(abs(a-b) for a,b in zip(x['oracleSourceRect'],x['actualSourceRect']))<1e-8
bindings={str(path.relative_to(R)):digest(path) for path in [W/'placements.json',project/'project.json',project/'source.pdf',R/'Tests/quality_control/brahms-recheck-2026-10-10/manual-cue-additions.json',*[W/x['file'] for x in manifest]]}
data.update({'finalVersion':'approved Oct4 seven crop trims plus 72 assisted cue additions','originalSourceSHA256':digest(original),'sourceRectangleTolerancePoints':1e-8,'all72NewDestinationGlyphsVisuallyComparedTo24OriginalSourceRegions':True,'all72SourceSystemIdentitiesCheckedAgainstIndependentCoverage':True,'all604BandIDsAndSourcePageOrderMatchPreviousAssistedReexport':True,'unchangedMainCropsAgainstPreviousAssistedReexport':597,'approvedSingleEdgeMainCropChanges':7,'all42PriorCopySourceRectanglesAndAboveBelowFlagsPreserved':True,'totalSourceCopies':114,'outputPageCounts':[x['outputPages'] for x in manifest],'all7ChangedCropContextsAndActualOutputsVisuallyReviewed':True,'intendedTargetLossIdentifiedIn7TrimmedRows':False,'finalActualViolaP8S2InTempoDescenderAndP34S4ForteHookVisible':True,'fileBindingsSHA256':bindings,'scopeLimit':'Independent structural review covers all 78 output pages. Visual review covers all seven changed crop rows, every one of the 72 new cue destinations, 24 original cue regions, and two Viola repair hotspots. This reviewer did not visually inspect all 78 final pages or establish an exhaustive note-pixel oracle. Fresh Auto results remain separate.'})
p.write_text(json.dumps(data,indent=2)+'\n')
p=Q/'seven-trims-receipt.json';data=json.load(open(p));data.update({'allSevenOriginalCorrectedContextsAndFinalOutputRowsVisuallyReviewed':True,'intendedTargetLossIdentified':False,'partialNeighborInkStillRetained':True,'finalPDFAndGeometryBindingsSHA256':bindings,'scopeLimit':'Whole intended rows were inspected in immutable original and corrected source contexts and in final actual output; these are visually established obligations rather than per-pixel ownership masks.'});p.write_text(json.dumps(data,indent=2)+'\n')
print('Final independent 93521 crossreview bound:',unchanged,'unchanged crops,',changed,'approved trims,',total_count,'copies,',sum(x['outputPages'] for x in manifest),'pages')
