
// Test-only same-file extension: no production diagnostic or visibility changes.
extension ScoreSystemTemplateMatcher {
    static func independentBoundaryCancellationChecks() throws -> [[String: Any]] {
        var rows: [[String: Any]] = []
        for doubleRule in [false, true] {
            let width = 320, height = 300, firstX = 80
            var ink = [Bool](repeating: false, count: width * height)
            func mark(_ x: Int, _ y: Int) { ink[y * width + x] = true }
            let lineGroups: [[Double]] = [[60, 68, 76, 84, 92], [180, 188, 196, 204, 212]]
            for lines in lineGroups {
                for line in lines { for x in firstX...300 { mark(x, Int(line)) } }
                // Target ink in each clef patch; staff lines remain independently testable.
                for y in Int(lines[0] - 4)...Int(lines[4] + 4) {
                    for x in 90...94 { mark(x, y) }
                }
            }
            let ruleColumns = doubleRule ? Array(78...80) + Array(83...85) : Array(78...84)
            for x in ruleColumns { for y in 60...212 { mark(x, y) } }
            let raster = Raster(width: width, height: height, ink: ink)
            let members = lineGroups.enumerated().map { i, lines in
                StaffFeature(id: i, lines: lines, start: firstX, end: 300,
                             patch: [Bool](repeating: false, count: patchWidth * patchHeight))
            }
            var calls = 0
            guard let complete = boundaryAnchoredPatches(members, raster: raster, slope: 0,
                isCancelled: { calls += 1; return false }) else {
                throw NSError(domain: "BoundaryRegression", code: 1,
                              userInfo: [NSLocalizedDescriptionKey: "Uncancelled helper unexpectedly returned nil"])
            }
            guard complete.count == 2, complete.allSatisfy({ $0.boundaryPatchProven && $0.patch.contains(true) }),
                  zip(complete, members).allSatisfy({ $0.id == $1.id && $0.start == $1.start
                    && $0.end == $1.end && $0.lines == $1.lines }) else {
                throw NSError(domain: "BoundaryRegression", code: 2,
                              userInfo: [NSLocalizedDescriptionKey: "Source boundary was not proven or original geometry changed"])
            }
            guard calls > 40 else {
                throw NSError(domain: "BoundaryRegression", code: 3,
                              userInfo: [NSLocalizedDescriptionKey: "Fixture did not exercise phase scanning"])
            }
            var longest = 0.0
            for threshold in 1...calls {
                var polls = 0
                let start = Date()
                let cancelled = boundaryAnchoredPatches(members, raster: raster, slope: 0,
                    isCancelled: { polls += 1; return polls >= threshold })
                longest = max(longest, Date().timeIntervalSince(start))
                guard cancelled == nil, polls == threshold else {
                    throw NSError(domain: "BoundaryRegression", code: threshold,
                                  userInfo: [NSLocalizedDescriptionKey: "Cancellation leaked partial staff results at checkpoint \(threshold)"])
                }
            }
            rows.append(["fixture": doubleRule ? "double source boundary" : "thick source boundary",
                         "provenStaffPatches": complete.count, "sourceGeometryUnchanged": true,
                         "cancellationCheckpointsExercised": calls,
                         "everyCancellationReturnedNil": true, "longestCancelledRunSeconds": longest])
        }
        return rows
    }
}
