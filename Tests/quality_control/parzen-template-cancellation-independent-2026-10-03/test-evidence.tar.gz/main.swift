import Foundation
import PDFKit

struct InputCase: Decodable {
    var sourcePath: String
    var pages: [ScorePageAnalysis]
    var profile: ScoreExtractionProfile
    var overrides: [ScorePageOverride]
}

@main struct IndependentCancellationRegression {
    static func main() throws {
        let input = try JSONDecoder().decode([InputCase].self,
            from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))[0]
        let privateRows = try ScoreSystemTemplateMatcher.independentBoundaryCancellationChecks()
        let pdf = PDFDocument(url: URL(fileURLWithPath: input.sourcePath))!
        let selectedPages = [1, 3, 5] // Two reviewed source systems plus one known unreviewed match.
        let pages = input.pages.filter { selectedPages.contains($0.pageIndex) }
        let overrides = input.overrides.filter { selectedPages.contains($0.pageIndex) }
        var images: [Int: CGImage] = [:]
        for page in pages { images[page.pageIndex] = NativeScorePageAnalyzer.render(pdf.page(at: page.pageIndex)!) }
        let baseline = ScoreSystemTemplateMatcher.suggest(pages: pages, profile: input.profile,
            reviewedOverrides: overrides, imageForPage: { images[$0] })
        guard !baseline.cancelled, baseline.suggestions.count == 1,
              baseline.suggestions.first?.pageIndex == 5 else {
            throw NSError(domain: "PublicRegression", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Expected real-source page6 match not established"])
        }
        var imageRequests = 0, cancellationRequested = false
        let start = Date()
        let cancelled = ScoreSystemTemplateMatcher.suggest(pages: pages, profile: input.profile,
            reviewedOverrides: overrides, imageForPage: { index in
                imageRequests += 1
                // Page2 has already been analyzed; cancellation arrives while page4 is requested.
                if imageRequests == 2 { cancellationRequested = true }
                return images[index]
            }, isCancelled: { cancellationRequested })
        guard cancelled.cancelled, cancelled.suggestions.isEmpty, imageRequests == 2 else {
            throw NSError(domain: "PublicRegression", code: 2,
                          userInfo: [NSLocalizedDescriptionKey: "Public cancellation returned partial proposals or kept scanning"])
        }
        let output: [String: Any] = ["status": "pass", "privateBoundaryChecks": privateRows,
            "publicSuggest": ["sourcePages": selectedPages.map { $0 + 1 }, "baselineSuggestions": baseline.suggestions.count,
                "cancellationAfterCompletedPage": 2, "imageRequests": imageRequests,
                "cancelled": cancelled.cancelled, "returnedSuggestions": cancelled.suggestions.count,
                "elapsedSeconds": Date().timeIntervalSince(start)],
            "productionMutations": false]
        let data = try JSONSerialization.data(withJSONObject: output, options: [.prettyPrinted, .sortedKeys])
        FileHandle.standardOutput.write(data); print("")
    }
}
