import Foundation
@main enum Bind {
 struct Inventory:Codable { var source:String;var sourceSHA256:String;var pages:[ScorePageAnalysis] }
 static func main() throws {
  let a=CommandLine.arguments, d=JSONDecoder()
  var inventory=try d.decode(Inventory.self,from:Data(contentsOf:URL(fileURLWithPath:a[1])))
  let profile=try d.decode(ScoreExtractionProfile.self,from:Data(contentsOf:URL(fileURLWithPath:a[2])))
  let overrides=try d.decode([ScorePageOverride].self,from:Data(contentsOf:URL(fileURLWithPath:a[3])))
  for pi in inventory.pages.indices {
   let page=inventory.pages[pi]
   let plan=ScoreExtractionPlanner.plan(pages:inventory.pages,profile:profile,overrides:overrides)
   for hi in (page.sharedHeadings ?? []).indices {
    let binding=ScoreExtractionPlanner.headingRecognitionBinding(page:page,plan:plan,anchorStaffID:page.sharedHeadings![hi].anchorStaffID)
    precondition(binding != nil)
    inventory.pages[pi].sharedHeadings![hi].recognitionBinding=binding
   }
  }
  let plan=ScoreExtractionPlanner.plan(pages:inventory.pages,profile:profile,overrides:overrides)
  precondition(plan.canApply && plan.bands.count==96)
  let voiceIntro=plan.bands.first{$0.pageIndex==0 && $0.systemIndex==0 && $0.partID=="voice"}!
  precondition(voiceIntro.generatedRest?.barCount==3 && voiceIntro.sourceMarkings.count==1)
  let e=JSONEncoder();e.outputFormatting=[.prettyPrinted,.sortedKeys]
  try e.encode(inventory).write(to:URL(fileURLWithPath:a[4]))
  print("Bound source headings to all reviewed printed/silent recipients; 96 complete items.")
 }
}
