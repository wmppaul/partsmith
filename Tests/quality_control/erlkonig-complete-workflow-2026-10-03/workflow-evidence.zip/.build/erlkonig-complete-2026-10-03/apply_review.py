from pathlib import Path
import json

work = Path(__file__).resolve().parent
baseline = json.loads((work / 'parts/manifest.json').read_text())
overrides = json.loads((work / 'overrides.json').read_text())
inventory = json.loads((work / 'inventory-unbound.json').read_text())
placements = {p['id']: p for part in baseline['parts'] for p in part['placements']}
changes = []

def edge(identifier, index, value, reason):
    old = placements[identifier]
    rect = old['sourceRect'].copy()
    rect[index] = value
    page = next(p for p in overrides if p['pageIndex'] == old['sourcePage'] - 1)
    system = next(s for s in page['systems'] if s['systemIndex'] == old['system'] - 1)
    band = next(b for b in system['bands'] if b['partID'] == identifier.split('-')[-1])
    band['rect'] = rect
    changes.append({'id': identifier, 'before': old['sourceRect'], 'after': rect, 'reason': reason})

edge('p1-s1-piano', 1, 136.5, 'Exclude sliced work-number header while preserving complete opening tempo and quarter-note stem.')
edge('p4-s4-piano', 3, 816.5, 'Retain the independently source-measured diminuendo, whose stroke envelope ends at 814.9606159627438 points.')
obligations = json.loads((work / 'independent-review/voice-top-source-obligations.json').read_text())
for obligation in obligations['rows']:
    identifier = f"p{obligation['page']}-s{obligation['system']}-voice"
    edge(identifier, 1, obligation['minimalConservativeCropTop'],
         'Remove large previous-piano fragments while preserving printed measure number, clef, key, notes and slurs with a one-point upper margin against independently frozen original-source ink.')

tempo = inventory['pages'][0]['sharedHeadings'][0]
assert 'Schnell' in tempo['recognizedText']
rect = [121.6, 136.5, 220.1, 155.5]
page = inventory['pages'][0]
changes.append({'id': 'p1-s1-Schnell-copy', 'beforeNormalized': tempo['bounds'], 'after': rect,
                'reason': 'Original source ink starts at 138 and ends at 153.3 points; a blank gap ends before unrelated piano ink at 158.5. Includes the complete quarter-note stem.'})
tempo['bounds'] = [rect[0] / page['pageWidth'], rect[1] / page['pageHeight'],
                   rect[2] / page['pageWidth'], rect[3] / page['pageHeight']]
for name, value in [('reviewed-overrides.json', overrides), ('reviewed-inventory-unbound.json', inventory), ('manual-corrections.json', changes)]:
    (work / name).write_text(json.dumps(value, indent=2) + '\n')
print('Applied five source crop corrections and one complete tempo-copy correction; baseline preserved.')
