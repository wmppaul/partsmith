from pathlib import Path
import json,hashlib,pymupdf
root=Path.cwd();work=root/'.build/erlkonig-complete-2026-10-03'
record=next(r for r in json.loads((root/'.build/variable-profile-audit-2026-10-03/source-roster.json').read_text()) if 'erlkonig' in r['id'])
source=root/record['sourcePath'];assert hashlib.sha256(source.read_bytes()).hexdigest()==record['sourceSHA256']
inventory=json.loads((root/record['nativeInventoryPath']).read_text());pdf=pymupdf.open(source)
profile=json.loads((root/record['profilePath']).read_text());parts={p['id']:p for p in profile['parts']}
systems=[];overrides=[]
for pi,rosters in enumerate(record['sourcePageSystems']):
    page=inventory['pages'][pi];staves=sorted(page['staves'],key=lambda s:s['staffLineFractions'][0]);offset=0
    correction={'pageIndex':pi,'reason':'Instrument roster read on every original page; initial silent vocal bars counted from printed system numbers.','systems':[]}
    for si,roster in enumerate(rosters):
        first=staves[offset];top=first['staffLineFractions'][0]*page['pageHeight']
        numbers=[(int(w[4]),list(w[:4])) for w in pdf[pi].get_text('words') if w[4].isdigit() and w[0]<85 and 0<top-w[3]<15]
        if pi==0 and si==0:firstbar=1;assert not numbers
        else:assert len(numbers)==1,(pi,si,numbers);firstbar=numbers[0][0]
        bands=[]
        for part in roster:
            ids=[s['id'] for s in staves[offset:offset+parts[part]['staffCount']]];offset+=len(ids)
            bands.append({'partID':part,'candidateIDs':ids})
        spec={'systemIndex':si,'bands':bands,'omittedParts':[{'partID':part,'reason':'Vocal staff omitted during the printed piano introduction.'} for part in parts if part not in roster],'startBarNumber':firstbar}
        correction['systems'].append(spec)
        systems.append({'page':pi+1,'system':si+1,'firstBar':firstbar,'top':top,'roster':roster,'bands':bands,'printedNumber':numbers,'spec':spec})
    assert offset==len(staves)
    overrides.append(correction)
for i,s in enumerate(systems):
    s['barCount']=(systems[i+1]['firstBar'] if i+1<len(systems) else 149)-s['firstBar']
    assert 1<=s['barCount']<=4
    s.pop('spec')['barCount']=s['barCount']
assert len(systems)==48 and sum(s['barCount'] for s in systems[:4])==12 and systems[-1]['firstBar']==145
headings=[]
for pi in [0,9,10]:
    for b in pdf[pi].get_text('dict')['blocks']:
        for line in b.get('lines',[]):
            txt=''.join(s['text'] for s in line['spans'])
            if not any(word in txt for word in ['Schnell.','accelerando','Recit.','Andante.']):continue
            system=next(s for s in systems if s['page']==pi+1 and s['system']==(1 if pi==0 else 3))
            x0,y0,x1,y1=line['bbox'];r=[x0-1,y0-1,x1+1,y1+1]
            headings.append({'pageIndex':pi,'anchorStaffID':system['bands'][0]['candidateIDs'][0], 'bounds':[r[0]/pdf[pi].rect.width,r[1]/pdf[pi].rect.height,r[2]/pdf[pi].rect.width,r[3]/pdf[pi].rect.height], 'recognizedText':txt.replace('\x00','♩'),'reviewedSourceRect':r,'system':system['system']})
for item in headings: inventory['pages'][item['pageIndex']].setdefault('sharedHeadings',[]).append({k:item[k] for k in ['anchorStaffID','bounds','recognizedText']})
inventory.update(source=str(source),sourceSHA256=record['sourceSHA256'])
for name,obj in [('inventory-unbound.json',inventory),('profile.json',profile),('overrides.json',overrides),('source-reviewed-map.json',{'source':str(source),'sourceSHA256':record['sourceSHA256'],'systems':systems,'headings':headings,'finalBarCountEvidence':'Original PDF page11 voice system145 has vertical measure boundaries x216.43,368.32,478.39,547.51/549.87; final two strokes form a double bar. Four final measures145–148.'})]:
    (work/name).write_text(json.dumps(obj,indent=2)+'\n')
print('48 reviewed systems, bars1–148, four 3-bar omitted vocal passages, four printed shared directions.')
