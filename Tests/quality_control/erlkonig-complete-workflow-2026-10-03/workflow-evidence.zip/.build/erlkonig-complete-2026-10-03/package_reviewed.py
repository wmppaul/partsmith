from pathlib import Path
import hashlib
import json
import shutil
import zipfile
import pymupdf

root = Path.cwd()
work = root / '.build/erlkonig-complete-2026-10-03'
out = root / 'output/pdf/auto-qc-2026-10-03/erlkonig-reviewed-draft'
out.mkdir(parents=True, exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((work / 'reviewed-parts/manifest.json').read_text())
plan = json.loads((work / 'reviewed-parts/plan.json').read_text())
assert sha(Path(manifest['source'])) == manifest['sourceSHA256']
bands = [b for page in plan['pages'] for b in page['assignments']]
assert len(bands) == 96 and all(not p['unresolvedReasons'] for p in plan['pages'])
coverage = {}
for part in manifest['parts']:
    owned = [b for b in bands if b['partID'] == part['id']]
    bars = [n for b in owned for n in range(b['startBarNumber'], b['startBarNumber'] + b['barCount'])]
    assert bars == list(range(1, 149)) and len(owned) == 48
    assert len(pymupdf.open(work / 'reviewed-parts' / part['file'])) == part['outputPages']
    coverage[part['id']] = {'systems': 48, 'bars': [1, 148], 'pages': part['outputPages'],
        'musicCrops': sum(b['kind'] == 'music' for b in owned),
        'generatedRestBars': sum(b.get('generatedRest', {}).get('barCount', 0) for b in owned)}
for p in (work / 'reviewed-parts').iterdir():
    if p.is_dir(): shutil.copytree(p, out / p.name, dirs_exist_ok=True)
    else: shutil.copy2(p, out / p.name)
assert sha(out / manifest['project'] / 'source.pdf') == manifest['sourceSHA256']
for name in ['profile.json', 'reviewed-overrides.json', 'reviewed-inventory.json', 'source-reviewed-map.json', 'manual-corrections.json']:
    shutil.copy2(work / name, out / name)
review = {'status': 'complete assisted draft; performance layout and opening Voice meter unresolved',
    'sourceSHA256': manifest['sourceSHA256'], 'coverage': coverage,
    'initialization': 'Manual source-derived identity/measure map across all 48 systems; saved native staff inventory reused. This is not new automatic identity recognition or a fresh whole-score scan.',
    'renderer': manifest['renderer'],
    'corrections': json.loads((work / 'manual-corrections.json').read_text()),
    'review': 'Independent reviewer examined all 11 original pages, 48 paired source/output systems and initial 13 output pages; after corrections, all six changed pages and source guards were rechecked. Root viewed all 12 final pages and six corrected strips. Six unchanged Piano pages are pixel-identical to the reviewed baseline.',
    'remaining': ['Voice opening generated rests lack the source common-time meter indication.',
                  'Four separate three-bar vocal rest rows should eventually combine into a twelve-bar rest.',
                  'All three Voice page turns split phrases or pickups; Piano is continuously playing across turns.',
                  'Small neighboring note/line fragments and cropped vocal text remain; this is not clean isolation.'],
    'pdfSHA256': {part['file']: sha(out / part['file']) for part in manifest['parts']}}
(out / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
(out / 'README.md').write_text('''# Erlkönig — complete assisted draft

Both parts cover all 148 measures: Voice has 4 pages and Piano has 8. Open either PDF to view it, or open the `.partsmithproject` in Partsmith to edit the crops and layout. The original score is embedded in that project.

The 48 systems were assigned from source review. Native Partsmith then built the parts. Five crop edges and the opening tempo copy were corrected against the original, including a missing piano diminuendo. Three oversized vocal crops were tightened without excluding the intended notation. These are reviewed manual corrections, not a claim that Auto independently found the instrument identities or these crop fixes.

This remains a draft: the vocal introduction needs its common-time indication; its twelve silent bars currently occupy four separate rest rows. The three vocal page turns split phrases or pickups, and the piano plays continuously across its turns. Small neighboring fragments and cropped vocal words remain. See `review.json` for the exact scope and corrections.

`profile.json`, `reviewed-overrides.json` and `reviewed-inventory.json` preserve the initialization. `source-reviewed-map.json` records the initial source map; `manual-corrections.json` records the later crop and tempo changes. The source PDF is unchanged.
''')
files = {str(p.relative_to(out)): sha(p) for p in out.rglob('*') if p.is_file() and p.name not in ['files.sha256.json', 'Erlkonig-complete-reviewed-draft.zip']}
(out / 'files.sha256.json').write_text(json.dumps(files, indent=2) + '\n')
archive = out / 'Erlkonig-complete-reviewed-draft.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, 9) as z:
    for rel in files: z.write(out / rel, rel)
    z.write(out / 'files.sha256.json', 'files.sha256.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for rel, expected in files.items(): assert hashlib.sha256(z.read(rel)).hexdigest() == expected
print(json.dumps({'output': str(out), 'coverage': coverage, 'archiveSHA256': sha(archive), 'verifiedMembers': len(files) + 1}, indent=2))
