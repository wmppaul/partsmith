import Foundation

struct ScoreDirectionAssignment: Equatable {
    var systemIndex: Int
    var partID: String
    var candidateIDs: [Int]
    var kind: String
}

struct ScoreDirectionPageBinding {
    var profile: ScoreExtractionProfile
    var staves: [ScoreObservedStaff]
    var assignments: [ScoreDirectionAssignment]
    var ignoredCandidateIDs: [Int]
    var automaticMarkings: [String: [ScoreSourceMarking]]
    var automaticEndingMarkings: [String: [String: [ScoreSourceMarking]]] = [:]
}

extension ScoreDetectionReview {
    enum DirectionEditError: LocalizedError {
        case unavailableMarking
        var errorDescription: String? {
            "This copied direction is no longer available. Select it again in the current review."
        }
    }

    mutating func removeSourceMarking(from bandID: String, at index: Int) throws {
        guard let band = plan.bands.first(where: { $0.id == bandID }),
              band.sourceMarkings.indices.contains(index),
              let page = analyses.first(where: { $0.pageIndex == band.pageIndex }),
              let pagePlan = plan.pages.first(where: { $0.pageIndex == band.pageIndex }),
              pagePlan.unresolvedReasons.isEmpty, excludedPageReasons[band.pageIndex] == nil else {
            throw DirectionEditError.unavailableMarking
        }
        var correction = ScoreSystemAssignment.pageOverride(page: page, pagePlan: pagePlan,
            existingOverride: overrides.first { $0.pageIndex == page.pageIndex })
        guard let system = correction.systems.firstIndex(where: { $0.systemIndex == band.systemIndex }) else {
            throw DirectionEditError.unavailableMarking
        }
        var markings = band.sourceMarkings
        markings.remove(at: index)
        let rectangles = markings.map {
            [$0.leftFraction * page.pageWidth, $0.topFraction * page.pageHeight,
             (1 - $0.rightFraction) * page.pageWidth, $0.bottomFraction * page.pageHeight]
        }
        let below = markings.map { $0.isBelow == true }
        if band.generatedRest != nil {
            guard let omitted = correction.systems[system].omittedParts?.firstIndex(where: { $0.partID == band.partID }) else {
                throw DirectionEditError.unavailableMarking
            }
            correction.systems[system].omittedParts![omitted].sourceMarkings = rectangles
            correction.systems[system].omittedParts![omitted].sourceMarkingsBelow = below
        } else {
            guard let part = correction.systems[system].bands.firstIndex(where: { $0.partID == band.partID }) else {
                throw DirectionEditError.unavailableMarking
            }
            let removed = band.sourceMarkings[index]
            let removedPairs = Set((page.sharedEndings ?? []).filter { $0.sourceMarking == removed }.map(\.pairID))
            correction.systems[system].bands[part].automaticLocalEndingPairIDs?.removeAll { removedPairs.contains($0) }
            correction.systems[system].bands[part].sourceMarkings = rectangles
            correction.systems[system].bands[part].sourceMarkingsBelow = below
        }
        var proposal = self
        // Capture before materializing a list: the surviving automatic copies
        // still need to be invalidated if their source assignment changes later.
        proposal.captureDirectionBindings()
        proposal.overrides.removeAll { $0.pageIndex == page.pageIndex }
        proposal.overrides.append(correction)
        proposal.replan()
        guard proposal.plan.pages.first(where: { $0.pageIndex == page.pageIndex })?.unresolvedReasons.isEmpty == true else {
            throw DirectionEditError.unavailableMarking
        }
        self = proposal
    }

    mutating func invalidateAutomaticDirections(on pageIndex: Int) {
        captureDirectionBindings()
        clearAutomaticDirections(on: pageIndex)
        replan()
    }

    /// Capture ownership once, while the plan still represents the recognized
    /// layout. Crop edits are intentionally absent from this identity.
    mutating func captureDirectionBindings() {
        for page in analyses where directionBindings[page.pageIndex] == nil
            && (page.sharedHeadings != nil || page.sharedNavigation != nil || page.sharedEndings != nil) {
            guard let pagePlan = plan.pages.first(where: { $0.pageIndex == page.pageIndex }),
                  pagePlan.unresolvedReasons.isEmpty else { continue }
            let reviewedBands = overrides.first { $0.pageIndex == page.pageIndex }?.systems ?? []
            let automaticBands = pagePlan.assignments.filter { band in
                // An override supplied before recognition review is an explicit
                // manual choice. Later UI materialization is covered by this
                // already-captured binding, so automatic copies remain known.
                !reviewedBands.contains { system in
                    system.systemIndex == band.systemIndex && (system.bands.contains {
                        $0.partID == band.partID && $0.sourceMarkings != nil
                    } || (system.omittedParts ?? []).contains {
                        $0.partID == band.partID && $0.sourceMarkings != nil
                    })
                }
            }
            let automaticMarkings = Dictionary(uniqueKeysWithValues: automaticBands.map {
                ("\($0.systemIndex):\($0.partID)", $0.sourceMarkings)
            })
            var endingsByPair: [String: [String: [ScoreSourceMarking]]] = [:]
            if !(page.sharedEndings ?? []).isEmpty {
                var withoutEndings = page
                withoutEndings.sharedEndings = nil
                let otherPlan = ScoreExtractionPlanner.plan(pages: [withoutEndings], profile: profile,
                    overrides: overrides.filter { $0.pageIndex == page.pageIndex })
                for band in automaticBands {
                    let other = otherPlan.bands.first { $0.id == band.id }?.sourceMarkings ?? []
                    for ending in page.sharedEndings ?? [] where ending.isValid(on: page) {
                        let expected = ending.sourceMarking
                        let own = band.sourceMarkings.filter { $0 == expected && !other.contains($0) }
                        if !own.isEmpty {
                            endingsByPair[ending.pairID, default: [:]]["\(band.systemIndex):\(band.partID)"] = own
                        }
                    }
                }
            }
            directionBindings[page.pageIndex] = ScoreDirectionPageBinding(profile: profile, staves: page.staves,
                assignments: orderedDirectionAssignments(pagePlan.assignments.map {
                    .init(systemIndex: $0.systemIndex, partID: $0.partID, candidateIDs: $0.candidateIDs, kind: $0.kind)
                }), ignoredCandidateIDs: overrides.first { $0.pageIndex == page.pageIndex }?.ignoredCandidateIDs?.sorted() ?? [],
                automaticMarkings: automaticMarkings, automaticEndingMarkings: endingsByPair)
        }
    }

    func directionAssignments(on pageIndex: Int, plan: ScoreExtractionPlan) -> [ScoreDirectionAssignment] {
        if let correction = overrides.first(where: { $0.pageIndex == pageIndex }) {
            // Inspect the requested mapping even when its crop geometry is
            // temporarily invalid. A crop edit must not change mark ownership.
            return orderedDirectionAssignments(correction.systems.flatMap { system in
                system.bands.map {
                    ScoreDirectionAssignment(systemIndex: system.systemIndex, partID: $0.partID,
                        candidateIDs: $0.candidateIDs ?? [], kind: $0.kind ?? "music")
                } + (system.omittedParts ?? []).map {
                    ScoreDirectionAssignment(systemIndex: system.systemIndex, partID: $0.partID,
                        candidateIDs: [], kind: "generated-rest")
                }
            })
        }
        return orderedDirectionAssignments((plan.pages.first { $0.pageIndex == pageIndex }?.assignments ?? []).map {
            .init(systemIndex: $0.systemIndex, partID: $0.partID, candidateIDs: $0.candidateIDs, kind: $0.kind)
        })
    }

    private func orderedDirectionAssignments(_ assignments: [ScoreDirectionAssignment]) -> [ScoreDirectionAssignment] {
        assignments.sorted {
            $0.systemIndex == $1.systemIndex ? $0.partID < $1.partID : $0.systemIndex < $1.systemIndex
        }
    }

    mutating func clearAutomaticDirections(on pageIndex: Int) {
        guard let index = analyses.firstIndex(where: { $0.pageIndex == pageIndex }) else { return }
        let page = analyses[index]
        let binding = directionBindings[pageIndex]
        let knownByBand = binding?.automaticMarkings ?? [:]
        let linkedPairs = Set((page.sharedEndings ?? []).map(\.pairID))
        let hadRecognition = page.sharedHeadings != nil || page.sharedNavigation != nil || page.sharedEndings != nil || directionBindings[pageIndex] != nil
        analyses[index].sharedHeadings = nil
        analyses[index].sharedNavigation = nil
        analyses[index].sharedEndings = nil
        directionBindings.removeValue(forKey: pageIndex)
        directionReferences.removeAll { $0.pageIndex == pageIndex }
        removeKnownAutomaticMarkings(on: page, binding: binding, knownByBand: knownByBand,
                                    endingPairIDs: linkedPairs)
        invalidateLinkedEndings(pairIDs: linkedPairs, except: pageIndex)
        if hadRecognition {
            let issue = ScoreDirectionIssue(pageIndex: pageIndex,
                message: "Directions need a new scan after changing this page's staff assignments. Existing music crops and manual markings are kept.")
            if !directionIssues.contains(issue) { directionIssues.append(issue) }
        }
    }
    /// Only linked ending copies are invalidated on the other source pages.
    /// Their independent headings/navigation/destinations retain their identity.
    private mutating func invalidateLinkedEndings(pairIDs: Set<String>, except pageIndex: Int) {
        guard !pairIDs.isEmpty else { return }
        for index in analyses.indices where analyses[index].pageIndex != pageIndex {
            let page = analyses[index]
            let affected = Set((page.sharedEndings ?? []).map(\.pairID)).intersection(pairIDs)
            guard !affected.isEmpty else { continue }
            let binding = directionBindings[page.pageIndex]
            var knownByBand: [String: [ScoreSourceMarking]] = [:]
            for pair in affected {
                for (band, values) in binding?.automaticEndingMarkings[pair] ?? [:] {
                    knownByBand[band, default: []] += values
                }
            }
            let retained = (page.sharedEndings ?? []).filter { !affected.contains($0.pairID) }
            analyses[index].sharedEndings = retained.isEmpty ? nil : retained
            removeKnownAutomaticMarkings(on: page, binding: binding, knownByBand: knownByBand,
                                        endingPairIDs: affected, preservingOtherCategories: true)
            if var updated = binding {
                for (band, values) in knownByBand {
                    updated.automaticMarkings[band]?.removeAll { values.contains($0) }
                }
                for pair in affected { updated.automaticEndingMarkings.removeValue(forKey: pair) }
                directionBindings[page.pageIndex] = updated
            }
            let issue = ScoreDirectionIssue(pageIndex: page.pageIndex,
                message: "Paired endings need a new scan because a linked source page's staff assignments changed. Other directions and manual markings are kept.")
            if !directionIssues.contains(issue) { directionIssues.append(issue) }
        }
    }

    private mutating func removeKnownAutomaticMarkings(on page: ScorePageAnalysis,
        binding: ScoreDirectionPageBinding?, knownByBand: [String: [ScoreSourceMarking]],
        endingPairIDs: Set<String>, preservingOtherCategories: Bool = false) {
        func removingOtherCategoryOwnership(from markings: [ScoreSourceMarking]) -> [ScoreSourceMarking] {
            guard preservingOtherCategories else { return markings }
            return markings.filter { marking in
                let bounds = [marking.leftFraction, marking.topFraction,
                              1 - marking.rightFraction, marking.bottomFraction]
                let sameBounds: ([Double]) -> Bool = { other in
                    other.count == 4 && zip(other, bounds).allSatisfy { abs($0 - $1) < 1e-9 }
                }
                let headings = page.sharedHeadings ?? []
                return !(marking.isBelow != true && (headings + ScoreSharedHeading.coalesced(headings)).contains { sameBounds($0.bounds) })
                    && !(page.sharedNavigation ?? []).contains {
                        sameBounds($0.bounds) && $0.isBelow == (marking.isBelow == true)
                    }
            }
        }
        func retainedIndices(rectangles: [[Double]], below: [Bool]?, known: [ScoreSourceMarking]) -> [Int] {
            rectangles.indices.filter { item in
                let rect = rectangles[item]
                guard rect.count == 4 else { return true }
                return !known.contains { marking in
                    let expected = [marking.leftFraction * page.pageWidth, marking.topFraction * page.pageHeight,
                        (1 - marking.rightFraction) * page.pageWidth, marking.bottomFraction * page.pageHeight]
                    return (marking.isBelow == true) == (below?[item] == true)
                        && zip(expected, rect).allSatisfy { abs($0 - $1) < 1e-7 }
                }
            }
        }
        for correction in overrides.indices where overrides[correction].pageIndex == page.pageIndex {
            for system in overrides[correction].systems.indices {
                for band in overrides[correction].systems[system].bands.indices {
                    var value = overrides[correction].systems[system].bands[band]
                    let systemIndex = overrides[correction].systems[system].systemIndex
                    // A reassignment may rename the recipient while retaining
                    // its candidate staves and copied rectangles. Follow that
                    // original staff ownership first. In particular, an
                    // authoritative manual list must not inherit another
                    // recipient's automatic-copy provenance after a swap.
                    let originalOwner = binding?.assignments.first {
                        !$0.candidateIDs.isEmpty
                            && $0.candidateIDs.sorted() == (value.candidateIDs ?? []).sorted()
                    }
                    let owner = originalOwner?.partID ?? value.partID
                    let originalSystem = originalOwner?.systemIndex ?? systemIndex
                    var known = knownByBand["\(originalSystem):\(owner)"] ?? []
                    // A local crop edit can restore an ending after the initial
                    // binding captured its suppressed state. Another edit may
                    // then materialize that copy into the override. Its explicit
                    // automatic provenance survives and must follow the original
                    // staff owner during reassignment or linked invalidation.
                    let automaticPairs = Set(value.automaticLocalEndingPairIDs ?? []).intersection(endingPairIDs)
                    // The marker belongs to the materialized copy, even if an
                    // assignment edit just replaced this band's staff IDs or
                    // part name. Matching only its new owner would lose that
                    // provenance and accidentally turn the old copy manual.
                    known += (page.sharedEndings ?? []).filter {
                        automaticPairs.contains($0.pairID)
                    }.map(\.sourceMarking)
                    known = removingOtherCategoryOwnership(from: known)
                    value.automaticLocalEndingPairIDs?.removeAll { endingPairIDs.contains($0) }
                    overrides[correction].systems[system].bands[band] = value
                    guard let rectangles = value.sourceMarkings,
                          value.sourceMarkingsBelow == nil || value.sourceMarkingsBelow?.count == rectangles.count else { continue }
                    let keep = retainedIndices(rectangles: rectangles, below: value.sourceMarkingsBelow, known: known)
                    value.sourceMarkings = keep.map { rectangles[$0] }
                    if let sides = value.sourceMarkingsBelow { value.sourceMarkingsBelow = keep.map { sides[$0] } }
                    overrides[correction].systems[system].bands[band] = value
                }
                for omitted in (overrides[correction].systems[system].omittedParts ?? []).indices {
                    var value = overrides[correction].systems[system].omittedParts![omitted]
                    guard let rectangles = value.sourceMarkings,
                          value.sourceMarkingsBelow == nil || value.sourceMarkingsBelow?.count == rectangles.count else { continue }
                    // Silence has no physical staff identity to follow. Its
                    // stable system/part identity binds automatic copies;
                    // explicit manual omission lists are absent from this map.
                    let systemIndex = overrides[correction].systems[system].systemIndex
                    let known = removingOtherCategoryOwnership(from: knownByBand["\(systemIndex):\(value.partID)"] ?? [])
                    let keep = retainedIndices(rectangles: rectangles, below: value.sourceMarkingsBelow, known: known)
                    value.sourceMarkings = keep.map { rectangles[$0] }
                    if let sides = value.sourceMarkingsBelow { value.sourceMarkingsBelow = keep.map { sides[$0] } }
                    overrides[correction].systems[system].omittedParts![omitted] = value
                }
            }
        }
    }

}
