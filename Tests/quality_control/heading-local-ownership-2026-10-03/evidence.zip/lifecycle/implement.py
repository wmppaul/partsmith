from pathlib import Path
w=Path('.build/heading-local-ownership-2026-10-03/Core')
p=w/'Detection/ScoreExtractionPlanner.swift';s=p.read_text()
s=s.replace('struct ScoreSharedHeading: Codable, Equatable {','''/// Produced only after a complete source-block match. Recipient evidence never
/// changes the original shared source rectangle or the musical staff crop.
struct ScoreHeadingLocalCounterpart: Codable, Equatable {
    var partID: String
    var anchorStaffID: Int
    var bounds: [Double]
    var inkBounds: [Double]
    var recognizedText: String
}

struct ScoreSharedHeading: Codable, Equatable {''')
s=s.replace('    var fragmentBounds: [[Double]]? = nil','''    var fragmentBounds: [[Double]]? = nil
    /// Optional legacy-compatible proof of a complete equivalent local block.
    var localCounterparts: [ScoreHeadingLocalCounterpart]? = nil''',1)
s=s.replace('            combined.inkBounds = nil','''            combined.inkBounds = nil
            combined.localCounterparts = nil''',1)
s=s.replace('    var automaticLocalEndingPairIDs: [String]? = nil','''    var automaticLocalEndingPairIDs: [String]? = nil
    /// Normalized exact global source boxes whose automatic local-heading
    /// decisions survive UI materialization. Nil leaves explicit lists manual.
    var automaticLocalHeadingBounds: [[Double]]? = nil''',1)
s=s.replace('''                            return ids.isEmpty ? nil : ids
                        }())''','''                            return ids.isEmpty ? nil : ids
                        }(), automaticLocalHeadingBounds: {
                            let boxes = ScoreSharedHeading.coalesced(page.sharedHeadings ?? []).filter { heading in
                                heading.recognitionBinding?.systemIndex == band.systemIndex
                                    && (heading.localCounterparts ?? []).contains { $0.partID == band.partID }
                            }.map(\\.bounds)
                            return boxes.isEmpty ? nil : boxes
                        }())''',1)
s=s.replace('planned.append(reviewedPage(page, profile: profile, override: correction))','planned.append(reviewedPage(page, profile: profile, override: correction, isCancelled: isCancelled))')
s=s.replace('planned.append(automaticPage(page, profile: profile))','planned.append(automaticPage(page, profile: profile, isCancelled: isCancelled))')
s=s.replace('private static func automaticPage(_ page: ScorePageAnalysis, profile: ScoreExtractionProfile) -> ScorePagePlan {','private static func automaticPage(_ page: ScorePageAnalysis, profile: ScoreExtractionProfile, isCancelled: () -> Bool = { false }) -> ScorePagePlan {')
s=s.replace('copySharedHeadings(page: page, to: &output.assignments)','copySharedHeadings(page: page, to: &output.assignments, isCancelled: isCancelled)',1)
a=s.index('    private static func copySharedHeadings(');b=s.index('    /// Retain printed pixels',a)
s=s[:a]+'''    private static func copySharedHeadings(page: ScorePageAnalysis, to bands: inout [ScorePlannedBand],
                                          preservingMarkings: Set<String> = [],
                                          automaticHeadingBounds: [String: [[Double]]] = [:],
                                          legacyReference: ScorePagePlan? = nil,
                                          isCancelled: () -> Bool = { false }) {
        let current = bands
        let recognized = legacyReference?.assignments ?? current
        for heading in ScoreSharedHeading.coalesced(page.sharedHeadings ?? []) {
            guard !isCancelled() else { return }
            guard ScoreSharedEnding.validBounds(heading.bounds) else { continue }
            // Refresh only copies carrying explicit automatic provenance. A
            // newly invalid initial mapping cannot preserve a stale automatic
            // copy merely because the UI materialized it into an explicit list.
            for i in bands.indices where automaticHeadingBounds[bands[i].id]?.contains(heading.bounds) == true {
                guard !otherDirectionOwns(heading.bounds, page: page, band: bands[i]) else { continue }
                bands[i].sourceMarkings.removeAll { headingMarking($0, equals: heading.bounds) }
            }
            let expected = heading.recognitionBinding ?? headingRecognitionBinding(page: page,
                bands: recognized, anchorStaffID: heading.anchorStaffID)
            let actual = headingRecognitionBinding(page: page, bands: current, anchorStaffID: heading.anchorStaffID)
            guard let expected, actual == expected else {
                let systems = Set(([expected?.systemIndex].compactMap { $0 })
                    + current.filter { $0.candidateIDs.contains(heading.anchorStaffID) }.map(\\.systemIndex))
                for i in bands.indices where systems.isEmpty || systems.contains(bands[i].systemIndex) {
                    let warning = "Shared heading source ownership could not be verified. Run Auto again or review its source copy."
                    if !bands[i].warnings.contains(warning) { bands[i].warnings.append(warning) }
                }
                continue
            }
            for i in bands.indices where bands[i].systemIndex == expected.systemIndex {
                guard !isCancelled() else { return }
                guard !preservingMarkings.contains(bands[i].id)
                    || automaticHeadingBounds[bands[i].id]?.contains(heading.bounds) == true else { continue }
                if localHeadingRetained(heading, page: page, band: bands[i], binding: expected) { continue }
                copySharedHeading(heading, to: &bands[i])
            }
        }
    }

    private static func headingMarking(_ marking: ScoreSourceMarking, equals bounds: [Double]) -> Bool {
        marking.isBelow != true && bounds.count == 4
            && zip([marking.leftFraction, marking.topFraction, 1-marking.rightFraction, marking.bottomFraction], bounds)
                .allSatisfy { abs($0-$1) < 1e-9 }
    }

    private static func otherDirectionOwns(_ bounds: [Double], page: ScorePageAnalysis, band: ScorePlannedBand) -> Bool {
        (page.sharedNavigation ?? []).contains { $0.bounds == bounds && !$0.isBelow }
            || (page.sharedEndings ?? []).contains { $0.isValid(on: page) && $0.bounds == bounds && $0.systemIndex == band.systemIndex }
    }

    /// Recognition proves equivalence; planning independently proves that the
    /// current recipient still owns and retains the complete original local ink.
    private static func localHeadingRetained(_ heading: ScoreSharedHeading, page: ScorePageAnalysis,
                                             band: ScorePlannedBand, binding: ScoreHeadingRecognitionBinding) -> Bool {
        guard heading.recognitionBinding == binding, band.kind == "music",
              band.systemIndex == binding.systemIndex, band.pageIndex == binding.pageIndex,
              let first = ScoreLocalEndingPreservation.firstStaff(of: band, on: page) else { return false }
        let matches = (heading.localCounterparts ?? []).filter { $0.partID == band.partID }
        guard matches.count == 1 else { return false }
        let local = matches[0], b = local.bounds, ink = local.inkBounds
        func text(_ string: String) -> String {
            string.lowercased().split(whereSeparator: { $0.isWhitespace }).joined(separator: " ")
        }
        guard local.anchorStaffID == first.id,
              !text(heading.recognizedText).isEmpty, text(local.recognizedText) == text(heading.recognizedText),
              ScoreSharedEnding.validBounds(b), ScoreSharedEnding.validBounds(ink),
              ink[0] >= b[0], ink[1] >= b[1], ink[2] <= b[2], ink[3] <= b[3] else { return false }
        let ordered = page.staves.sorted { ($0.staffLineFractions.first ?? -1) < ($1.staffLineFractions.first ?? -1) }
        guard ordered.allSatisfy(validStaff), let index = ordered.firstIndex(where: { $0.id == first.id }) else { return false }
        let top = first.staffLineFractions[0], space = (first.staffLineFractions[4]-top)/4
        let previousBottom = index > 0 ? ordered[index-1].staffLineFractions[4] : 0
        let allowance = 1.25*space*page.pageHeight/page.pageWidth
        guard space.isFinite, space > 0, b[1] < top, (b[1]+b[3])/2 < top,
              b[3] <= top+space, (b[1]+b[3])/2 > (previousBottom+top)/2,
              abs(b[0]-heading.bounds[0]) <= allowance,
              ink[0] >= band.leftFraction, ink[2] <= 1-band.rightFraction,
              ink[1] >= band.topFraction, ink[3] <= band.bottomFraction else { return false }
        return true
    }

'''+s[b:]
s=s.replace('private static func reviewedPage(_ page: ScorePageAnalysis, profile: ScoreExtractionProfile, override: ScorePageOverride) -> ScorePagePlan {','private static func reviewedPage(_ page: ScorePageAnalysis, profile: ScoreExtractionProfile, override: ScorePageOverride, isCancelled: () -> Bool = { false }) -> ScorePagePlan {')
s=s.replace('var automaticEndingPairs: [String: Set<String>] = [:]','var automaticEndingPairs: [String: Set<String>] = [:]\n        var automaticHeadingBounds: [String: [[Double]]] = [:]',1)
s=s.replace('automaticEndingPairs[output.assignments.last!.id] = Set(assigned.automaticLocalEndingPairIDs ?? [])','automaticEndingPairs[output.assignments.last!.id] = Set(assigned.automaticLocalEndingPairIDs ?? [])\n                automaticHeadingBounds[output.assignments.last!.id] = assigned.automaticLocalHeadingBounds ?? []',1)
s=s.replace('preservingMarkings: explicitMarkingLists, legacyReference: legacyReference)','preservingMarkings: explicitMarkingLists, automaticHeadingBounds: automaticHeadingBounds,\n                    legacyReference: legacyReference, isCancelled: isCancelled)',1)
p.write_text(s)
p=w/'DocumentModel/PartsmithDocument.swift';s=p.read_text();a=s.index('        var correction = overrides.first(where: { $0.pageIndex == band.pageIndex })',s.index('    private mutating func setCrop('));b=s.index('        guard let systemIndex = correction.systems.firstIndex',a)
s=s[:a]+'''        let existing = overrides.first(where: { $0.pageIndex == band.pageIndex })
        var correction = ScoreSystemAssignment.pageOverride(page: page, pagePlan: pagePlan, existingOverride: existing)
        if existing == nil { correction.reason = "Crop edges reviewed in Auto Extract." }
'''+s[b:];p.write_text(s)
p=w/'Detection/ScoreSharedDirectionReview.swift';s=p.read_text();needle='''        correction.systems[system].bands[part].automaticLocalEndingPairIDs?.removeAll { removedPairs.contains($0) }'''
s=s.replace(needle,needle+'''
        let removedHeadingBounds = (page.sharedHeadings ?? []) + ScoreSharedHeading.coalesced(page.sharedHeadings ?? [])
        correction.systems[system].bands[part].automaticLocalHeadingBounds?.removeAll { box in
            removed.isBelow != true && removedHeadingBounds.contains { $0.bounds == box }
                && box.count == 4 && zip(box, [removed.leftFraction, removed.topFraction, 1-removed.rightFraction, removed.bottomFraction])
                    .allSatisfy { abs($0-$1) < 1e-9 }
        }''',1)
needle='''                    if preservingOtherCategories {'''
s=s.replace(needle,'''                    if !preservingOtherCategories {
                        // Restored automatic heading copies may postdate the
                        // initial binding. Follow the materialized provenance,
                        // never the recipient's newly edited part/staff identity.
                        let registered = (page.sharedHeadings ?? []) + ScoreSharedHeading.coalesced(page.sharedHeadings ?? [])
                        for bounds in value.automaticLocalHeadingBounds ?? []
                            where ScoreSharedEnding.validBounds(bounds) && registered.contains(where: { $0.bounds == bounds }) {
                            known.append(ScoreSourceMarking(topFraction: bounds[1], bottomFraction: bounds[3],
                                leftFraction: bounds[0], rightFraction: 1-bounds[2]))
                        }
                        value.automaticLocalHeadingBounds = nil
                    }
'''+needle,1)
p.write_text(s)
print('Scratch only: planner/model, review, crop UI API updated')
