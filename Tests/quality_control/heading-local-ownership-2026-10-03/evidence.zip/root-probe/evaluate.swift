import Foundation
import ImageIO
struct Pair: Decodable {
 var id: String
 var globalText: String
 var localText: String
 var globalImage: String
 var localImage: String
 var localRegionClipped: Bool
}
@main enum Evaluate {
 static func main() throws {
  let root = URL(fileURLWithPath: ".build/heading-local-root-2026-10-03")
  let pairs = try JSONDecoder().decode([Pair].self, from: Data(contentsOf: root.appendingPathComponent("real-block-pairs.json")))
  var results: [[String:Any]] = []
  func image(_ path: String) -> CGImage? {
   guard let source = CGImageSourceCreateWithURL(URL(fileURLWithPath: path) as CFURL, nil) else { return nil }
   return CGImageSourceCreateImageAtIndex(source, 0, nil)
  }
  for pair in pairs {
   var result: [String:Any] = ["id":pair.id,"equivalent":false,"automaticCopyRetained":true]
   if pair.localRegionClipped {
    result["reason"] = "Full padded local block exceeds this OCR probe's source region; no equality proof. Text also differs by leading punctuation."
   } else if let global=image(pair.globalImage), let local=image(pair.localImage),
             let a=ExactHeadingBlockMatch.block(global), let b=ExactHeadingBlockMatch.block(local) {
    let equal=ExactHeadingBlockMatch.equivalent(global,local,globalText:pair.globalText,localText:pair.localText)
    result["equivalent"]=equal;result["automaticCopyRetained"] = !equal
    result["globalInkDimensions"]=[a.width,a.height];result["localInkDimensions"]=[b.width,b.height]
    result["reason"] = equal ? "Complete original blocks match." : "Complete blocks differ; font/scan changes and unexplained extra original ink are not erased."
   } else { throw NSError(domain:"HeadingBlockProbe",code:1,userInfo:[NSLocalizedDescriptionKey:"Missing image for \(pair.id)"]) }
   results.append(result)
  }
  let data=try JSONSerialization.data(withJSONObject:results,options:[.prettyPrinted,.sortedKeys]);try data.write(to:root.appendingPathComponent("real-block-results.json"));print(String(data:data,encoding:.utf8)!)
 }
}
