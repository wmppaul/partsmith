import Foundation
import PDFKit
import Vision
import ImageIO
import UniformTypeIdentifiers
struct Inventory: Decodable { var pages: [ScorePageAnalysis] }
@main enum Probe {
 static func main() throws {
  let root = URL(fileURLWithPath: ".build/heading-local-root-2026-10-03")
  let schumann = CommandLine.arguments.contains("schumann")
  let inventory = try JSONDecoder().decode(Inventory.self, from: Data(contentsOf: URL(fileURLWithPath: schumann ? ".build/heading-blocks-2026-10-03/native-worker-final/schumann-inventory.json" : ".build/ownership-mozart-output-2026-10-03/candidate/mozart-inventory.json")))
  let pdf = PDFDocument(url: URL(fileURLWithPath: schumann ? "sample_scores/medium_skewed/03_schumann_piano_quintet_op44_imslp_06822.pdf" : "sample_scores/medium_skewed/01_mozart_piano_quartet_k478_imslp_86903.pdf"))!
  let profile = try JSONDecoder().decode(ScoreExtractionProfile.self, from: Data(contentsOf: URL(fileURLWithPath: schumann ? "Tests/quality_control/profiles/medium-skewed-03-schumann-piano-quintet-op44-imslp-06822.json" : "Tests/quality_control/profiles/medium-skewed-01-mozart-piano-quartet-k478-imslp-86903.json")))
  for index in (schumann ? [1,18,25] : [0,11]) {
   var page = inventory.pages.first { $0.pageIndex == index }!
   let image = NativeScorePageAnalyzer.render(pdf.page(at:index)!, maximumWidth: page.imageWidth, maximumHeight:page.imageHeight)!
   if schumann { page.sharedHeadings = ScoreSharedHeadingDetector.detect(in:image,page:page,profile:profile) }
   let plan = ScoreExtractionPlanner.plan(pages:[page],profile:profile)
   var outputs:[[String:Any]] = []
   let ordered = page.staves.sorted { $0.staffLineFractions[0] < $1.staffLineFractions[0] }
   for band in plan.bands where band.systemIndex == (schumann && index == 18 ? 2 : 0) {
    let staff = ScoreLocalEndingPreservation.firstStaff(of:band,on:page)!
    let pos = ordered.firstIndex { $0.id == staff.id }!
    let space = (staff.staffLineFractions[4]-staff.staffLineFractions[0])/4
    let previous = pos>0 ? ordered[pos-1].staffLineFractions[4] : 0
    let top = max(previous + (pos>0 ? space*0.2:0),staff.staffLineFractions[0]-12*space)
    let bottom = staff.staffLineFractions[0]+space*0.4
    let rect = CGRect(x:0,y:floor(top*Double(image.height)),width:Double(image.width),height:ceil((bottom-top)*Double(image.height)))
    guard let crop = image.cropping(to:rect) else {continue}
    let request=VNRecognizeTextRequest();request.recognitionLevel = .accurate;request.usesLanguageCorrection=false;request.recognitionLanguages=["en-US"];request.minimumTextHeight=0.03
    try VNImageRequestHandler(cgImage:crop,options:[:]).perform([request])
    for observation in request.results ?? [] {
     let candidate=observation.topCandidates(1).first!,b=observation.boundingBox
     let r=CGRect(x:b.minX,y:(rect.minY+(1-b.maxY)*rect.height)/Double(image.height),width:b.width,height:b.height*rect.height/Double(image.height))
     outputs.append(["partID":band.partID,"staffID":staff.id,"text":candidate.string,"confidence":candidate.confidence,"bounds":[r.minX,r.minY,r.maxX,r.maxY],"staffTop":staff.staffLineFractions[0],"previousBottom":previous])
    }
    let dest=CGImageDestinationCreateWithURL(root.appendingPathComponent("p\(index+1)-\(band.partID)-region.png") as CFURL,UTType.png.identifier as CFString,1,nil)!
    CGImageDestinationAddImage(dest,crop,nil);CGImageDestinationFinalize(dest)
   }
   for (n,h) in (page.sharedHeadings ?? []).enumerated() {
    print("GLOBAL", index+1,h.recognizedText,h.bounds)
    let b=h.bounds,r=CGRect(x:b[0]*Double(image.width),y:b[1]*Double(image.height),width:(b[2]-b[0])*Double(image.width),height:(b[3]-b[1])*Double(image.height))
    if let crop=image.cropping(to:r) {let d=CGImageDestinationCreateWithURL(root.appendingPathComponent("p\(index+1)-global\(n).png") as CFURL,UTType.png.identifier as CFString,1,nil)!;CGImageDestinationAddImage(d,crop,nil);CGImageDestinationFinalize(d)}
   }
   let data=try JSONSerialization.data(withJSONObject:outputs,options:[.prettyPrinted,.sortedKeys]);try data.write(to:root.appendingPathComponent("p\(index+1)-local-ocr.json"));print(String(data:data,encoding:.utf8)!)
  }
 }
}
