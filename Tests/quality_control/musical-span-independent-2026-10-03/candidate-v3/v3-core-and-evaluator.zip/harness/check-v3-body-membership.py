from pathlib import Path
import json,hashlib
roots=[Path('.build/musical-span-independent-2026-10-03'),Path('.build/musical-span-attached-addendum-2026-10-03')];allchecks=[]
for root in roots:
 fixtures={c['id']:c for c in json.loads((root/'inputs/cases.json').read_text())}
 for case in json.loads((root/'candidate-v3/span-witnesses.json').read_text()):
  f=fixtures[case['id']];gray=(root/'inputs'/case['id']/'source.gray').read_bytes();assert hashlib.sha256(gray).hexdigest()==f['sourceRawSHA256']
  for si,s in enumerate(case['spans']):
   left,right=s['stroke']
   for bi,b in enumerate(s['bodies']):
    footprint={(x,y)for y,lo,hi in b['footprintRuns']for x in range(lo,hi)};shaft={tuple(p)for p in b['shaftBodyPixels']};attachments=b['attachmentRows'];cx,cy,r=b['filledDisk'];disk={(cx+dx,cy+dy)for dy in range(-r,r+1)for dx in range(-r,r+1)if dx*dx+dy*dy<=r*r}
    assert (cx,cy)in footprint and not(left<=cx<right);assert not(footprint&shaft);assert all(left<=x<right and min(attachments)<=y<=max(attachments)for x,y in shaft);assert disk<=footprint|shaft;assert len(footprint)>0
    x0,y0,x1,y1=b['bounds'];assert [min(x for x,y in footprint),min(y for x,y in footprint),max(x for x,y in footprint)+1,max(y for x,y in footprint)+1]==[x0,y0,x1,y1]
    sourceCheck=None
    if case['scale']==1:
     assert all(0<=x<f['width']and 0<=y<f['height']and gray[y*f['width']+x]==0 for x,y in footprint|shaft)
     expected={(x,y)for y in range(min(attachments),max(attachments)+1)for x in range(left,right)if gray[y*f['width']+x]==0};assert shaft==expected;sourceCheck=True
    allchecks.append({'suite':root.name,'id':case['id'],'scale':case['scale'],'span':si,'body':bi,'bounds':b['bounds'],'footprintPixels':len(footprint),'restoredShaftPixels':len(shaft),'disk':b['filledDisk'],'diskCoveredByExactUnion':True,'diskCenterInOffshaftFootprint':True,'shaftRestrictedToObservedAttachmentRows':True,'footprintBoundsExact':True,'originalSourcePixelsVerified':sourceCheck,'sourceCheckScope':'Exact scale1 original source bytes; half-scale observer threshold pixels were not independently rerendered.'})
p=roots[0]/'candidate-v3/body-membership-checks.json';p.write_text(json.dumps({'bodies':len(allchecks),'fullResolutionBodiesSourceVerified':sum(x['originalSourcePixelsVerified']is True for x in allchecks),'allGeometryAndDiskChecksPass':True,'checks':allchecks},indent=2)+'\n');print(p.read_text())
