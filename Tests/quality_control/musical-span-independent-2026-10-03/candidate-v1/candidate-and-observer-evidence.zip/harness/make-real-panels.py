from pathlib import Path
from PIL import Image,ImageDraw
import json,hashlib,shutil
root=Path('.build/musical-span-independent-2026-10-03/candidate-v1/real-source-review');root.mkdir(exist_ok=True)
r=Path('.build/source-musical-spans-2026-10-03/candidate-v1-observed-real/span-records');imdir=Path('.build/brahms-source-span-full-replay-2026-10-03/rasters');cards=[];bindings=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,page in enumerate([23,28,29,38,39]):
 p=r/f'{n:03}.json';d=json.loads(p.read_text());source=imdir/f'page-{page}.png';im=Image.open(source).convert('RGB');assert im.size==(d['width'],d['height']);shutil.copyfile(p,root/f'p{page}-witnesses.json')
 bindings.append({'page':page,'raster':str(source),'rasterSHA256':sha(source),'bodyLog':str(p),'bodyLogSHA256':sha(p)})
 for i,s in enumerate(d['spans']):
  card=Image.new('RGB',(600,300),'white');draw=ImageDraw.Draw(card);draw.text((8,5),f'p{page} span{i+1}: owners {s["staffIDs"]}',fill='black')
  for k,b in enumerate(s['bodies']):
   x0,y0,x1,y1=b['bounds'];box=(max(0,x0-7),max(0,y0-7),min(im.width,x1+7),min(im.height,y1+7));crop=im.crop(box).resize(((box[2]-box[0])*7,(box[3]-box[1])*7),Image.Resampling.NEAREST)
   card.paste(crop,(8+k*300,50));draw.text((8+k*300,30),f'{"hollow"if b["hollow"]else"filled"}  {b["bounds"]}',fill='black')
   draw.rectangle((8+k*300+(x0-box[0])*7,50+(y0-box[1])*7,8+k*300+(x1-box[0])*7-1,50+(y1-box[1])*7-1),outline=(230,80,0),width=1)
  cards.append(card)
canvas=Image.new('RGB',(1200,300*((len(cards)+1)//2)),'white')
for i,im in enumerate(cards):canvas.paste(im,((i%2)*600,(i//2)*300))
canvas.save(root/'all-raw-body-fits.png');(root/'bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
