from pathlib import Path
import json,hashlib
root=Path('.build/musical-span-independent-2026-10-03');p=root/'candidate-v1-witnesses'
records=[];current=None
for line in (p/'run.log').read_text().splitlines():
 if line.startswith('SOURCE_CASE '):
  assert current is None;current=json.loads(line[len('SOURCE_CASE '):])
 elif line.startswith('SOURCE_SPANS '):
  assert current is not None;current['spans']=json.loads(line[len('SOURCE_SPANS '):]);records.append(current);current=None
assert len(records)==29 and current is None
actual=json.loads((root/'candidate-v1/results.json').read_text());logged=json.loads((p/'results.json').read_text())
def strip(v):
 if isinstance(v,dict):return {k:strip(x)for k,x in v.items()if k!='elapsedSeconds'}
 if isinstance(v,list):return [strip(x)for x in v]
 return v
assert strip(actual)==strip(logged),'Logging changed semantical result'
assert [(x['id'],x['scale'])for x in records]==[(x['id'],x['scale'])for x in actual['cases']]
(p/'span-witnesses.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
summary={'observations':len(records),'semanticResultsEqualToUninstrumented':True,'observationsWithSpan':sum(bool(x['spans'])for x in records),'totalSpanRecords':sum(len(x['spans'])for x in records),'negativeObservations':sum(x['family']=='new-no-shared-span'for x in records),'negativeObservationsWithSpan':sum(x['family']=='new-no-shared-span'and bool(x['spans'])for x in records),'records':[{'id':x['id'],'scale':x['scale'],'spans':len(x['spans']),'owners':[s['staffIDs']for s in x['spans']]}for x in records]}
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
