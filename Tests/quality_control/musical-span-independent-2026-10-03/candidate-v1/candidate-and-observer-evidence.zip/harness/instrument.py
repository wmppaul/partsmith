from pathlib import Path
import shutil,json,hashlib,difflib
root=Path('.build/musical-span-independent-2026-10-03');dst=root/'candidate-v1-witnesses';dst.mkdir(exist_ok=True)
src=Path('.build/source-musical-spans-2026-10-03/candidate-v1-final/Core');shutil.copytree(src,dst/'Core',dirs_exist_ok=True)
p=dst/'Core/Detection/NativeScorePageAnalyzer.swift';old=p.read_text();needle='''            for span in sourceSpans {''';assert old.count(needle)==1
insert='''            if let data = try? JSONEncoder().encode(sourceSpans) {
                FileHandle.standardError.write(Data("SOURCE_SPANS ".utf8))
                FileHandle.standardError.write(data)
                FileHandle.standardError.write(Data("\\n".utf8))
            }
''';new=old.replace(needle,insert+needle);p.write_text(new)
(dst/'logging-only.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='frozen/NativeScorePageAnalyzer.swift',tofile='logging/NativeScorePageAnalyzer.swift')))
e=(root/'evaluate.swift').read_text();needle='''    let began=Date();let found=NativeScorePageAnalyzer.notationComponents''';assert e.count(needle)==1
e=e.replace(needle,'''    let identity:[String:Any] = ["id":fixture.id,"scale":scale,"family":fixture.family]
    FileHandle.standardError.write(Data("SOURCE_CASE ".utf8))
    FileHandle.standardError.write(try JSONSerialization.data(withJSONObject:identity,options:[.sortedKeys]))
    FileHandle.standardError.write(Data("\\n".utf8))
'''+needle);(dst/'evaluate.swift').write_text(e);shutil.copyfile(root/'run.sh',dst/'run.sh')
h={str(f.relative_to(dst/'Core')):hashlib.sha256(f.read_bytes()).hexdigest()for f in sorted((dst/'Core').rglob('*'))if f.is_file()};(dst/'source-hashes.json').write_text(json.dumps(h,indent=2)+'\n')
