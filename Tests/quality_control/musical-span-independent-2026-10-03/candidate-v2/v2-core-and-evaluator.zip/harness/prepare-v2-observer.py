from pathlib import Path
import shutil,json,hashlib,difflib
r=Path('.build/musical-span-independent-2026-10-03');src=Path('.build/source-musical-spans-2026-10-03/candidate-v2/Core');out=r/'candidate-v2';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();protocol=Path('.build/source-musical-spans-2026-10-03/v2-protocol-before-results.json')
assert sha(src/'Detection/NativeScorePageAnalyzer.swift')=='08ef2cc99337e104d646a1ded1d7b5dc63819b9735a511192d74570e41fff6d8'
assert sha(protocol)=='2c1caa954c2b2fe718b83986b69445915700adbd6f7ca4a0b2eb9b878d14050b'
for inputs in [r,Path('.build/musical-span-attached-addendum-2026-10-03')]:
 for p,h in json.loads((inputs/'input-manifest.json').read_text()).items():assert sha(inputs/p)==h
shutil.copytree(src,out/'Core',dirs_exist_ok=True);shutil.copyfile(protocol,out/'candidate-protocol.json')
hashes={str(p.relative_to(src)):sha(p)for p in sorted(src.rglob('*'))if p.is_file()};(out/'frozen-source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
p=out/'Core/Detection/NativeScorePageAnalyzer.swift';old=p.read_text();needle='            for span in sourceSpans {';assert old.count(needle)==1
insert='''            if let data = try? JSONEncoder().encode(sourceSpans) {
                FileHandle.standardError.write(Data("SOURCE_SPANS ".utf8))
                FileHandle.standardError.write(data)
                FileHandle.standardError.write(Data("\\n".utf8))
            }
''';new=old.replace(needle,insert+needle);p.write_text(new)
(out/'logging-only.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='frozen/NativeScorePageAnalyzer.swift',tofile='observer/NativeScorePageAnalyzer.swift')))
# The same already-audited evaluator's only additions are JSON case labels.
shutil.copyfile(r/'candidate-v1-witnesses/evaluate.swift',out/'evaluate.swift');shutil.copyfile(r/'run.sh',out/'run.sh')
(out/'observer-source-hashes.json').write_text(json.dumps({str(p.relative_to(out/'Core')):sha(p)for p in sorted((out/'Core').rglob('*'))if p.is_file()},indent=2)+'\n')
(out/'run-bindings.json').write_text(json.dumps({'frozenNativeSHA256':hashes['Detection/NativeScorePageAnalyzer.swift'],'observerNativeSHA256':sha(p),'protocolSHA256':sha(protocol),'original29InputManifestSHA256':sha(r/'input-manifest.json'),'addendumInputManifestSHA256':sha(Path('.build/musical-span-attached-addendum-2026-10-03/input-manifest.json')),'execution':'One instrumented native execution per unchanged suite; logging only observes returned source spans and case IDs. No uninstrumented duplicate run.'},indent=2)+'\n')
print('Prepared V2 observer; frozen source and both input manifests verified.')
