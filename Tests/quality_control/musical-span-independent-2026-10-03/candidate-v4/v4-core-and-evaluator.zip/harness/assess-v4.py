from pathlib import Path
import json,collections,hashlib
roots=[Path('.build/musical-span-independent-2026-10-03'),Path('.build/musical-span-attached-addendum-2026-10-03')]
for R in roots:
 out=R/'candidate-v4';versions={v:json.loads((R/v/'results.json').read_text())for v in ['baseline','candidate-v1','candidate-v2','candidate-v3','candidate-v4']};records=[];pending=None
 for line in(out/'run.log').read_text().splitlines():
  if line.startswith('SOURCE_CASE '):assert pending is None;pending=json.loads(line[12:])
  if line.startswith('SOURCE_SPANS '):assert pending is not None;pending['spans']=json.loads(line[13:]);records.append(pending);pending=None
 assert len(records)==len(versions['baseline']['cases'])==len(versions['candidate-v4']['cases']) and pending is None
 (out/'span-witnesses.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
 summaries=[]
 for prior in ['baseline','candidate-v1','candidate-v2','candidate-v3']:
  ownerRows=[];componentRows=[]
  for b,c,w in zip(versions[prior]['cases'],versions['candidate-v4']['cases'],records):
   for f in ['id','family','scale','sourceRawSHA256','sourceShape','analysisShape']:assert b[f]==c[f]
   assert (b['id'],b['scale'])==(w['id'],w['scale']);assert b['canApply'] and c['canApply'] and b['bandCount']==c['bandCount'];assert len(b['targets'])==len(c['targets'])
   count=lambda v,alt:collections.Counter(json.dumps(x,sort_keys=True)for x in v['components']if(x.get('isOwnershipAlternative')is True)==alt)
   ordinarySame=count(b,False)==count(c,False);removed=list((count(b,True)-count(c,True)).elements())
   componentRows.append({'id':b['id'],'scale':b['scale'],'ordinaryComponentsEqual':ordinarySame,'removedPriorAlternatives':[json.loads(x)for x in removed],'note':'Removed V1 source-span hypotheses are expected when rejected; removal of baseline alternatives would be a regression.'})
   for bt,ct in zip(b['targets'],c['targets']):
    for f in ['owner','partID','sourcePixels','sourceEnvelope','sourceMaskSHA256','allowedWholeNeighborIDs','candidateIDs']:assert bt[f]==ct[f]
    old=set(bt['lostPixelIndices']);new=set(ct['lostPixelIndices']);env=ct['sourceEnvelope'];crop=ct['crop'];full=crop[0]<=env[0]+1e-9 and crop[1]<=env[1]+1e-9 and crop[2]>=env[2]-1e-9 and crop[3]>=env[3]-1e-9
    ownerRows.append({'id':c['id'],'family':c['family'],'scale':c['scale'],'owner':ct['owner'],'sourcePixels':ct['sourcePixels'],'sourceEnvelope':env,'priorCrop':bt['crop'],'candidateCrop':crop,'priorLost':len(old),'candidateLost':len(new),'newlyLostPixelIndices':sorted(new-old),'recoveredPixelIndices':sorted(old-new),'fullSourceRetained':not new and full,'priorSpuriousWholeNeighborIDs':bt['spuriousWholeNeighborCoreIDs'],'candidateSpuriousWholeNeighborIDs':ct['spuriousWholeNeighborCoreIDs'],'newSpuriousWholeNeighborIDs':sorted(set(ct['spuriousWholeNeighborCoreIDs'])-set(bt['spuriousWholeNeighborCoreIDs']))})
  report={'comparisonAgainst':prior,'sourceScaleCases':len(records),'ownerObservations':len(ownerRows),'inputBindingsExact':True,'observerScope':'One V4 native pass per suite; observer adds only serialization of returned spans and case labels. No independent uninstrumented rerun.','priorCompleteOwners':sum(x['priorLost']==0 for x in ownerRows),'candidateCompleteOwners':sum(x['candidateLost']==0 for x in ownerRows),'newlyLostOwners':sum(bool(x['newlyLostPixelIndices'])for x in ownerRows),'newlyLostPixels':sum(len(x['newlyLostPixelIndices'])for x in ownerRows),'recoveredOwners':sum(bool(x['recoveredPixelIndices'])for x in ownerRows),'recoveredPixels':sum(len(x['recoveredPixelIndices'])for x in ownerRows),'newSpuriousNeighborOwnerObservations':sum(bool(x['newSpuriousWholeNeighborIDs'])for x in ownerRows),'newSpuriousNeighborRelations':sum(len(x['newSpuriousWholeNeighborIDs'])for x in ownerRows),'ordinaryComponentsInvariant':all(x['ordinaryComponentsEqual']for x in componentRows),'priorAlternativesRetained':all(not x['removedPriorAlternatives']for x in componentRows),'emittedSpanRecords':sum(len(x['spans'])for x in records),'negativeSourceScaleObservations':sum(x['family']=='new-no-shared-span'for x in records),'negativeObservationsWithSpans':sum(x['family']=='new-no-shared-span'and bool(x['spans'])for x in records),'candidateElapsedSeconds':versions['candidate-v4']['elapsedSeconds'],'owners':ownerRows,'componentComparisons':componentRows}
  (out/f'full-comparison-to-{prior}.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');summaries.append({k:v for k,v in report.items()if k not in ['owners','componentComparisons']})
 (out/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n');print(R.name,json.dumps(summaries,indent=2))
