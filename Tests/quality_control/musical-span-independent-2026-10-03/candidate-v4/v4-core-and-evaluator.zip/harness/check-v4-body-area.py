from pathlib import Path
import json,math
roots=[Path('.build/musical-span-independent-2026-10-03'),Path('.build/musical-span-attached-addendum-2026-10-03')]
# Independent gift-wrapping hull, deliberately not the Native monotone-chain code.
def cell_hull(cells):
 points=sorted({(x+dx,y+dy)for x,y in cells for dx,dy in[(0,0),(1,0),(0,1),(1,1)]});assert len(points)>=3
 start=points[0];hull=[];p=start
 while True:
  hull.append(p);q=next(v for v in points if v!=p)
  for r in points:
   cross=(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
   if cross<0 or (cross==0 and (r[0]-p[0])**2+(r[1]-p[1])**2>(q[0]-p[0])**2+(q[1]-p[1])**2):q=r
  p=q
  if p==start:break
  assert len(hull)<=len(points)
 area=abs(sum(a[0]*b[1]-b[0]*a[1]for a,b in zip(hull,hull[1:]+hull[:1])))/2
 return hull,area
# Fixed convention checks, no classifier calls: unit square, two diagonal squares,
# solid2x2 block, and L triomino. Holes are not filled in the numerator.
for cells,area in[({(0,0)},1),({(0,0),(1,1)},3),({(0,0),(1,0),(0,1),(1,1)},4),({(0,0),(1,0),(0,1)},3.5)]:assert cell_hull(cells)[1]==area
records=[]
def strip_area(x):
 if isinstance(x,dict):return{k:strip_area(v)for k,v in x.items()if k not in['inkArea','hullArea','solidity']}
 if isinstance(x,list):return[strip_area(v)for v in x]
 return x
for root in roots:
 current=json.loads((root/'candidate-v4/span-witnesses.json').read_text());old=json.loads((root/'candidate-v3/span-witnesses.json').read_text());assert strip_area(current)==old
 for c in current:
  for si,s in enumerate(c['spans']):
   for bi,b in enumerate(s['bodies']):
    footprint={(x,y)for y,left,right in b['footprintRuns']for x in range(left,right)};shaft={tuple(p)for p in b['shaftBodyPixels']};pixels=footprint|shaft;hull,area=cell_hull(pixels);ink=len(pixels);solidity=ink/area
    assert math.isclose(ink,b['inkArea'],rel_tol=0,abs_tol=1e-12);assert math.isclose(area,b['hullArea'],rel_tol=0,abs_tol=1e-12);assert math.isclose(solidity,b['solidity'],rel_tol=0,abs_tol=1e-12);assert solidity>=.82
    records.append({'suite':root.name,'id':c['id'],'scale':c['scale'],'span':si,'body':bi,'sourceBodyBounds':b['bounds'],'uniqueFootprintPixels':len(footprint),'uniqueShaftPixels':len(shaft),'computedInkArea':ink,'computedHullArea':area,'computedSolidity':solidity,'loggedInkArea':b['inkArea'],'loggedHullArea':b['hullArea'],'loggedSolidity':b['solidity'],'hullUnitCellCorners':hull,'allValuesMatch':True})
result={'method':'Independent gift-wrapping convex hull of unit-cell CORNERS, shoelace continuous area; numerator is unique source footprint+shaft cell count. Native uses monotone chain; no copied Native hull implementation.','conventionControlsPassed':4,'bodyRecords':len(records),'allValuesMatch':True,'allBodyEvidenceExactToV3ExceptNewAreaFields':True,'checks':records}
out=roots[0]/'candidate-v4/body-area-checks.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'bodies':len(records),'allValuesMatch':True,'areas':[(r['id'],r['scale'],r['computedInkArea'],r['computedHullArea'],r['computedSolidity'])for r in records]},indent=2))
