import Foundation
import CoreGraphics
import ImageIO
@main enum Replay {
 struct Inventory: Codable { var pages:[ScorePageAnalysis];var plan:ScoreExtractionPlan }
 struct Output:Codable {var pages:[ScorePageAnalysis];var plan:ScoreExtractionPlan}
 static func main()throws {
  let a=CommandLine.arguments
  let base=try JSONDecoder().decode(Inventory.self,from:Data(contentsOf:URL(fileURLWithPath:".build/ownership-alternatives-2026-10-03/actual.json")))
  let profile=try JSONDecoder().decode(ScoreExtractionProfile.self,from:Data(contentsOf:URL(fileURLWithPath:"Tests/quality_control/profiles/medium-skewed-06-brahms-string-quartet-no3-op67-imslp-93521.json")))
  var pages:[ScorePageAnalysis]=[]
  for pn in [10] {
   let old=base.pages[pn-1]
   let url=URL(fileURLWithPath:".build/brahms-source-span-full-replay-2026-10-03/rasters/page-\(pn).png")
   let src=CGImageSourceCreateWithURL(url as CFURL,nil)!,image=CGImageSourceCreateImageAtIndex(src,0,nil)!
   let p=NativeScorePageAnalyzer.analyze(pageIndex:pn-1,image:image,pageWidth:old.pageWidth,pageHeight:old.pageHeight)
   precondition(p.staves==old.staves,"Staff geometry drift")
   pages.append(p);print("native page",pn,"components",p.inkComponents?.count ?? -1)
  }
  let out=Output(pages:pages,plan:ScoreExtractionPlanner.plan(pages:pages,profile:profile))
  let e=JSONEncoder();e.outputFormatting=[.sortedKeys,.prettyPrinted];try e.encode(out).write(to:URL(fileURLWithPath:a[1]))
 }
}

enum SpanProbe {
 static var index = 0
 static func capture(_ spans:[NativeScorePageAnalyzer.SourceSpanWitness], seeds:[NativeScorePageAnalyzer.SourceSpanSeed], width:Int,height:Int) {
  let dir=URL(fileURLWithPath:CommandLine.arguments[1]).deletingLastPathComponent().appendingPathComponent("span-records")
  try! FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
  let seedData=seeds.map {["left":Double($0.left),"right":Double($0.right),"y":Double($0.y),"space":$0.space]}
  let data:[String:Any] = ["index":index,"width":width,"height":height,"seeds":seedData,"spans":try!JSONSerialization.jsonObject(with:JSONEncoder().encode(spans))]
  try!JSONSerialization.data(withJSONObject:data,options:[.prettyPrinted,.sortedKeys]).write(to:dir.appendingPathComponent(String(format:"%03d.json",index)))
  index += 1
 }
}
