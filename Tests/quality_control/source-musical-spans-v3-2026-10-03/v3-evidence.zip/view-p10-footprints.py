from pathlib import Path
import json,hashlib
from PIL import Image,ImageDraw
p=Path('.build/source-musical-spans-2026-10-03');d=p/'candidate-v3-p10-observed';r=json.load(open(d/'span-records/000.json'));src=Path('.build/brahms-source-span-full-replay-2026-10-03/rasters/page-10.png');im=Image.open(src).convert('RGB');s=r['spans'][0]
canvas=Image.new('RGB',(1200,1080),'white');dr=ImageDraw.Draw(canvas);dr.text((10,10),'V3 p10: THREE source fermata arches misclassified as filled heads; original source and whole accepted footprint.',fill='black');idx=[]
for k,b in enumerate(s['bodies']):
 x0,y0,x1,y1=b['bounds'];box=(x0-8,y0-6,x1+8,y1+12);sc=7;w=(box[2]-box[0])*sc;h=(box[3]-box[1])*sc;top=65+k*335
 raw=im.crop(box);raw.save(d/f'p10-body{k}-source.png');view=raw.resize((w,h),Image.Resampling.NEAREST)
 mask=Image.new('RGB',raw.size,'white')
 for y,a,z in b['footprintRuns']:
  for x in range(a,z):mask.putpixel((x-box[0],y-box[1]),(0,0,0))
 for x,y in b['shaftBodyPixels']:mask.putpixel((x-box[0],y-box[1]),(40,80,180))
 mask=mask.resize((w,h),Image.Resampling.NEAREST)
 for xx,label,pic in [(10,'Unmodified source (dot is separate)',view),(440,'Whole footprint; blue = original shaft',mask)]:
  dr.text((xx,top-20),label,fill='black');canvas.paste(pic,(xx,top))
  cx,cy,rad=b['filledDisk'];dr.ellipse((xx+(cx-rad-box[0])*sc,top+(cy-rad-box[1])*sc,xx+(cx+rad+1-box[0])*sc,top+(cy+rad+1-box[1])*sc),outline=(0,170,50),width=2)
 dr.text((900,top+10),f'Body {k}\nbounds{x0},{y0},{x1},{y1}\ndisk{b["filledDisk"]}\nOff-shaft pixels{sum(z-a for y,a,z in b["footprintRuns"])}\nActual shaft pixels{len(b["shaftBodyPixels"])}\nGreen circle tests local\nthickness, not whole\nfilled-head identity.',fill='black')
 idx.append({'body':k,'bodyBounds':b['bounds'],'sourcePatchBounds':box,'sourcePatchFile':f'p10-body{k}-source.png','sourcePatchSHA256':hashlib.sha256((d/f'p10-body{k}-source.png').read_bytes()).hexdigest()})
canvas.save(d/'p10-source-footprints.png');(d/'p10-source-bindings.json').write_text(json.dumps({'sourceRaster':str(src),'sourceSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'witnessSHA256':hashlib.sha256((d/'span-records/000.json').read_bytes()).hexdigest(),'observations':idx},indent=2)+'\n')
