from pathlib import Path
import shutil,json,hashlib
p=Path('.build/source-musical-spans-2026-10-03');d=p/'candidate-v3/Core';shutil.copytree(p/'candidate-v2/Core',d)
f=d/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text().replace('        var filledDisk: [Int]\n','        var filledDisk: [Int]\n        var shaftBodyPixels: [[Int]]\n',1)
needle='                var disk: [Int]?\n';insert='''                // The shaft is known original ink belonging to this body's
                // observed attachment rows. Its exclusion was useful for path
                // explanation, but must not split a real filled head in half.
                var thicknessPixels = pixels
                var shaftBodyPixels: [[Int]] = []
                for y in attachments.first!...attachments.last! {
                    if isCancelled() { return [] }
                    for x in left..<right where black(x, y) {
                        thicknessPixels.insert((y - yLo) * localWidth + x - xLo)
                        shaftBodyPixels.append([x, y])
                    }
                }
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
old='|| !pixels.contains(y * localWidth + x) { full = false }';new='|| !thicknessPixels.contains(y * localWidth + x) { full = false }';assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('                    filledDisk: disk, explainedThinRuns:', '                    filledDisk: disk, shaftBodyPixels: shaftBodyPixels, explainedThinRuns:',1);f.write_text(s)
h={str(x.relative_to(d)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(d.rglob('*.swift'))};(d.parent/'source-hashes.json').write_text(json.dumps(h,indent=2,sort_keys=True)+'\n')
print(h['Detection/NativeScorePageAnalyzer.swift']);print(hashlib.sha256((p/'v3-protocol-before-results.json').read_bytes()).hexdigest())
