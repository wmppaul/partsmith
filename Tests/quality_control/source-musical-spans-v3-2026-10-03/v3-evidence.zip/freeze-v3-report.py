from pathlib import Path
import json,hashlib,zipfile,shutil
p=Path('.build/source-musical-spans-2026-10-03');r=Path('Tests/quality_control/source-musical-spans-v3-2026-10-03');r.mkdir(exist_ok=True)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
copy={'protocol-before-results.json':p/'v3-protocol-before-results.json','fourcore-comparison.json':p/'candidate-v3/fourcore-comparison.json','real-five-comparison.json':p/'candidate-v3/real-five-comparison.json','p10-source-footprints.png':p/'candidate-v3-p10-observed/p10-source-footprints.png','p10-source-bindings.json':p/'candidate-v3-p10-observed/p10-source-bindings.json','p10-invariance.json':p/'candidate-v3-p10-observed/invariance.json','p10-witnesses.json':p/'candidate-v3-p10-observed/span-records/000.json','root-full39-comparison.json':Path('.build/brahms-source-span-full-v3-2026-10-03/comparison.json'),'combined-aborted-before-tests.json':Path('.build/numbered-lines-source-spans-2026-10-03/ABORTED-before-tests.json')}
for name,f in copy.items():shutil.copy2(f,r/name)
inputs=[p/'candidate-v3/Core/Detection/NativeScorePageAnalyzer.swift',p/'candidate-v3-p10-observed/Core/Detection/NativeScorePageAnalyzer.swift',Path('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'),Path('Tests/quality_control/source-musical-spans-v2-2026-10-03/manifest.json'),Path('Tests/quality_control/musical-span-independent-2026-10-03/candidate-v3/manifest.json'),Path('Tests/quality_control/musical-span-attached-addendum-2026-10-03/candidate-v3/manifest.json'),Path('.build/brahms-source-span-full-v3-2026-10-03/candidate.json'),Path('.build/brahms-source-span-full-v3-2026-10-03/run.log')]
(r/'bindings.json').write_text(json.dumps({str(f):sha(f) for f in inputs},indent=2,sort_keys=True)+'\n')
files={}
for name in ['v3-protocol-before-results.json','make-v3.py','compare-v3.py','freeze-v3-report.py','view-p10-footprints.py','case176.swift','fourcore.swift','real-five.swift','p10-observed.swift','build-run.sh']:files[name]=p/name
for name in ['StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift','NativeScorePageAnalyzer.swift']:files['candidate-v3/Core/Detection/'+name]=p/'candidate-v3/Core/Detection'/name
for variant in ['candidate-v3','candidate-v3-p10-observed']:
 for f in (p/variant).rglob('*'):
  if f.is_file() and f.suffix in ['.json','.log','.pgm','.png'] and 'Core' not in f.parts and 'fourcore-sources' not in f.parts:files[str(f.relative_to(p))]=f
files['candidate-v3-p10-observed/Core/Detection/NativeScorePageAnalyzer.swift']=p/'candidate-v3-p10-observed/Core/Detection/NativeScorePageAnalyzer.swift'
combined=Path('.build/numbered-lines-source-spans-2026-10-03')
for name in ['protocol-before-results.json','source-bindings-before-results.json','combined-versus-numbered-v2.diff','ABORTED-before-tests.json']:files['aborted-combined/'+name]=combined/name
archive=r/'v3-evidence.zip';members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,f in sorted(files.items()):z.write(f,n);members[n]={'sha256':sha(f),'bytes':f.stat().st_size}
(r/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),'members':members},indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(archive) as z:
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
print(len(members),archive.stat().st_size)
