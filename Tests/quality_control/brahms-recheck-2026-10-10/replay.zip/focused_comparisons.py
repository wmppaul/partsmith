from pathlib import Path
import json
import pymupdf as fitz
from PIL import Image, ImageDraw
W=Path('.build/brahms-recheck-2026-10-10');Q=Path('Tests/quality_control/brahms-recheck-2026-10-10')
load=lambda p:json.loads(p.read_text())
mapping=load(Q/'complete-band-inventory.json')['rows']
fresh=load(W/'fresh-corrected-auto/placements.json')
final=load(W/'assisted-cue-correction/placements.json')
cases=[('violin2',3,1,'Rehearsal A: source page 3, system 1 / Violin II'),
       ('viola',8,2,'Viola in-tempo descender + rehearsal F: source page 8, system 2'),
       ('cello',31,4,'Shared fermata: source page 31, system 4 / Cello')]
out=Q/'focused-comparisons';out.mkdir(exist_ok=True)
for logical,pg,sy,title in cases:
    row=next(r for r in mapping if r['partID']==logical and r['sourcePage']==pg and r['system']==sy)
    name=row['partName'];images=[]
    index=next(i for i,r in enumerate([r for r in mapping if r['partID']==logical]) if r['id']==row['id'])
    for mode,parts in [('fresh-corrected-auto',fresh),('assisted-cue-correction',final)]:
        p=next(p for p in parts if p['name']==name);placed=p['placements'][index]
        rect=fitz.Rect(placed['destinationRect'])
        for copy in placed['sourceMarkings']:rect|=fitz.Rect(copy['destinationRect'])
        rect+=(-2,-2,2,2)
        pdf=fitz.open(W/mode/p['file']);pix=pdf[placed['outputPage']-1].get_pixmap(matrix=fitz.Matrix(2,2),clip=rect,alpha=False)
        images.append(Image.frombytes('RGB',(pix.width,pix.height),pix.samples))
    width=max(i.width for i in images)+20;height=sum(i.height for i in images)+100
    sheet=Image.new('RGB',(width,height),'white');draw=ImageDraw.Draw(sheet)
    draw.text((10,8),title,fill='black');y=30
    for label,im in zip(['Fresh corrected Auto - draft','Reviewed assisted export - latest seven trims retained'],images):
        draw.text((10,y),label,fill='black');sheet.paste(im,(10,y+18));y+=im.height+28
    sheet.save(out/f'{logical}-p{pg:02d}s{sy}-before-after.png')
print('Rendered3focused actualPDFbefore/aftercomparisons')
