from pathlib import Path
import json
import pymupdf as fitz
from PIL import Image,ImageDraw
q=Path('Tests/quality_control/brahms-recheck-2026-10-10');out=q/'cue-review';out.mkdir(exist_ok=True)
f=Path('.build/brahms-recheck-2026-10-10/fresh-corrected-auto');r=json.load(open(q/'audit.json'))['fresh-corrected-auto'];parts=json.load(open(f/'placements.json'));plan=json.load(open(f/'plan.json'));oracle=json.load(open('Tests/quality_control/brahms93521/shared-directions-corrected.json'))
source=fitz.open('output/pdf/auto-qc-2026-10-03/brahms-quartet-93521-viola-in-tempo-repair/rectified-review-source.pdf');target=fitz.open(f/'Violin II.pdf')
pairs=[a for pg in plan['pages'] for a in pg['assignments'] if a['partID']=='violin2'];placements=parts[1]['placements'];by={(a['pageIndex']+1,a['systemIndex']+1):p for a,p in zip(pairs,placements)}
lookup={c['id']:c for c in oracle['entries']}
for x in r['copyOracleCoverage']:
 if x['part']!='Violin II' or x['blackPixelsOutsideStoredSourceGeometry']==0 or x['kind']=='rehearsal':continue
 cue=lookup[x['id']];p=by[(x['sourcePage'],x['system'])];cr=fitz.Rect(cue['rect']);sc=fitz.Rect(0,max(0,cr.y0-5),427,cr.y1+6);dr=fitz.Rect(p['destinationRect']);regions=[dr]+[fitz.Rect(c['destinationRect']) for c in p['sourceMarkings']];tr=fitz.Rect(0,min(x.y0 for x in regions)-4,612,max(x.y1 for x in regions)+4)
 def im(page,clip):
  px=page.get_pixmap(matrix=fitz.Matrix(3,3),clip=clip,alpha=False);return Image.frombytes('RGB',(px.width,px.height),px.samples)
 a=im(source[x['sourcePage']-1],sc);b=im(target[p['outputPage']-1],tr)
 sheet=Image.new('RGB',(max(a.width,b.width),a.height+b.height+65),'#eeeeee');d=ImageDraw.Draw(sheet);d.text((10,6),f"Source p{x['sourcePage']} s{x['system']}: {cue['text']}",fill='black');sheet.paste(a,(0,25));d.text((10,a.height+33),f"Current fresh Auto Violin II output p{p['outputPage']}: copied heading and complete music strip",fill='black');sheet.paste(b,(0,a.height+58));sheet.save(out/(x['id']+'.png'))
