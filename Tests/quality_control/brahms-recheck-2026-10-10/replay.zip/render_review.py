from pathlib import Path
import json,math
import pymupdf as fitz
from PIL import Image,ImageDraw
root=Path('.build/brahms-recheck-2026-10-10')
qc=Path('Tests/quality_control/brahms-recheck-2026-10-10');qc.mkdir(exist_ok=True)
def render(folder,manifest,kind):
 out=qc/kind;out.mkdir(exist_ok=True)
 page_inventory=[]
 for part in manifest:
  pdf=fitz.open(folder/part['file']);images=[]
  for i,page in enumerate(pdf,1):
   pix=page.get_pixmap(matrix=fitz.Matrix(1.25,1.25),alpha=False)
   im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
   placements=[p for p in part['placements'] if p['outputPage']==i]
   pages=[p['sourcePage'] for p in placements]
   page_inventory.append({'part':part['name'],'page':i,'sourcePages':sorted(set(pages)),'systems':len(placements),'image':f'{kind}/{part["name"]}-page-{i:02d}.png'})
   im.save(out/f'{part["name"]}-page-{i:02d}.png');images.append(im)
  for start in range(0,len(images),4):
   w,h=images[0].size;sheet=Image.new('RGB',(w*2,(h+25)*2),'#dddddd');draw=ImageDraw.Draw(sheet)
   for j,im in enumerate(images[start:start+4]):
    x=j%2*w;y=j//2*(h+25);draw.text((x+10,y+5),f'{part["name"]}: output page {start+j+1}',fill='black');sheet.paste(im,(x,y+25))
   sheet.save(out/f'{part["name"]}-contact-{start//4+1:02d}.jpg',quality=94)
 return page_inventory
if __name__=='__main__':
 import sys
 if sys.argv[1]=='secondary':
  folder=Path('.build/brahms09200-recheck-2026-10-10/parts');m=json.load(open(folder/'manifest.json'))['parts'];pages=render(folder,m,'09200-crossreview')
 else:
  mode=sys.argv[1];folder=root/mode;m=json.load(open(folder/'placements.json'));pages=render(folder,m,mode+'-review')
 (qc/(sys.argv[1]+'-pages.json')).write_text(json.dumps(pages,indent=2)+'\n')
