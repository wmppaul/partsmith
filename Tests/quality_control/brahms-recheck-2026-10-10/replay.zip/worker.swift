import AppKit
import Combine
import CryptoKit
import Foundation
import PDFKit

@main enum Recheck {
    struct Envelope: Codable { var project: ProjectData }
    struct Inventory: Codable {
        var source: String; var sourceSHA256: String
        var pages: [ScorePageAnalysis]; var rectifications: [PageRectification]
    }
    static let oldDir = URL(fileURLWithPath: "output/pdf/auto-qc-2026-10-03/brahms-quartet-93521-viola-in-tempo-repair")
    static let base = URL(fileURLWithPath: ".build/brahms-recheck-2026-10-10")
    static func hash(_ data: Data) -> String { SHA256.hash(data:data).map{String(format:"%02x",$0)}.joined() }
    static func fail(_ msg: String) -> NSError { NSError(domain:"BrahmsRecheck",code:1,userInfo:[NSLocalizedDescriptionKey:msg]) }
    static func write<T:Encodable>(_ value:T, _ url:URL) throws {
        let e=JSONEncoder();e.dateEncodingStrategy = .iso8601;e.outputFormatting=[.sortedKeys,.prettyPrinted,.withoutEscapingSlashes]
        try e.encode(value).write(to:url)
    }
    static func main() throws {
        let mode=CommandLine.arguments[1]
        if mode=="verify-reopen" || mode=="verify-corrected-reopen" {
            for name in (mode=="verify-corrected-reopen" ? ["assisted-cue-correction"] : ["fresh-corrected-auto", "fresh-raw-auto", "assisted-reexport"]) {
                let dir=base.appendingPathComponent(name)
                let package=dir.appendingPathComponent("Brahms — String Quartet No.3, Op.67.partsmithproject")
                let d=JSONDecoder.withISO
                let p=try d.decode(Envelope.self,from:Data(contentsOf:package.appendingPathComponent("project.json"))).project
                let doc=PartsmithDocument(project:p,sourcePDFData:try Data(contentsOf:package.appendingPathComponent("source.pdf")))
                try export(doc:doc,out:dir.appendingPathComponent("reopened"))
                print("REOPENED",name);fflush(stdout)
            }
            return
        }
        if mode=="assisted-cue-correction" {
            let input=base.appendingPathComponent("corrected-cues-input/Brahms — String Quartet No.3, Op.67.partsmithproject")
            let p=try JSONDecoder.withISO.decode(Envelope.self,from:Data(contentsOf:input.appendingPathComponent("project.json"))).project
            let source=try Data(contentsOf:input.appendingPathComponent("source.pdf"))
            guard hash(source)=="662aabfdecb2d125151c984fe1dc866ea068668ee9bb74f23f286f552603c14a" else{throw fail("Source hash changed")}
            guard p.bands.allSatisfy({band in band.sourceMarkings.allSatisfy{$0.isValid(in:band)}}) else {throw fail("Invalid copied source geometry")}
            try export(doc:PartsmithDocument(project:p,sourcePDFData:source),out:base.appendingPathComponent(mode))
            return
        }
        let oldPackage=oldDir.appendingPathComponent("Brahms — String Quartet No.3, Op.67.partsmithproject")
        let source=try Data(contentsOf:oldPackage.appendingPathComponent("source.pdf"))
        guard hash(source)=="662aabfdecb2d125151c984fe1dc866ea068668ee9bb74f23f286f552603c14a" else {throw fail("Source hash changed")}
        let d=JSONDecoder();d.dateDecodingStrategy = .iso8601
        let original=try d.decode(Envelope.self,from:Data(contentsOf:oldPackage.appendingPathComponent("project.json"))).project
        let out=base.appendingPathComponent(mode)
        try FileManager.default.createDirectory(at:out,withIntermediateDirectories:true)
        if mode=="assisted-reexport" {
            let doc=PartsmithDocument(project:original,sourcePDFData:source)
            try export(doc:doc,out:out)
            return
        }
        let profile=try d.decode(ScoreExtractionProfile.self,from:Data(contentsOf:URL(fileURLWithPath:"Tests/quality_control/profiles/medium-skewed-06-brahms-string-quartet-no3-op67-imslp-93521.json")))
        let doc=PartsmithDocument(sourcePDFData:source)
        doc.project.pageCount=39
        doc.project.sourceFilename="06_brahms_string_quartet_no3_op67_imslp_93521.pdf"
        doc.project.projectName="Brahms — String Quartet No.3, Op.67"
        if mode=="fresh-corrected-auto" {doc.project.pageRectifications=original.pageRectifications}
        var review:ScoreDetectionReview?,done=false,last=""
        let observer=doc.$scoreDetectionProgress.sink{p in
            guard let p else{return}
            let next="\(p.directionPhase?.rawValue ?? "staves") \(p.completedPages)/\(p.totalPages)"
            if next != last {last=next;print(mode,next);fflush(stdout)}
        }
        let start=Date()
        doc.detectScore(profile:profile,findSourceHeader:true,copySharedDirections:true){r in review=r;done=true}
        while !done && Date().timeIntervalSince(start)<1200 {RunLoop.main.run(until:Date().addingTimeInterval(0.02))}
        observer.cancel()
        guard let r=review else{throw fail("No detection completion")}
        try write(Inventory(source:oldPackage.appendingPathComponent("source.pdf").standardizedFileURL.path,sourceSHA256:hash(source),pages:r.analyses,rectifications:r.rectifications),out.appendingPathComponent("inventory.json"))
        try write(r.plan,out.appendingPathComponent("plan.json"))
        struct Summary:Codable{var mode:String;var seconds:Double;var canApply:Bool;var bands:Int;var excluded:[Int];var issueMessages:[String];var header:SourceHeaderSelection?}
        try write(Summary(mode:mode,seconds:Date().timeIntervalSince(start),canApply:r.plan.canApply,bands:r.plan.bands.count,excluded:r.autoSkippedPageIndices.sorted(),issueMessages:r.directionIssues.map(\.message),header:r.suggestedSourceHeader),out.appendingPathComponent("summary.json"))
        guard r.plan.canApply else{throw fail("Plan unresolved; inventory and plan saved")}
        doc.project.projectSettings.headerDisplayMode = .typed
        doc.project.projectSettings.defaultTitleText="Brahms — String Quartet No.3, Op.67"
        doc.project.projectSettings.defaultComposerText="Johannes Brahms"
        guard doc.addScoreParts(from:r)==604 else{throw fail("Apply did not return 604 bands")}
        try export(doc:doc,out:out)
        print("DONE",mode,Date().timeIntervalSince(start));fflush(stdout)
    }
    static func export(doc:PartsmithDocument,out:URL) throws {
        try FileManager.default.createDirectory(at:out,withIntermediateDirectories:true)
        let package=out.appendingPathComponent("Brahms — String Quartet No.3, Op.67.partsmithproject")
        try FileManager.default.createDirectory(at:package,withIntermediateDirectories:true)
        try write(Envelope(project:doc.project),package.appendingPathComponent("project.json"))
        try doc.sourcePDFData!.write(to:package.appendingPathComponent("source.pdf"))
        let pdf=doc.pdfDocument!
        struct Copy:Codable {var sourceRect:[Double];var destinationRect:[Double];var isBelow:Bool}
        struct Placement:Codable {var bandID:UUID;var sourcePage:Int;var outputPage:Int;var sourceRect:[Double];var destinationRect:[Double];var sourceMarkings:[Copy]}
        struct Part:Codable {var partID:UUID;var name:String;var file:String;var sha256:String;var outputPages:Int;var bandCount:Int;var placements:[Placement]}
        func rect(_ r:CGRect,_ height:Double)->[Double]{[r.minX,height-r.maxY,r.maxX,height-r.minY]}
        var parts:[Part]=[]
        for part in doc.project.parts {
            let layout=try PartLayoutEngine.makePlan(project:doc.project,pageBoundsProvider:{pdf.page(at:$0)?.bounds(for:.mediaBox)},partID:part.id)
            let bands=doc.project.bands.filter{$0.partID==part.id && !$0.excluded}
            guard layout.pages.flatMap(\.placements).map(\.bandID)==bands.map(\.id) else{throw fail("Reordered/dropped bands")}
            let name=part.name+".pdf",url=out.appendingPathComponent(name)
            try PartPDFExporter.export(partID:part.id,document:doc,to:url)
            guard PDFDocument(url:url)?.pageCount==layout.pages.count else{throw fail("Page mismatch")}
            let placements=layout.pages.flatMap{page in page.placements.map{p in
                let h=pdf.page(at:p.sourcePageIndex)!.bounds(for:.mediaBox).height
                return Placement(bandID:p.bandID,sourcePage:p.sourcePageIndex+1,outputPage:page.index+1,sourceRect:rect(p.sourceRect,h),destinationRect:rect(p.destinationRect,layout.pageSize.height),sourceMarkings:p.sourceMarkings.map{Copy(sourceRect:rect($0.sourceRect,h),destinationRect:rect($0.destinationRect,layout.pageSize.height),isBelow:$0.isBelow)})
            }}
            parts.append(Part(partID:part.id,name:part.name,file:name,sha256:hash(try Data(contentsOf:url)),outputPages:layout.pages.count,bandCount:bands.count,placements:placements))
            print(part.name,bands.count,"systems",layout.pages.count,"pages");fflush(stdout)
        }
        try write(parts,out.appendingPathComponent("placements.json"))
        let decoded=try JSONDecoder.withISO.decode(Envelope.self,from:Data(contentsOf:package.appendingPathComponent("project.json"))).project
        // ISO8601 saves whole seconds. Compare the persisted representation,
        // including all crop geometry and metadata, rather than subsecond dates
        // from a just-created in-memory document.
        let e=JSONEncoder();e.dateEncodingStrategy = .iso8601;e.outputFormatting=[.sortedKeys]
        guard try e.encode(decoded)==e.encode(doc.project) else{throw fail("Saved reopen differs")}
    }
}
extension JSONDecoder {static var withISO:JSONDecoder{let d=JSONDecoder();d.dateDecodingStrategy = .iso8601;return d}}
