"""Replay reviewed corrections without changing production detection."""
from pathlib import Path
import json, shutil, hashlib
W=Path('.build/brahms-recheck-2026-10-10')
Q=Path('Tests/quality_control/brahms-recheck-2026-10-10')
P=Path('output/pdf/auto-qc-2026-10-04/brahms-quartet-93521-reviewed-trims')
original=next(P.glob('*.partsmithproject'))
target=W/'corrected-cues-input'/original.name
target.mkdir(parents=True,exist_ok=True)
raw=json.loads((original/'project.json').read_text())
bands={b['id']:b for b in raw['project']['bands']}
expected=json.loads((Q/'manual-cue-additions.json').read_text())
assert hashlib.sha256((original/'source.pdf').read_bytes()).hexdigest()==expected['originalSourceSHA256']
assert hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest()==expected['baseDeliveryManifestSHA256']
for a in expected['additions']:
    b=bands[a['bandID']]
    assert b['pageIndex']+1==a['sourcePage']
    assert a['sourceMarking'] not in b.get('sourceMarkings',[])
    b.setdefault('sourceMarkings',[]).append(a['sourceMarking'])
(target/'project.json').write_text(json.dumps(raw,indent=2)+'\n')
shutil.copy2(original/'source.pdf',target/'source.pdf')
print('Prepared Oct4 reviewed604bands with42old and72new reviewedsourcecopies:',target)
