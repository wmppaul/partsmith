from pathlib import Path
import json,hashlib,math
import pymupdf as fitz
import numpy as np
w=Path('.build/brahms-recheck-2026-10-10');q=Path('Tests/quality_control/brahms-recheck-2026-10-10')
oldDir=Path('output/pdf/auto-qc-2026-10-03/brahms-quartet-93521-viola-in-tempo-repair')
old=json.load(open(oldDir/'manifest.json'));oracle=json.load(open('Tests/quality_control/brahms93521/shared-directions-corrected.json'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.load(open(p))
expected={p['pageNumber']:p['systemsReviewed'] for p in oracle['coverage']}
source=fitz.open(oldDir/'rectified-review-source.pdf')
def contains(a,b,t=1e-8):return a[0]<=b[0]+t and a[1]<=b[1]+t and a[2]>=b[2]-t and a[3]>=b[3]-t
results={}
for mode in ['fresh-corrected-auto','fresh-raw-auto','assisted-reexport','assisted-cue-correction']:
 folder=w/mode;parts=load(folder/'placements.json');project=load(next(folder.glob('*.partsmithproject/project.json')))['project'];summary={}
 assert sha(next(folder.glob('*.partsmithproject/source.pdf')))==old['sourceSHA256']
 assert len(project['bands'])==604 and len(parts)==4
 if mode.startswith('assisted-'):
  planned={p['name']:p['placements'] for p in old['parts']}
  ids={p['partID']:o['id'] for p,o in zip(parts,old['parts'])}
 else:
  plan=load(folder/'plan.json');planned={p['name']:[] for p in parts};names={p['id']:p['name'] for p in plan['parts']}
  for page in plan['pages']:
   for a in page['assignments']:planned[names[a['partID']]].append(a)
  ids={p['partID']:o['id'] for p,o in zip(parts,old['parts'])}
  summary.update(load(folder/'summary.json'))
 order=[];wholeNeighbors=[];partialLineCounts=0;layout=[];copyCoverage=[]
 inventory=load(w/'fresh-corrected-auto/inventory.json') if mode!='fresh-raw-auto' else load(folder/'inventory.json')
 pageStaves={p['pageIndex']+1:p for p in inventory['pages']}
 for part in parts:
  assert part['bandCount']==151 and len(part['placements'])==151
  seen=[];minGap=1e9;heights=[]
  rows=planned[part['name']]
  for placed,a in zip(part['placements'],rows):
   pg=placed['sourcePage'];sys=a['system'] if mode.startswith('assisted-') else a['systemIndex']+1
   seen.append((pg,sys));box=placed['destinationRect'];src=placed['sourceRect'];h=pageStaves[pg]['pageHeight']
   assert 0<=box[0]<box[2]<=612 and 0<=box[1]<box[3]<=792
   ratio=(box[2]-box[0])/(src[2]-src[0]);assert abs((box[3]-box[1])/(src[3]-src[1])-ratio)<1e-7
   cs=a['candidateIDs'];staves=pageStaves[pg]['staves']
   target=[s for s in staves if s['id'] in cs]
   for st in target:
    ys=[y*h for y in st['staffLineFractions']];assert src[1]<=ys[0] and src[3]>=ys[-1];heights.append((ys[-1]-ys[0])*ratio)
   for st in staves:
    if st['id'] in cs:continue
    ys=[y*h for y in st['staffLineFractions']]
    included=sum(src[1]<=y<=src[3] for y in ys);partialLineCounts+=included
    if included==5:wholeNeighbors.append({'part':part['name'],'sourcePage':pg,'system':sys,'outputPage':placed['outputPage'],'foreignStaffID':st['id']})
  assert seen==[(p,s) for p in range(1,40) for s in range(1,expected[p]+1)],(mode,part['name'],'coverage')
  for pg in range(1,part['outputPages']+1):
   group=[p for p in part['placements'] if p['outputPage']==pg];items=[]
   for p in group:
    items.append((p['destinationRect'][1],p['destinationRect'][3]))
    items.extend((c['destinationRect'][1],c['destinationRect'][3]) for c in p['sourceMarkings'])
   items.sort()
   assert all(b[0]>=a[1]-1e-6 for a,b in zip(items,items[1:])),(mode,part['name'],pg,'overlap')
   gaps=[b['destinationRect'][1]-a['destinationRect'][3] for a,b in zip(group,group[1:])];minGap=min([minGap]+gaps)
  layout.append({'part':part['name'],'systems':len(seen),'outputPages':part['outputPages'],'staffCoreHeightPoints':[min(heights),max(heights)],'minimumMusicGap':minGap})
  # Strict source rectangle coverage is intentionally separate from pixel claims.
  if mode!='fresh-raw-auto':
   partid=ids[part['partID']]
   bysystem={(p['sourcePage'],a['system'] if mode.startswith('assisted-') else a['systemIndex']+1):p for p,a in zip(part['placements'],rows)}
   for cue in oracle['entries']:
    if partid not in cue['copyTargetPartIDs']:continue
    p=bysystem[(cue['pageNumber'],cue['systemNumber'])];regions=[p['sourceRect']]+[c['sourceRect'] for c in p['sourceMarkings']]
    complete=any(contains(r,cue['rect']) for r in regions)
    # Count black source pixels outside the union, preserving padding misses separately.
    rect=fitz.Rect(cue['rect']);page=source[cue['pageNumber']-1];pix=page.get_pixmap(matrix=fitz.Matrix(6,6),clip=rect,colorspace=fitz.csGRAY,alpha=False)
    a=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width);yy,xx=np.indices(a.shape);x=(xx+pix.x+0.5)/6;y=(yy+pix.y+0.5)/6
    covered=np.zeros(a.shape,dtype=bool)
    for r in regions:covered|=(x>=r[0])&(x<=r[2])&(y>=r[1])&(y<=r[3])
    missing=int(np.count_nonzero((a<160)&~covered));total=int(np.count_nonzero(a<160))
    copyCoverage.append({'id':cue['id'],'text':cue['text'],'kind':cue['kind'],'part':part['name'],'sourcePage':cue['pageNumber'],'system':cue['systemNumber'],'completeOracleRectangleCovered':complete,'blackPixelsOutsideStoredSourceGeometry':missing,'oracleBlackPixels':total})
 summary.update({'sourceSHA256':old['sourceSHA256'],'sourcePages':39,'identityOrderValidatedAgainstSourceReviewedOracleCoverage':True,'totalSystems':151,'totalBands':604,'sourceCopies':sum(len(p['sourceMarkings']) for part in parts for p in part['placements']),'parts':layout,'wholeNeighborIncidences':wholeNeighbors,'foreignLineCentersRetained':partialLineCounts,'copyOracleCoverage':copyCoverage})
 results[mode]=summary
(q/'audit.json').write_text(json.dumps(results,indent=2)+'\n')
for mode,r in results.items():
 print(mode,'pages',sum(p['outputPages'] for p in r['parts']),'copies',r['sourceCopies'],'whole foreign cores',len(r['wholeNeighborIncidences']),'oracle apparent missing',sum(x['blackPixelsOutsideStoredSourceGeometry']>0 for x in r['copyOracleCoverage']))
