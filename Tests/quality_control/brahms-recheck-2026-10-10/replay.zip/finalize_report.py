from pathlib import Path
import json, hashlib, copy, csv
import pymupdf as fitz

W=Path('.build/brahms-recheck-2026-10-10')
Q=Path('Tests/quality_control/brahms-recheck-2026-10-10')
F=W/'assisted-cue-correction'
P=Path('output/pdf/auto-qc-2026-10-04/brahms-quartet-93521-reviewed-trims')
load=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
parts=load(F/'placements.json')
old=load(P/'manifest.json')
base=load(next(P.glob('*.partsmithproject/project.json')))['project']
project=load(next(F.glob('*.partsmithproject/project.json')))['project']
before={b['id']:b for b in base['bands']}
after={b['id']:b for b in project['bands']}
assert set(before)==set(after) and len(after)==604
add=load(Q/'manual-cue-additions.json')['additions']
assert len(add)==72
newByID={}
for a in add:newByID.setdefault(a['bandID'],[]).append(a['sourceMarking'])
for bid,b in before.items():
    c=copy.deepcopy(after[bid]); marks=c.pop('sourceMarkings',[])
    original=copy.deepcopy(b); oldmarks=original.pop('sourceMarkings',[])
    assert c==original,(bid,'main-band metadata changed')
    assert marks==oldmarks+newByID.get(bid,[]),(bid,'source copies changed unexpectedly')
for a,b in zip(base['parts'],project['parts']):
    normalized=copy.deepcopy(a)
    normalized['layoutSettings'].setdefault('usesSharedLayout',True)
    assert normalized==b,(a['name'],'part metadata changed beyond current native shared-layout default')
for k,v in base.items():
    if k not in ('bands','modifiedAt','parts'):assert project[k]==v,(k,'project settings changed')

inventory=[]
for part, parent in zip(parts,old['parts']):
    assert len(part['placements'])==len(parent['placements'])==151
    for index,(p,o) in enumerate(zip(part['placements'],parent['placements']),1):
        assert max(abs(a-b) for a,b in zip(p['sourceRect'],o['sourceRect']))<1e-8
        assert p['sourcePage']==o['sourcePage']
        inventory.append({'id':o['id'],'bandUUID':p['bandID'],'partID':parent['id'],
            'partName':part['name'],'order':index,'sourcePage':p['sourcePage'],
            'system':o['system'],'outputPage':p['outputPage'],'kind':'music',
            'candidateIDs':o['candidateIDs'],'sourceRect':p['sourceRect'],
            'destinationRect':p['destinationRect'],'sourceMarkings':p['sourceMarkings'],
            'provenance':'Oct4 source-reviewed crop; Oct10 current native export and reviewed source cue copies'})
write(Q/'complete-band-inventory.json',{'coordinates':'top-down PDF points, one-based pages/systems',
    'sourceSHA256':old['sourceSHA256'],'parentManifestSHA256':sha(P/'manifest.json'),
    'sourcePages':39,'sourceSystems':151,'coverPages':[1],'rows':inventory})
with (Q/'complete-band-inventory.csv').open('w',newline='') as f:
    keys=['id','bandUUID','partName','order','sourcePage','system','outputPage']
    wr=csv.DictWriter(f,fieldnames=keys);wr.writeheader()
    wr.writerows({k:r[k] for k in keys} for r in inventory)
write(Q/'parent-preservation.json',{'parentDirectory':str(P),'parentManifestSHA256':sha(P/'manifest.json'),
    'all604BandIdentitiesOrderCropGeometryAndMetadataUnchanged':True,
    'allOtherProjectSettingsIncluding9RectificationsUnchangedExceptModifiedAtAndNativeUsesSharedLayoutDefault':True,
    'nativeSchemaDefaultAdded':{'part.layoutSettings.usesSharedLayout':True},
    'all42ExistingSourceMarkingRectanglesRetainedUnchanged':True,
    'onlyAdditional72SourceMarkingRectanglesAdded':True,
    'manualViolaP8S2BottomPoints':284,
    'sevenOct4ManualSourceReviewedTrimEdgesRetained':load(Q/'retained-seven-trims.json')['changes']})

reopened=load(F/'reopened/placements.json');rrows=[]
for p,r in zip(parts,reopened):
    assert p['placements']==r['placements']
    a=fitz.open(F/p['file']);b=fitz.open(F/'reopened'/r['file'])
    assert len(a)==len(b)==p['outputPages']
    assert all(x.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False).samples==
               y.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False).samples for x,y in zip(a,b))
    rrows.append({'part':p['name'],'pages':len(a),'placementsIdentical':True,
        'allReopenedPagePixelsIdenticalAt36DPI':True})
write(Q/'reopen-verification.json',{'method':'Current native saved project decode and complete four-part reexport; every placement compared exactly, all 78 PDF pages compared at 36 DPI. PDF binary metadata hashes may differ.','rows':rrows})

pages=load(Q/'final-v-broad-page-comparison.json')
for p in pages:
    p['review']='pixel-identical to visually viewed broad cue export' if p['sameCompletePagePixelsAsViewedBroad'] else 'visually viewed actual final output page'
write(Q/'final-page-review.json',{'scope':'Complete 78-page pagination overview, readable music/marks and crop/placement sanity. 35 full-page PNGs identical to prior viewed broad export; all 43 changed pages visually viewed. Does not replace full-source note-by-note ownership review.','pages':pages})
hashes=load(Q/'source-hashes.json')
current={p:sha(Path(p)) for p in hashes}
assert current==hashes,'Production source files changed during run'
write(Q/'source-hashes-final.json',{'unchanged':True,'files':current})
print('Verified all604 parent crops and metadata;42prior+72new copies;78 saved/reopened page rasters identical;43 changed pages viewed;production sources unchanged')
