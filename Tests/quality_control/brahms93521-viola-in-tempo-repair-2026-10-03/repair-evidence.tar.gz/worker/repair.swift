import AppKit
import CryptoKit
import Foundation
import PDFKit

@main enum RepairViola {
 struct Envelope: Codable { var project: ProjectData }
 static func hash(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
 static func rect(_ x: CGRect, _ page: CGRect) -> [Double] { [x.minX-page.minX,page.maxY-x.maxY,x.maxX-page.minX,page.maxY-x.minY] }
 static func json(_ object: Any, _ url: URL) throws { try JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted,.sortedKeys,.withoutEscapingSlashes]).write(to: url) }
 static func main() throws {
  let root=URL(fileURLWithPath:FileManager.default.currentDirectoryPath)
  let base=root.appendingPathComponent(".build/brahms93521-full-production-workflow-draft-2026-10-03/production-crop-draft-parts")
  let work=root.appendingPathComponent(".build/brahms93521-viola-in-tempo-2026-10-03")
  var manifest=try JSONSerialization.jsonObject(with: Data(contentsOf:base.appendingPathComponent("manifest.json"))) as! [String:Any]
  let package=manifest["project"] as! String
  let source=try Data(contentsOf:base.appendingPathComponent(package).appendingPathComponent("source.pdf"))
  let originalBytes=try Data(contentsOf:base.appendingPathComponent(package).appendingPathComponent("project.json"))
  let decoder=JSONDecoder();decoder.dateDecodingStrategy = .iso8601
  let encoder=JSONEncoder();encoder.dateEncodingStrategy = .iso8601;encoder.outputFormatting = [.prettyPrinted,.sortedKeys,.withoutEscapingSlashes]
  let original=try decoder.decode(Envelope.self,from:originalBytes).project
  var document=PartsmithDocument(project:original,sourcePDFData:source)
  let targetID=UUID(uuidString:"4234AE04-F8EB-4446-9095-1A5961992AA6")!
  let part=original.parts.first { $0.name == "Viola" }!
  let target=original.bands.first { $0.id == targetID }!
  precondition(original.bands.count==604 && original.pageRectifications.count==9)
  precondition(!original.pageRectifications.contains { $0.pageIndex == 7 })
  precondition(original.bands.reduce(0) { $0+$1.sourceMarkings.count }==42)
  precondition(target.partID==part.id && target.pageIndex==7 && target.generatedRest==nil)
  let bounds=document.pdfDocument!.page(at:7)!.bounds(for:.mediaBox)
  precondition(bounds.height==614 && bounds.width==427)
  precondition(abs(target.bottomFraction*bounds.height-280.53013910355486)<1e-9)
  document.updateBand(targetID,topFraction:target.topFraction,bottomFraction:284.0/bounds.height)
  var expected=original;let index=expected.bands.firstIndex { $0.id==targetID }!
  expected.bands[index].bottomFraction=284.0/bounds.height;expected.modifiedAt=document.project.modifiedAt
  precondition(document.project==expected, "Only the target bottom and transaction date may change")
  let output=work.appendingPathComponent("parts")
  precondition(!FileManager.default.fileExists(atPath:output.path))
  try FileManager.default.copyItem(at:base,to:output)
  let saved=try encoder.encode(Envelope(project:document.project));try saved.write(to:output.appendingPathComponent(package).appendingPathComponent("project.json"))
  let reopened=PartsmithDocument(project:try decoder.decode(Envelope.self,from:saved).project,sourcePDFData:try Data(contentsOf:output.appendingPathComponent(package).appendingPathComponent("source.pdf")))
  let reopenedBytes = try encoder.encode(Envelope(project:reopened.project))
  precondition(reopenedBytes == saved)
  precondition(reopened.sourcePDFData==source)
  document=reopened
  let pdf=document.pdfDocument!
  let layout=try PartLayoutEngine.makePlan(project:document.project,pageBoundsProvider:{pdf.page(at:$0)?.bounds(for:.mediaBox)},partID:part.id)
  let stored=document.project.bands.filter { $0.partID==part.id }
  precondition(stored.count==151 && layout.pages.flatMap(\.placements).flatMap(\.sourceBandIDs)==stored.map(\.id))
  let outPDF=output.appendingPathComponent("Viola.pdf")
  try PartPDFExporter.export(partID:part.id,document:document,to:outPDF)
  var parts=manifest["parts"] as! [[String:Any]]
  let partIndex=parts.firstIndex { $0["id"] as? String == "viola" }!
  let oldPlacements=parts[partIndex]["placements"] as! [[String:Any]]
  let oldByBand=Dictionary(uniqueKeysWithValues:zip(stored.map(\.id),oldPlacements))
  var placements=[[String:Any]]()
  for page in layout.pages {
   for placed in page.placements {
    var row=oldByBand[placed.bandID]!
    let sourceBounds=pdf.page(at:placed.sourcePageIndex)!.bounds(for:.mediaBox)
    let outputBounds=CGRect(origin:.zero,size:layout.pageSize)
    row["outputPage"]=page.index+1
    row["sourceRect"]=rect(placed.sourceRect,sourceBounds)
    row["destinationRect"]=rect(placed.destinationRect,outputBounds)
    row["sourceMarkings"]=placed.sourceMarkings.map { marking -> [String:Any] in
     var x:[String:Any]=["sourceRect":rect(marking.sourceRect,sourceBounds),"destinationRect":rect(marking.destinationRect,outputBounds)]
     if marking.isBelow { x["isBelow"]=true };return x
    }
    placements.append(row)
   }
  }
  precondition(placements.count==151)
  parts[partIndex]["placements"]=placements;parts[partIndex]["outputPages"]=layout.pages.count
  parts[partIndex]["systemsPerPage"]=layout.pages.map { $0.placements.count }
  parts[partIndex]["sha256"]=hash(try Data(contentsOf:outPDF));manifest["parts"]=parts
  manifest["status"]="reviewed single-crop alternative — existing draft limitations remain"
  manifest["manualCropRepair"]=["bandID":"p8-s2-viola","bandUUID":targetID.uuidString,"sourcePage":8,"bottomBefore":280.53013910355486,"bottomAfter":284.0,"sourceGuard":"source-guard-before-edit.json","operation":"PartsmithDocument.updateBand; exact original source preserved"] as [String:Any]
  try json(manifest,output.appendingPathComponent("manifest.json"))
  // Preserve the previous detection plan as provenance, not as the adjusted project geometry.
  try FileManager.default.moveItem(at:output.appendingPathComponent("plan.json"),to:output.appendingPathComponent("original-detection-plan.json"))
  let proof:[String:Any]=["sourceSHA256":hash(source),"originalProjectSHA256":hash(originalBytes),"finalProjectSHA256":hash(saved),"all604BandUUIDsAndOrderPreserved":original.bands.map(\.id)==document.project.bands.map(\.id),"onlyOneBottomEdgeAndModificationDateChanged":true,"rectificationsExact":original.pageRectifications==document.project.pageRectifications,"sourceMarkingsExact":zip(original.bands,document.project.bands).allSatisfy {$0.sourceMarkings==$1.sourceMarkings},"nativeSaveDecodeReopenCanonicalBytesExact":true,"violaPageCount":layout.pages.count,"violaPlacements":placements.count,"allOtherPDFsCopiedWithoutReexport":true,"sourcePageHeight":bounds.height,"finalBottom":284.0]
  try json(proof,work.appendingPathComponent("native-proof.json"))
  print("Native one-edge edit, save/reopen and Viola export complete: \(layout.pages.count) pages; 604 original references, 9 rectifications and 42 source copies preserved.")
 }
}
