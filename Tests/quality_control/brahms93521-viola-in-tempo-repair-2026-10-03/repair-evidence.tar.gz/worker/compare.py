from pathlib import Path
import json,hashlib,pymupdf as f
w=Path('.build/brahms93521-viola-in-tempo-2026-10-03');base=Path('.build/brahms93521-full-production-workflow-draft-2026-10-03/production-crop-draft-parts');load=lambda p:json.load(open(p));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=load(base/'manifest.json');after=load(w/'parts/manifest.json');guard=load(w/'source-guard-before-edit.json');old={p['id']:p for p in before['parts']};new={p['id']:p for p in after['parts']};assert old.keys()==new.keys();diffs=[];placementdiffs=[];sourceCopies=0
for pid,p in new.items():
 assert sha(w/'parts'/p['file'])==p['sha256'];assert p['outputPages']==old[pid]['outputPages'];assert len(p['placements'])==len(old[pid]['placements'])==151
 if pid!='viola':assert p==old[pid];assert sha(w/'parts'/p['file'])==sha(base/p['file'])
 for a,b in zip(old[pid]['placements'],p['placements']):
  assert a['id']==b['id'];assert a['candidateIDs']==b['candidateIDs'];assert a['sourcePage']==b['sourcePage'];assert a['system']==b['system'];sourceCopies+=len(b['sourceMarkings'])
  assert [(x['sourceRect'],x.get('isBelow',False)) for x in a['sourceMarkings']]==[(x['sourceRect'],x.get('isBelow',False)) for x in b['sourceMarkings']]
  if a['sourceRect']!=b['sourceRect']:diffs.append(dict(id=b['id'],before=a['sourceRect'],after=b['sourceRect']))
  if a['destinationRect']!=b['destinationRect'] or a['outputPage']!=b['outputPage']:placementdiffs.append(dict(id=b['id'],oldPage=a['outputPage'],newPage=b['outputPage'],before=a['destinationRect'],after=b['destinationRect']))
assert sourceCopies==42;assert len(diffs)==1 and diffs[0]['id']=='p8-s2-viola';assert diffs[0]['after']==[0,227.6901081916538,427,284.0]
assert diffs[0]['after'][3]>guard['independentSourceRasterCoordinates']['onePixelWhiteClearanceBottomPDF']
d0=f.open(base/'Viola.pdf');d1=f.open(w/'parts/Viola.pdf');out=w/'changed-pages';out.mkdir(exist_ok=True);pages=[]
for i,(a,b) in enumerate(zip(d0,d1)):
 pa=a.get_pixmap(matrix=f.Matrix(1.7,1.7));pb=b.get_pixmap(matrix=f.Matrix(1.7,1.7));same=pa.samples==pb.samples;row=dict(page=i+1,pixelIdentical=same)
 if not same:
  for key,pix in [('before',pa),('after',pb)]:
   path=out/f'{key}-page-{i+1:02}.png';pix.save(path);row[key]=dict(path=str(path),sha256=sha(path))
 pages.append(row)
# Changed source/result details; output coordinates follow the exact native placement.
target=next(x for x in new['viola']['placements'] if x['id']=='p8-s2-viola');a=target['sourceRect'];b=target['destinationRect'];scale=(b[2]-b[0])/(a[2]-a[0]);focus=[70,265,122,286]
cl=f.Rect(b[0]+(focus[0]-a[0])*scale,b[1]+(focus[1]-a[1])*scale,b[0]+(focus[2]-a[0])*scale,b[1]+(focus[3]-a[1])*scale)
d1[target['outputPage']-1].get_pixmap(matrix=f.Matrix(6,6),clip=cl).save(w/'repaired-output-detail.png')
projectBefore=load(base/before['project']/'project.json')['project'];projectAfter=load(w/'parts'/after['project']/'project.json')['project'];changes=[]
for a,b in zip(projectBefore['bands'],projectAfter['bands']):
 assert a['id']==b['id']
 for k in set(a)|set(b):
  if a.get(k)!=b.get(k):changes.append(dict(id=a['id'],field=k,before=a.get(k),after=b.get(k)))
assert len(changes)==1 and changes[0]['id']==guard['sourceBandUUID'] and changes[0]['field']=='bottomFraction'
assert projectBefore['pageRectifications']==projectAfter['pageRectifications'];assert projectBefore['parts']==projectAfter['parts'];assert projectBefore['projectSettings']==projectAfter['projectSettings']
assert sha(w/'parts'/after['project']/'source.pdf')==before['sourceSHA256']
report=dict(scope='Only Viola re-exported. Three other PDFs byte-identical; all16 Viola pages compared at the same1.7× raster; only changed pages retained for visual review.',sourceSHA256=before['sourceSHA256'],baselineManifestSHA256=sha(base/'manifest.json'),finalManifestSHA256=sha(w/'parts/manifest.json'),all604BandIdentitiesAndOrderExact=True,all9RectificationsExact=True,all42SourceCopiesExact=True,all4PartSettingsExact=True,sourceCropChanges=diffs,projectBandFieldChanges=changes,placementChanges=placementdiffs,violaPages=pages,changedViolaPages=[x['page'] for x in pages if not x['pixelIdentical']],unchangedViolaPages=[x['page'] for x in pages if x['pixelIdentical']],targetOutputPage=target['outputPage'],sourceGuardContained=True,extraNeighborInk='Expansion intersects original Cello upper staff-line/clef tops. It cannot include a whole Cello staff; source review checks actual fragments. Existing broader crop limitations remain.')
(w/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['sourceCropChanges','changedViolaPages','unchangedViolaPages','targetOutputPage']},indent=2))
