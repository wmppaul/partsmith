#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
p=.build/numbered-envelope-independent-2026-10-03
core=$p/candidate/Core
mkdir -p "$p/original29" "$p/addendum6"
xcrun swiftc -O -module-cache-path "$p/module-cache" "$core/Detection/StaffBandDetector.swift" "$core/Detection/ScoreExtractionPlanner.swift" "$core/Detection/ScoreSharedEnding.swift" "$core/Detection/ScoreSharedEndingDetector.swift" "$core/Detection/ScoreLocalEndingPreservation.swift" "$core/Detection/NativeScorePageAnalyzer.swift" "$p/evaluate.swift" -o "$p/evaluate" > "$p/small-build.log" 2>&1
"$p/evaluate" .build/musical-span-independent-2026-10-03/inputs "$p/original29/results.json" > "$p/original29/run.log" 2>&1
"$p/evaluate" .build/musical-span-attached-addendum-2026-10-03/inputs "$p/addendum6/results.json" > "$p/addendum6/run.log" 2>&1
