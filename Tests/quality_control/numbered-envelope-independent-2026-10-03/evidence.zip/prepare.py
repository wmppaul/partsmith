from pathlib import Path
import hashlib,json,shutil
R=Path('.build/numbered-envelope-independent-2026-10-03');S=Path('.build/numbered-line-envelope-compatibility-2026-10-03');P=Path('.build/combined-span-v4-independent-2026-10-03')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(S/'candidate/Core/Detection/NativeScorePageAnalyzer.swift')=='e32b5a76928b505efbeba6fa5bc9aef4b58ed0e2b7d11ddeef3269b73570996f'
assert sha(S/'protocol-before-results.json')=='caced5d8a638510b906541cd02fb23141ac04582ecf6e9e37a318a088691de2f'
shutil.copytree(S/'candidate/Core',R/'candidate/Core')
(R/'candidate/source-hashes.json').write_text(json.dumps({str(p.relative_to(S/'candidate/Core')):sha(p)for p in sorted((S/'candidate/Core').rglob('*'))if p.is_file()},indent=2)+'\n')
for f in ['controls297.swift','expanded336.swift']:
 assert sha(S/f)==sha(P/f);shutil.copyfile(S/f,R/f)
for f in ['controls297-pixels.swift','observer297.patch']:shutil.copyfile(P/f,R/f)
assert sha(R/'controls297-pixels.swift')=='e6327ef291d7e352a7790b8e82e06ff0e91d267574f809079705e3b73bf0ecf4'
(R/'baseline/controls297-pixels-run').mkdir(parents=True)
shutil.copyfile(P/'baseline/controls297-pixels-run/results.json',R/'baseline/controls297-pixels-run/results.json')
shutil.copyfile(P/'baseline297-reproduction.json',R/'prior-baseline297-reproduction.json')
shutil.copyfile(S/'protocol-before-results.json',R/'candidate-protocol-before-results.json')
s=(P/'build-run.sh').read_text().replace(str(P),str(R));(R/'build-run.sh').write_text(s)
s=(P/'compare297.py').read_text().replace(str(P),str(R));(R/'compare297.py').write_text(s)
bindings={str(p):sha(p)for p in [S/'candidate/Core/Detection/NativeScorePageAnalyzer.swift',S/'protocol-before-results.json',R/'controls297.swift',R/'controls297-pixels.swift',R/'expanded336.swift',P/'baseline/controls297-pixels-run/results.json',P/'baseline297-reproduction.json',Path('.build/ownership-alternatives-2026-10-03/results297.json'),Path('.build/ownership-alternatives-2026-10-03/results336.json')]}
(R/'input-bindings-before-results.json').write_text(json.dumps(bindings,indent=2)+'\n')
protocol={'scope':'One unchanged297 exact source pixel observer and one unchanged336 envelope run against frozen narrow compatibility candidate. Reuse exact previously validated297 baseline; no new baseline native execution.','candidateNative':sha(S/'candidate/Core/Detection/NativeScorePageAnalyzer.swift'),'gates':'No newly lost source-owned pixel compared to original production baseline, including existing failures. No new whole-neighbor inclusion for clean/separation negatives or new global ownership union. Full recovery of old failures is not required. Only if these limited gates pass, run unchanged29+6 against their original baseline masks.','inputs':'All original constructors, transforms, scales, masks, owner definitions and observers are unchanged; source bytes/mask sets must match every case. No post-result threshold changes or new fixture.'}
(R/'independent-protocol-before-results.json').write_text(json.dumps(protocol,indent=2)+'\n')
print('protocol',sha(R/'independent-protocol-before-results.json'),'bindings',sha(R/'input-bindings-before-results.json'))
