from pathlib import Path
import json,hashlib,collections
R=Path('.build/numbered-envelope-independent-2026-10-03')
b=json.loads((R/'baseline/controls297-pixels-run/results.json').read_text());c=json.loads((R/'candidate/controls297-pixels-run/results.json').read_text());old=json.loads(Path('.build/ownership-alternatives-2026-10-03/results297.json').read_text())
def stripped(v):
 d={k:x for k,x in v.items() if k not in ['sourceRawSHA256','sourceOwnershipSHA256','components']}
 d['targets']=[{k:x for k,x in t.items() if k not in ['sourcePixels','sourcePixelIndices','sourceMaskSHA256','lostPixelIndices']}for t in d['targets']];return d
assert len(b)==len(c)==len(old)==297
oldDelta=[{'caseIndex':i,'old':o,'new':stripped(x)}for i,(o,x)in enumerate(zip(old,b))if o!=stripped(x)]
(R/'baseline297-reproduction.json').write_text(json.dumps({'exact':not oldDelta,'differences':oldDelta},indent=2)+'\n')
assert not oldDelta,'Baseline differs from frozen original'
ownerRows=[];caseRows=[]
for i,(x,y)in enumerate(zip(b,c)):
 for k in ['kind','scale','tilt','bow','imageSize','expectsSeparation','sourceRawSHA256','sourceOwnershipSHA256']:assert x[k]==y[k]
 assert x['planCanApply'] and y['planCanApply']
 key={k:x[k]for k in ['kind','scale','tilt','bow']}; key['caseIndex']=i
 for a,z in zip(x['targets'],y['targets']):
  for k in ['owner','sourceEnvelope','sourcePixels','sourcePixelIndices','sourceMaskSHA256']:assert a[k]==z[k]
  oi=set(a['lostPixelIndices']);ni=set(z['lostPixelIndices']);assert oi<=set(a['sourcePixelIndices']) and ni<=set(z['sourcePixelIndices'])
  ownerRows.append(dict(key,owner=a['owner'],sourcePixels=a['sourcePixels'],sourceEnvelope=a['sourceEnvelope'],baselineCrop=a['crop'],candidateCrop=z['crop'],baselineLost=len(oi),candidateLost=len(ni),newlyLostPixelIndices=sorted(ni-oi),recoveredPixelIndices=sorted(oi-ni)))
 count=lambda v,alt:collections.Counter(json.dumps(t,sort_keys=True)for t in v['components']if(t.get('isOwnershipAlternative')is True)==alt)
 caseRows.append(dict(key,expectsSeparation=x['expectsSeparation'],baselineWholeNeighbors=x['wholeNeighborCount'],candidateWholeNeighbors=y['wholeNeighborCount'],wholeNeighborChange=y['wholeNeighborCount']-x['wholeNeighborCount'],baselineAllTargetsPreserved=x['allTargetsPreserved'],candidateAllTargetsPreserved=y['allTargetsPreserved'],ordinaryComponentMultisetEqual=count(x,False)==count(y,False),removedBaselineAlternatives=[json.loads(z)for z in(count(x,True)-count(y,True)).elements()],addedAlternativeComponents=[json.loads(z)for z in(count(y,True)-count(x,True)).elements()]))
fresh=json.loads(Path('.build/musical-span-independent-2026-10-03/baseline/results.json').read_text());f=next(x for x in fresh['cases']if x['id']=='original-case176')
assert b[176]['kind']=='edgeMusicBroken' and b[176]['scale']==1 and b[176]['tilt']==0 and b[176]['bow']==10
assert f['sourceRawSHA256']==b[176]['sourceRawSHA256']
for a,z in zip(f['targets'],b[176]['targets']):
 for k in ['sourcePixels','sourceEnvelope','sourceMaskSHA256','lostPixelIndices']:assert a[k]==z[k],k
summary={'cases':297,'owners':891,'sourceBindingsExact':True,'baselineReproducesOriginal297Exactly':True,'case176ReproducesIndependentSourceAndMaskExactly':True,'baselineCompleteCases':sum(x['allTargetsPreserved']for x in b),'candidateCompleteCases':sum(x['allTargetsPreserved']for x in c),'baselineCompleteOwners':sum(x['baselineLost']==0 for x in ownerRows),'candidateCompleteOwners':sum(x['candidateLost']==0 for x in ownerRows),'baselineLostPixels':sum(x['baselineLost']for x in ownerRows),'candidateLostPixels':sum(x['candidateLost']for x in ownerRows),'newlyLostPixels':sum(len(x['newlyLostPixelIndices'])for x in ownerRows),'recoveredPixels':sum(len(x['recoveredPixelIndices'])for x in ownerRows),'casesWithIncreasedWholeNeighborCount':sum(x['wholeNeighborChange']>0 for x in caseRows),'newWholeNeighborRelationsNetPositiveByCase':sum(max(0,x['wholeNeighborChange'])for x in caseRows),'expectsSeparationCasesWithNewNeighbors':sum(x['expectsSeparation']and x['wholeNeighborChange']>0 for x in caseRows),'ordinaryComponentsChangedCases':sum(not x['ordinaryComponentMultisetEqual']for x in caseRows),'removedBaselineAlternativeCases':sum(bool(x['removedBaselineAlternatives'])for x in caseRows),'case176':[x for x in ownerRows if x['caseIndex']==176]}
(R/'comparison297.json').write_text(json.dumps({'summary':summary,'cases':caseRows,'owners':ownerRows},indent=2)+'\n');(R/'summary297.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='case176'},indent=2))
old336=json.loads(Path('.build/ownership-alternatives-2026-10-03/results336.json').read_text());new336=json.loads((R/'candidate/expanded336-run/results.json').read_text());assert len(old336)==len(new336)==336
for a,z in zip(old336,new336):
 for k in ['headStyle','kind','scale','tilt','inset','sourceEnvelope']:assert a.get(k)==z.get(k)
r={'cases':336,'allCandidateSourceEnvelopesRetained':all(x['bothCropsPreserveSource']for x in new336),'newFailedEnvelopes':[i for i,(a,z)in enumerate(zip(old336,new336))if a['bothCropsPreserveSource']and not z['bothCropsPreserveSource']],'newUpperTargetFailures':[i for i,(a,z)in enumerate(zip(old336,new336))if a['preservesUpperTarget']and not z['preservesUpperTarget']],'changedCases':[{'index':i,'baseline':a,'candidate':z}for i,(a,z)in enumerate(zip(old336,new336))if a!=z]}
(R/'comparison336.json').write_text(json.dumps(r,indent=2)+'\n');print('336:',{k:len(v)if isinstance(v,list)else v for k,v in r.items()})
