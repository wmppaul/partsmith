from pathlib import Path
import json,hashlib,shutil,zipfile,subprocess
R=Path('.build/numbered-envelope-independent-2026-10-03');D=Path('Tests/quality_control/numbered-envelope-independent-2026-10-03');D.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for rel,h in json.loads((R/'candidate/source-hashes.json').read_text()).items():assert sha(R/'candidate/Core'/rel)==h
for rel,h in json.loads((R/'input-bindings-before-results.json').read_text()).items():assert sha(Path(rel))==h
for study in ['musical-span-independent-2026-10-03','musical-span-attached-addendum-2026-10-03']:
 p=Path('.build')/study
 for rel,h in json.loads((p/'input-manifest.json').read_text()).items():assert sha(p/rel)==h
s=json.loads((R/'summary297.json').read_text());a=json.loads((R/'comparison297.json').read_text());b=json.loads((R/'comparison336.json').read_text());small={n:json.loads((R/n/'summary.json').read_text())for n in ['original29','addendum6']}
assert s['newlyLostPixels']==0 and s['casesWithIncreasedWholeNeighborCount']==0 and b['allCandidateSourceEnvelopesRetained']and not b['newUpperTargetFailures']
assert all(v['newlyLostPixels']==0 and v['newSpuriousWholeNeighborRelations']==0 for v in small.values())
verdict={'scope':'Independent unchanged297 exact source-owned pixel comparison,336 fixed envelopes, original29 and prospective6.','preservationGate':'pass; no newly omitted baseline-owned pixel','separationGate':'pass; no increased whole-neighbor count, all27 junction negatives zero','existingFailures':'59 incomplete297cases and all35+6 incomplete smaller-suite owners remain unfinished','releaseScope':'Suitable for subsequent real-score evaluation only; no release approval, production modification or delivered output.','newlyLostPixels297':0,'recoveredPixels297':12,'wholeNeighborRelationsBefore':sum(x['baselineWholeNeighbors']for x in a['cases']),'wholeNeighborRelationsAfter':sum(x['candidateWholeNeighbors']for x in a['cases']),'changed297OwnerCrops':sum(x['baselineCrop']!=x['candidateCrop']for x in a['owners']),'smallSuiteSummaries':small}
(R/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
# Preserve exact static delta without running oldNative again.
old=Path('.build/brahms-numbered-lines-2026-10-03/candidate-v2/Core/Detection/NativeScorePageAnalyzer.swift');new=R/'candidate/Core/Detection/NativeScorePageAnalyzer.swift'
import difflib
(R/'delta-from-numbered-v2.patch').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='frozen-numbered-v2/NativeScorePageAnalyzer.swift',tofile='narrow-candidate/NativeScorePageAnalyzer.swift')))
(R/'executable-hashes.json').write_text(json.dumps({str(p.relative_to(R)):sha(p)for p in [R/'candidate/controls297-pixels-run/runner',R/'candidate/expanded336-run/runner',R/'evaluate']},indent=2)+'\n')
files={str(p.relative_to(R)):p for p in sorted(R.rglob('*'))if p.is_file()and'module-cache'not in p.parts and p.suffix in ['.json','.swift','.py','.sh','.patch','.log','.md']}
files['reused-baseline/results297.json']=Path('.build/ownership-alternatives-2026-10-03/results297.json');files['reused-baseline/results336.json']=Path('.build/ownership-alternatives-2026-10-03/results336.json')
for n,study in [('original29','musical-span-independent-2026-10-03'),('addendum6','musical-span-attached-addendum-2026-10-03')]:
 p=Path('.build')/study
 for rel in ['baseline/results.json','input-manifest.json']:
  files['reused-small/'+n+'/'+rel]=p/rel
am={n:sha(p)for n,p in sorted(files.items())};(D/'archive-manifest.json').write_text(json.dumps(am,indent=2)+'\n')
with zipfile.ZipFile(D/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,p in files.items():z.write(p,n)
 z.write(D/'archive-manifest.json','archive-manifest.json')
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert set(z.namelist())==set(am)|{'archive-manifest.json'}
 for n,h in am.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
for f in ['README.md','verdict.json','summary297.json','independent-protocol-before-results.json','input-bindings-before-results.json','small-input-bindings-before-results.json','limited-gates-passed.json','baseline297-reproduction.json','delta-from-numbered-v2.patch']:
 shutil.copyfile(R/f,D/f)
for n in ['original29','addendum6']:
 (D/n).mkdir(exist_ok=True)
 for f in ['summary.json','comparison.json']:shutil.copyfile(R/n/f,D/n/f)
m={str(p.relative_to(D)):sha(p)for p in sorted(D.rglob('*'))if p.is_file()and p.name!='manifest.json'};(D/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for n,h in m.items():assert sha(D/n)==h
print(json.dumps({'report':str(D),'README_SHA256':sha(D/'README.md'),'manifest_SHA256':sha(D/'manifest.json'),'artifacts':len(m),'archivePayloads':len(am),'archiveBytes':(D/'evidence.zip').stat().st_size},indent=2))
