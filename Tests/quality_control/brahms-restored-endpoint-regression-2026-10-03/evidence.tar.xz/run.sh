#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
p=.build/envelope-compatibility-corpus-2026-10-03/cause-242312
v=$1
core=$p/$v/Core/Detection
xcrun swiftc -O -module-cache-path .build/ModuleCache "$core/StaffBandDetector.swift" "$core/ScoreExtractionPlanner.swift" "$core/ScoreSharedEnding.swift" "$core/ScoreSharedEndingDetector.swift" "$core/ScoreLocalEndingPreservation.swift" "$core/NativeScorePageAnalyzer.swift" "$p/trace.swift" -o "$p/$v/trace"
"$p/$v/trace" .build/envelope-compatibility-corpus-2026-10-03/baseline/lightly-skewed-10-brahms-string-quartet-no3-op67-imslp-242312.json sample_scores/lightly_skewed/10_brahms_string_quartet_no3_op67_imslp_242312.pdf "$p/$v"
