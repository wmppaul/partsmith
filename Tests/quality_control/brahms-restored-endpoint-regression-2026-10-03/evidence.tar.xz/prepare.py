from pathlib import Path
import json,hashlib,shutil
p=Path('.build/envelope-compatibility-corpus-2026-10-03/cause-242312');core=Path('.build/numbered-line-envelope-compatibility-2026-10-03/candidate/Core');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=['StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift','NativeScorePageAnalyzer.swift']
records={}
for variant in ['baseline','candidate']:
 d=p/variant/'Core/Detection';d.mkdir(parents=True,exist_ok=True)
 for name in names:
  src=core/'Detection'/name
  if variant=='baseline' and name=='NativeScorePageAnalyzer.swift':src=Path('.build/ownership-alternatives-2026-10-03/Core/Detection')/name
  shutil.copy2(src,d/name)
 records[variant]={n:sha(d/n) for n in names}
 f=d/'NativeScorePageAnalyzer.swift';s=f.read_text()
 patches=[('        let original = ink','        let original = ink\n        Probe.save(original,width,height,"original")\n        Probe.saveRaw(Array(raw),width,height,"gray")'),('        var preservedMusicalConnection = false','        Probe.save(ink,width,height,"after-lines-\\(retainMusicalEvidence)")\n        var preservedMusicalConnection = false'),('        struct Run { var left: Int; var right: Int; var y: Int }','        Probe.save(ink,width,height,"after-connectors-\\(retainMusicalEvidence)")\n        struct Run { var left: Int; var right: Int; var y: Int }')]
 for old,new in patches:
  assert s.count(old)==1,(variant,old);s=s.replace(old,new)
 f.write_text(s)
records['observationalOnly']=True
(p/'original-source-bindings.json').write_text(json.dumps(records,indent=2)+'\n')
