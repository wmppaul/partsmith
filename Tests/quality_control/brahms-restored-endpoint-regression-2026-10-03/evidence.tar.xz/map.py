from pathlib import Path
import json,hashlib,collections
from PIL import Image,ImageDraw
import numpy as np
p=Path('.build/envelope-compatibility-corpus-2026-10-03/cause-242312');root=p.parent;ident='lightly-skewed-10-brahms-string-quartet-no3-op67-imslp-242312'
inputs={v['id']:v for v in json.load(open(root/'inputs.json'))};inp=inputs[ident]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(inp['source']))==inp['sourceSHA256']
read=lambda p:np.asarray(Image.open(p))<190
canon=lambda rows:sorted(json.dumps(c,sort_keys=True) for c in rows)
results=[]
def groups(mask):
 seen=np.zeros(mask.shape,dtype=bool);h,w=mask.shape;out=[]
 for y,x in zip(*np.where(mask)):
  if seen[y,x]:continue
  seen[y,x]=True;items=[(int(x),int(y))];i=0
  while i<len(items):
   xx,yy=items[i];i+=1
   for dx,dy in [(-1,-1),(0,-1),(1,-1),(-1,0),(1,0),(-1,1),(0,1),(1,1)]:
    nx,ny=xx+dx,yy+dy
    if 0<=nx<w and 0<=ny<h and mask[ny,nx] and not seen[ny,nx]:seen[ny,nx]=True;items.append((nx,ny))
  out.append(items)
 return out
for n,owners,bbox in [(1,[2,3],[794,702,886,813]),(2,[6,7],[384,834,981,935]),(16,[17,18],[218,2074,292,2174])]:
 old=json.load(open(root/'baseline'/f'{ident}.json'))['pages'][n-1];new=json.load(open(root/'candidate'/f'{ident}.json'))['pages'][n-1]
 for v,pg in [('baseline',old),('candidate',new)]:
  obs=json.load(open(p/v/f'p{n}'/'page.json'));assert canon(pg['inkComponents'])==canon(obs['inkComponents']),(n,v,'instrumented mismatch')
 d=p/'candidate'/f'p{n}';o=p/'baseline'/f'p{n}'
 original=read(d/'original.pgm');assert np.array_equal(original,read(o/'original.pgm'))
 lineOld=read(o/'after-lines-true.pgm');lineNew=read(d/'after-lines-true.pgm')
 finalName='after-connectors-false.pgm' if (d/'after-connectors-false.pgm').exists() else 'after-connectors-true.pgm'
 finalOld=read(o/finalName);finalNew=read(d/finalName)
 x0,y0,x1,y1=bbox;sl=np.s_[y0:y1,x0:x1]
 targets=groups(finalNew[sl]);target=max(targets,key=len)
 assert [min(x for x,y in target),min(y for x,y in target),max(x for x,y in target)+1,max(y for x,y in target)+1]==[0,0,x1-x0,y1-y0]
 targetMask=np.zeros(original.shape,bool)
 for x,y in target:targetMask[y+y0,x+x0]=True
 restored=lineNew & ~lineOld;newFinal=finalNew & ~finalOld
 subset=targetMask & ~restored
 rows=[]
 for cc in groups(subset[sl]):
  xx=[x+x0 for x,y in cc];yy=[y+y0 for x,y in cc];box=[min(xx),min(yy),max(xx)+1,max(yy)+1]
  ids=[s['id'] for s in old['staves'] if box[1]<=s['staffLineFractions'][-1]*old['imageHeight'] and box[3]>=s['staffLineFractions'][0]*old['imageHeight']]
  rows.append({'bbox':box,'area':len(cc),'owners':ids})
 coords=[[int(x),int(y)] for y,x in zip(*np.where(targetMask & restored))]
 out={'page':n,'originalComponentOwners':owners,'componentBounds':bbox,'componentArea':len(target),'ordinaryComponentsExactlyReproduced':True,'newAfterLinePixelsInComponent':len(coords),'allNewFinalComponentPixelsWereRestoredAfterLinePixels':bool(np.all(~(targetMask&newFinal)|restored)),'restoredPixels':coords,'componentAfterRemovingOnlyRestoredLinePixels':sorted(rows,key=lambda c:-c['area']),'sourceSHA256':inp['sourceSHA256'],'graySHA256':sha(d/'gray.pgm')}
 results.append(out)
 margin=25;box=[max(0,x0-margin),max(0,y0-margin),min(original.shape[1],x1+margin),min(original.shape[0],y1+margin)]
 gray=np.asarray(Image.open(d/'gray.pgm'));im=np.stack([gray]*3,axis=2);im[targetMask]=[40,115,220];im[targetMask&restored]=[235,25,130]
 im=Image.fromarray(im).crop(tuple(box));im.resize((im.width*3,im.height*3)).save(p/f'p{n}-component-restored.png')
 Image.open(d/'native-source.png').crop(tuple(box)).resize((im.width*3,im.height*3)).save(p/f'p{n}-source-detail.png')
 print(n,'area',len(target),'restored',len(coords),'groups without restore',[(r['area'],r['owners'],r['bbox']) for r in sorted(rows,key=lambda r:-r['area'])[:8]])
(p/'component-cause.json').write_text(json.dumps(results,indent=2)+'\n')
