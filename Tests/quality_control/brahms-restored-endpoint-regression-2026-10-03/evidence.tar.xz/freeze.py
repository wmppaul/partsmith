from pathlib import Path
import json,hashlib,shutil,tarfile,io
p=Path('.build/envelope-compatibility-corpus-2026-10-03/cause-242312');out=Path('Tests/quality_control/brahms-restored-endpoint-regression-2026-10-03');out.mkdir(parents=True,exist_ok=True);assert not (out/'manifest.json').exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for name in ['README.md','component-cause.json','cause-manifest.json','original-source-bindings.json']:
 shutil.copy2(p/name,out/name)
for f in p.glob('p*-*.png'):shutil.copy2(f,out/f.name)
files=[p/f for f in ['prepare.py','trace.swift','map.py','run.sh','freeze.py']]
for variant in ['baseline','candidate']:
 files += list((p/variant/'Core').rglob('*.swift'))+[p/variant/'run.log']
 for n in [1,2,16]:
  d=p/variant/f'p{n}';files += [d/'page.json']+list(d.glob('*.pgm'))
entries={str(f.relative_to(p)):sha(f) for f in files}
archive=out/'evidence.tar.xz'
with tarfile.open(archive,'w:xz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)))
with tarfile.open(archive) as t:
 for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==entries[m.name]
(out/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n')
inputs=json.load(open(p.parent/'inputs.json'));row=next(r for r in inputs if r['id']=='lightly-skewed-10-brahms-string-quartet-no3-op67-imslp-242312')
bindings={'source':row['source'],'sourceSHA256':row['sourceSHA256'],'profile':row['profile'],'profileSHA256':row['profileSHA256'],'exactCorpusInventories':{},'nativeImageBindings':{}}
for variant in ['baseline','candidate']:
 f=p.parent/variant/(row['id']+'.json');bindings['exactCorpusInventories'][variant]={'path':str(f),'sha256':sha(f)}
 for n in [1,2,16]:
  f=p/variant/f'p{n}'/'native-source.png';bindings['nativeImageBindings'][str(f)] = sha(f)
(out/'input-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
manifest={str(f.relative_to(out)):sha(f) for f in sorted(out.rglob('*')) if f.is_file()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(sha(out/f)==v for f,v in manifest.items())
print('manifest',sha(out/'manifest.json'),'archive',archive.stat().st_size,'members',len(entries))
