# Brahms — String Quartet No. 3, Op. 67

Complete **manually reviewed draft**, made from the existing Partsmith Auto extraction with seven source-reviewed crop corrections. The previous Auto parts are unchanged.

| Part | Pages | Systems |
|---|---:|---:|
| Violin I |18|151|
| Violin II |17|151|
| Viola |17|151|
| Violoncello |15|151|

The set keeps all 604 systems, 42 copied directions, the nine saved source corrections and six saved page breaks. Total length stays 67 pages. Seven complete neighboring staves were removed; the original target notes and markings in those seven rows were checked against the full score by two reviewers.

**Still a draft:** smaller neighboring fragments remain conspicuous in many systems, some markings remain duplicated, and some page turns cross active music. One pre-existing conservative page 35 crop check remains failed and unchanged. This is not a whole-score clean-output or performance certification. No music was erased or reconstructed.

The tighter crops move three Viola systems onto preceding pages, without adding pages. Its existing break before the source page 32 rest opening remains. All other parts keep their prior page allocations.

Open the included `.partsmithproject` folder in Partsmith to adjust the parts. It contains the immutable original score. Musical page titles stay normal; manual-review provenance is recorded in the project name and manifest.

Source: IMSLP 93521, SHA256 `662aabfdecb2d125151c984fe1dc866ea068668ee9bb74f23f286f552603c14a`.

Full evidence: [crop and output review](../../../../Tests/quality_control/brahms-reviewed-cleanup-2026-10-03/README.md).
