from pathlib import Path
from collections import Counter
import json
p=Path('.build/source-musical-spans-2026-10-03');d=p/'candidate-v4';j=lambda f:json.load(open(f));canon=lambda a:Counter(json.dumps(z,sort_keys=True) for z in a)
b=j('.build/brahms-numbered-lines-2026-10-03/baseline/fourcore.json');v1=j(p/'candidate-v1-final/fourcore.json');v2=j(d/'fourcore.json')
r={'cases':len(v2),'changesFromBaseline':[],'changesFromV1':[],'baselineIncomplete':0,'candidateIncomplete':0,'ordinaryExact':True,'oldComponentsRetained':True,'allCropsNoncontracting':True}
for old,prior,new in zip(b,v1,v2):
 assert (old['id'],old['scale'])==(new['id'],new['scale'])
 r['ordinaryExact'] &= canon([x for x in old['components'] if not x.get('isOwnershipAlternative')])==canon([x for x in new['components'] if not x.get('isOwnershipAlternative')])
 r['oldComponentsRetained'] &= not bool(canon(old['components'])-canon(new['components']))
 for a,c,z in zip(old['targets'],prior['targets'],new['targets']):
  r['baselineIncomplete']+=a['lostPixels']>0;r['candidateIncomplete']+=z['lostPixels']>0
  r['allCropsNoncontracting'] &= z['crop'][0]<=a['crop'][0] and z['crop'][1]>=a['crop'][1]
  info={'id':new['id'],'scale':new['scale'],'owner':a['owner'],'baselineLost':a['lostPixels'],'v1Lost':c['lostPixels'],'v4Lost':z['lostPixels']}
  if a['lostPixels']!=z['lostPixels']:r['changesFromBaseline'].append(info)
  if c['lostPixels']!=z['lostPixels']:r['changesFromV1'].append(info)
(d/'fourcore-comparison.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
base=j('.build/ownership-alternatives-2026-10-03/actual.json');new=j(d/'real-six.json');out=[]
for page in new['pages']:
 pn=page['pageIndex'];old=next(x for x in base['pages'] if x['pageIndex']==pn);oo=dict(old);nn=dict(page)
 oo.pop('inkComponents',None);nn.pop('inkComponents',None)
 added=canon(page.get('inkComponents',[]))-canon(old.get('inkComponents',[]));removed=canon(old.get('inkComponents',[]))-canon(page.get('inkComponents',[]))
 oldplan=next(x for x in base['plan']['pages'] if x['pageIndex']==pn);newplan=next(x for x in new['plan']['pages'] if x['pageIndex']==pn)
 changes=[]
 for a,b in zip(oldplan['assignments'],newplan['assignments']):
  assert a['id']==b['id']
  if a!=b:changes.append({'id':a['id'],'before':a,'after':b})
 out.append({'page':pn+1,'nonComponentAnalysisExact':oo==nn,'removedComponents':list(removed.elements()),'addedComponents':[json.loads(x) for x in added.elements()],'planExact':oldplan==newplan,'changedAssignments':changes})
(d/'real-six-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
print('real5',[(x['page'],len(x['addedComponents']),len(x['changedAssignments'])) for x in out])
