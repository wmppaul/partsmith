"""Compare a source-span-only candidate; no output is accepted from pass totals alone."""
import collections, hashlib, json, sys
from pathlib import Path
baseline, candidate, destination = map(Path, sys.argv[1:])
a, b = (json.loads(p.read_text()) for p in (baseline, candidate))
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'))
def key(c):return canonical(c)
def counted(p,alternative):return collections.Counter(key(c) for c in p['inkComponents'] or [] if (c.get('isOwnershipAlternative') is True)==alternative)
ap={p['pageIndex']:p for p in a['pages']};bp={p['pageIndex']:p for p in b['pages']}
assert ap.keys()==bp.keys(), 'Page scope changed'
errors=[];new_spans=[]
for index,p in ap.items():
 q=bp[index]
 pa={k:v for k,v in p.items() if k!='inkComponents'};pb={k:v for k,v in q.items() if k!='inkComponents'}
 if pa!=pb:errors.append({'page':index+1,'problem':'Non-component page field changed'})
 if counted(p,False)!=counted(q,False):errors.append({'page':index+1,'problem':'Ordinary components changed'})
 old=counted(p,True);new=counted(q,True)
 if old-new:errors.append({'page':index+1,'problem':'Existing preservation alternatives removed','missing':list((old-new).elements())})
 for span,n in (new-old).items():new_spans.append({'page':index+1,'span':json.loads(span),'occurrences':n})
assert a['plan']['parts']==b['plan']['parts'], 'Instrument profile changed'
def assignments(plan):return [band for page in plan['pages'] for band in page['assignments']]
for old,new in zip(a['plan']['pages'],b['plan']['pages']):
 if {k:v for k,v in old.items() if k not in {'assignments','warnings'}}!={k:v for k,v in new.items() if k not in {'assignments','warnings'}}:errors.append({'page':old['pageIndex']+1,'problem':'Plan coverage, omission or assignment state changed'})
ab={v['id']:v for v in assignments(a['plan'])};bb={v['id']:v for v in assignments(b['plan'])}
assert ab.keys()==bb.keys(), 'Part/system coverage changed'
changes=[]
def neighbors(band,p):
 return [s['id'] for s in p['staves'] if s['id'] not in band['candidateIDs'] and band['topFraction']<=s['staffLineFractions'][0] and band['bottomFraction']>=s['staffLineFractions'][4]]
for identity,p in ab.items():
 q=bb[identity];allowed={'topFraction','bottomFraction','warnings'}
 if {k:v for k,v in p.items() if k not in allowed}!={k:v for k,v in q.items() if k not in allowed}:errors.append({'band':identity,'problem':'Identity, horizontal crop, assignment or other band metadata changed'})
 if q['topFraction']>p['topFraction'] or q['bottomFraction']<p['bottomFraction']:errors.append({'band':identity,'problem':'Candidate excludes part of the old crop','before':[p['topFraction'],p['bottomFraction']],'after':[q['topFraction'],q['bottomFraction']]})
 if p!=q:changes.append({'band':identity,'page':p['pageIndex']+1,'oldY':[p['topFraction']*ap[p['pageIndex']]['pageHeight'],p['bottomFraction']*ap[p['pageIndex']]['pageHeight']],'newY':[q['topFraction']*bp[q['pageIndex']]['pageHeight'],q['bottomFraction']*bp[q['pageIndex']]['pageHeight']],'oldWholeNeighbors':neighbors(p,ap[p['pageIndex']]),'newWholeNeighbors':neighbors(q,bp[q['pageIndex']])})
result={'inputSHA256':{'baseline':hashlib.sha256(baseline.read_bytes()).hexdigest(),'candidate':hashlib.sha256(candidate.read_bytes()).hexdigest()},'pages':len(ap),'bands':len(ab),'errors':errors,'newSourceSpans':new_spans,'changedBands':changes,'scope':'Preservation-layer monotonicity and geometry only. New source spans and every changed real crop still require independent source review. Does not establish source-owned musical completeness.'}
destination.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'pages':len(ap),'bands':len(ab),'ordinaryOrPreservationErrors':len(errors),'newSpans':len(new_spans),'changedBands':len(changes)},indent=2))
if errors:sys.exit(1)
