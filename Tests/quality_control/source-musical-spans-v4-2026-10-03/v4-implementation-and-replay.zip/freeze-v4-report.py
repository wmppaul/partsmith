from pathlib import Path
import json,hashlib,zipfile,shutil
p=Path('.build/source-musical-spans-2026-10-03');r=Path('Tests/quality_control/source-musical-spans-v4-2026-10-03');r.mkdir(exist_ok=True);full=Path('.build/brahms-source-span-full-v4-2026-10-03');original=Path('.build/brahms-source-span-full-replay-2026-10-03')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
copy={'protocol-before-results.json':p/'v4-protocol-before-results.json','fourcore-comparison.json':p/'candidate-v4/fourcore-comparison.json','real-six-comparison.json':p/'candidate-v4/real-six-comparison.json','full39-protocol-before-results.json':full/'protocol-before-results.json','full39-comparison.json':full/'comparison.json','full39-run.log':full/'run.log','full39-inputs.json':original/'inputs.json','body-area-checks.json':Path('Tests/quality_control/musical-span-independent-2026-10-03/candidate-v4/body-area-checks.json'),'body-membership-checks.json':Path('Tests/quality_control/musical-span-independent-2026-10-03/candidate-v4/body-membership-checks.json')}
for name,f in copy.items():shutil.copy2(f,r/name)
inputs=[p/'candidate-v4/Core/Detection/NativeScorePageAnalyzer.swift',Path('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'),Path('Tests/quality_control/source-musical-spans-v3-2026-10-03/manifest.json'),Path('Tests/quality_control/musical-span-independent-2026-10-03/candidate-v4/manifest.json'),Path('Tests/quality_control/musical-span-attached-addendum-2026-10-03/candidate-v4/manifest.json'),full/'candidate.json',full/'protocol-before-results.json',full/'run.log',full/'replay',original/'inputs.json',Path('.build/ownership-alternatives-2026-10-03/actual.json')]
(r/'bindings.json').write_text(json.dumps({str(f):sha(f) for f in inputs},indent=2,sort_keys=True)+'\n')
files={}
for name in ['v4-protocol-before-results.json','make-v4.py','compare-v4.py','freeze-v4-report.py','case176.swift','fourcore.swift','real-six.swift','build-run.sh']:files[name]=p/name
for name in ['StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift','NativeScorePageAnalyzer.swift']:files['candidate-v4/Core/Detection/'+name]=p/'candidate-v4/Core/Detection'/name
for f in (p/'candidate-v4').glob('*'):
 if f.is_file() and f.suffix in ['.json','.log','.diff','.pgm']:files['candidate-v4/'+f.name]=f
for name in ['candidate.json','protocol-before-results.json','replay.swift','run.log','build.log','comparison.json']:files['root-full39/'+name]=full/name
for name in ['inputs.json','scope.json','compare.py']:files['root-full39/'+name]=original/name
archive=r/'v4-implementation-and-replay.zip';members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,f in sorted(files.items()):z.write(f,n);members[n]={'sha256':sha(f),'bytes':f.stat().st_size}
(r/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),'members':members,'omitted':'Rebuildable binaries and duplicated full source rasters. All original raster/input hashes and rootfull39 result retained.'},indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(archive) as z:
 for n,v in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
print(len(members),archive.stat().st_size)
