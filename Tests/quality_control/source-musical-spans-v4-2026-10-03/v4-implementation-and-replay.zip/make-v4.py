from pathlib import Path
import shutil,json,hashlib,difflib
p=Path('.build/source-musical-spans-2026-10-03');d=p/'candidate-v4/Core';shutil.copytree(p/'candidate-v3/Core',d)
f=d/'Detection/NativeScorePageAnalyzer.swift';old=f.read_text();s=old.replace('        var shaftBodyPixels: [[Int]]\n','        var shaftBodyPixels: [[Int]]\n        var inkArea: Double\n        var hullArea: Double\n        var solidity: Double\n',1)
helper='''    private struct SourceCellCorner: Hashable { var x: Int; var y: Int }
    private static func sourceCellHullArea(_ pixels: Set<Int>, stride: Int,
                                          isCancelled: () -> Bool) -> Double? {
        var corners = Set<SourceCellCorner>()
        for index in pixels {
            if isCancelled() { return nil }
            let x = index % stride, y = index / stride
            corners.insert(SourceCellCorner(x: x, y: y))
            corners.insert(SourceCellCorner(x: x + 1, y: y))
            corners.insert(SourceCellCorner(x: x, y: y + 1))
            corners.insert(SourceCellCorner(x: x + 1, y: y + 1))
        }
        let points = corners.sorted { $0.x != $1.x ? $0.x < $1.x : $0.y < $1.y }
        guard points.count >= 3 else { return 0 }
        func cross(_ a: SourceCellCorner, _ b: SourceCellCorner, _ c: SourceCellCorner) -> Int {
            (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
        }
        var lower: [SourceCellCorner] = [], upper: [SourceCellCorner] = []
        for point in points {
            if isCancelled() { return nil }
            while lower.count >= 2 && cross(lower[lower.count - 2], lower[lower.count - 1], point) <= 0 { lower.removeLast() }
            lower.append(point)
        }
        for point in points.reversed() {
            if isCancelled() { return nil }
            while upper.count >= 2 && cross(upper[upper.count - 2], upper[upper.count - 1], point) <= 0 { upper.removeLast() }
            upper.append(point)
        }
        let hull = Array(lower.dropLast()) + Array(upper.dropLast())
        guard hull.count >= 3 else { return 0 }
        var doubledArea = 0
        for i in hull.indices {
            let a = hull[i], b = hull[(i + 1) % hull.count]
            doubledArea += a.x * b.y - a.y * b.x
        }
        return Double(abs(doubledArea)) / 2
    }

'''
needle='    static func sourceMusicalSpans(';assert s.count(needle)==1;s=s.replace(needle,helper+needle,1)
needle='                guard let disk else { continue }\n';insert='''                guard let hullArea = sourceCellHullArea(thicknessPixels, stride: localWidth, isCancelled: isCancelled) else { return [] }
                guard hullArea > 0 else { continue }
                let inkArea = Double(thicknessPixels.count)
                let solidity = inkArea / hullArea
                guard solidity >= 0.82 else { continue }
''';assert s.count(needle)==1;s=s.replace(needle,needle+insert,1)
needle='filledDisk: disk, shaftBodyPixels: shaftBodyPixels, explainedThinRuns:';assert s.count(needle)==1;s=s.replace(needle,'filledDisk: disk, shaftBodyPixels: shaftBodyPixels, inkArea: inkArea, hullArea: hullArea, solidity: solidity, explainedThinRuns:',1);f.write_text(s)
h={str(x.relative_to(d)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(d.rglob('*.swift'))};(d.parent/'source-hashes.json').write_text(json.dumps(h,indent=2,sort_keys=True)+'\n');(d.parent/'versus-v3.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='v3/NativeScorePageAnalyzer.swift',tofile='v4/NativeScorePageAnalyzer.swift')))
print('Native',h['Detection/NativeScorePageAnalyzer.swift']);print('Protocol',hashlib.sha256((p/'v4-protocol-before-results.json').read_bytes()).hexdigest())
# Same source replay; the only extra page is the independently diagnosed p10.
s=(p/'real-five.swift').read_text().replace('for pn in [23,28,29,38,39] {','for pn in [10,23,28,29,38,39] {');(p/'real-six.swift').write_text(s)
