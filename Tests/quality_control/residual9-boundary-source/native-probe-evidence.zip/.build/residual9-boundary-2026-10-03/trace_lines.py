from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
import json, math

root=Path('.build/residual9-boundary-2026-10-03')
old=Path('.build/residual9-endpoint-ownership-2026-10-03')
baseline=json.loads((old/'baseline-actual.json').read_text())

def trace(a, expected, space, slope):
    h,w=a.shape
    step=max(2,round(space*.6))
    half=max(4,round(space*1.4))
    centers=np.arange(w//2,w-half,step)
    radius=round(space*2)
    offsets=np.arange(-radius,radius+1)
    prefix=np.pad(np.cumsum(a.astype(np.int32),axis=1),((0,0),(1,0)))
    # A row is supported by original horizontal ink, with one pixel of raster
    # uncertainty. Independently trace each physical line from its center anchor.
    weights=[]
    for x in centers:
        ys=np.rint(expected+slope*(x-w/2)+offsets).astype(int)
        options=[]
        for dy in [-1,0,1]:
            yy=np.clip(ys+dy,0,h-1)
            options.append((prefix[yy,x+half]-prefix[yy,x-half])/(2*half))
        weights.append(np.max(options,axis=0))
    weights=np.array(weights)
    maxstep=max(1,round(space*.13))
    cost=np.where(abs(offsets)<=max(1,round(space*.2)),abs(offsets)*.03,1e6)
    backs=[]
    for scores in weights:
        options=np.full((2*maxstep+1,len(offsets)),1e6)
        indices=np.arange(len(offsets))
        for i,delta in enumerate(range(-maxstep,maxstep+1)):
            prev=indices+delta
            valid=(prev>=0)&(prev<len(offsets))
            options[i,valid]=cost[prev[valid]]+.06*abs(delta)
        choice=options.argmin(axis=0)
        backs.append(indices+choice-maxstep)
        cost=options[choice,indices]+1-scores
    j=int(cost.argmin());path=[]
    for k in range(len(centers)-1,-1,-1):
        path.append(j);j=int(backs[k][j])
    path=np.array(path[::-1]);chosen=offsets[path]
    support=weights[np.arange(len(centers)),path]
    # Diagnostic only. The end is measured from native pixels after tracing;
    # final confidence/structural ownership remains separately unproven.
    good=np.where(support>=.65)[0]
    if len(good)==0:return None
    last=int(good[-1]);x=int(centers[last]);y=expected+slope*(x-w/2)+chosen[last]
    return {'x':centers.tolist(),'y':(expected+slope*(centers-w/2)+chosen).tolist(),
            'support':support.tolist(),'lastStrongWindow':x,'lastRow':float(y),
            'meanSupport':float(support[:last+1].mean()),
            'longestGapWindows':max([len(g) for g in ''.join('1' if s>=.5 else '0' for s in support[:last+1]).split('1')],default=0)}

records=[]
for pn in [24,28,29,31,35]:
    p=baseline['pages'][pn-1]
    image=Image.open(old/'rasters'/f'page-{pn}.png').convert('RGB')
    a=np.array(image.convert('L'))<190;h,w=a.shape
    slope=math.tan(math.radians(p['analysisSkewDegrees']))
    draw=ImageDraw.Draw(image)
    staves=[]
    for staff in p['staves']:
        lines=np.array(staff['staffLineFractions'])*h
        space=(lines[-1]-lines[0])/4
        traces=[trace(a,y,space,slope) for y in lines]
        for tr in traces:
            if tr:
                draw.line(list(zip(tr['x'],tr['y'])),fill=(255,50,50),width=1)
                draw.ellipse((tr['lastStrongWindow']-3,tr['lastRow']-3,tr['lastStrongWindow']+3,tr['lastRow']+3),outline=(0,0,255),width=2)
        staves.append({'id':staff['id'],'space':float(space),'traces':traces})
    records.append({'page':pn,'width':w,'height':h,'staves':staves})
    image.save(root/f'traced-page-{pn}.png')
    print(pn,[(s['id'],[t['lastStrongWindow'] if t else None for t in s['traces']]) for s in staves])
(root/'traced-lines.json').write_text(json.dumps(records,indent=2)+'\n')
