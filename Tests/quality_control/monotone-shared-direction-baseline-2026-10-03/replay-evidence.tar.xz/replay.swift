import AppKit
import CryptoKit
import Foundation
import PDFKit

struct Inventory: Codable {
    var source: String
    var sourceSHA256: String
    var pages: [ScorePageAnalysis]
    var rectifications: [PageRectification]?
}
struct Observation: Codable { var anchor: Int; var text: String; var confidence: Float; var bounds: [Double] }
struct OCRLog: Codable { var observations: [Observation]; var failures: [String]; var headings: [ScoreSharedHeading] }
struct Issue: Codable { var pageIndex: Int; var message: String }
struct Output: Codable {
    var id: String
    var physicalPage: Int
    var sourceSHA256: String
    var inventorySHA256: String
    var profileSHA256: String
    var originalAnalysis: ScorePageAnalysis
    var analyses: [ScorePageAnalysis]
    var plan: ScoreExtractionPlan
    var issues: [Issue]
    var referenceCount: Int
    var elapsedSeconds: Double
}
@main struct Replay {
    static func hash(_ data: Data) -> String { SHA256.hash(data:data).map { String(format:"%02x",$0) }.joined() }
    static func main() throws {
        let work=URL(fileURLWithPath:CommandLine.arguments[1])
        let jobs=[("lightly-skewed-10-brahms-string-quartet-no3-op67-imslp-242312",18), ("medium-skewed-05-brahms-string-quartet-no3-op67-imslp-09200",22)]
        for (id,page) in jobs {
            try autoreleasepool {
                let inventoryURL=work.appendingPathComponent("inputs/\(id).json")
                let profileURL=URL(fileURLWithPath:"Tests/quality_control/profiles/\(id).json")
                let data=try Data(contentsOf:inventoryURL), profileData=try Data(contentsOf:profileURL)
                let inventory=try JSONDecoder().decode(Inventory.self,from:data)
                let profile=try JSONDecoder().decode(ScoreExtractionProfile.self,from:profileData)
                let source=try Data(contentsOf:URL(fileURLWithPath:inventory.source))
                precondition(hash(source)==inventory.sourceSHA256)
                let pdf=PDFDocument(data:source)!
                let analysis=inventory.pages.first { $0.pageIndex==page-1 }!
                let start=Date()
                let result=ScoreSharedDirectionWorkflow.run(pdf:pdf,analyses:[analysis],profile:profile,
                    rectifications:inventory.rectifications ?? [],progress:{ p in
                        print("\(id) p\(page) \(p.phase.rawValue) \(p.completedPages)/\(p.totalPages)");fflush(stdout)
                    },isCancelled:{false})
                let plan=ScoreExtractionPlanner.plan(pages:result.analyses,profile:profile)
                let output=Output(id:id,physicalPage:page,sourceSHA256:hash(source),inventorySHA256:hash(data),
                    profileSHA256:hash(profileData),originalAnalysis:analysis,analyses:result.analyses,plan:plan,
                    issues:result.issues.map { Issue(pageIndex:$0.pageIndex,message:$0.message) },
                    referenceCount:result.references.count,elapsedSeconds:Date().timeIntervalSince(start))
                let encoder=JSONEncoder();encoder.outputFormatting=[.prettyPrinted,.sortedKeys,.withoutEscapingSlashes]
                try encoder.encode(output).write(to:work.appendingPathComponent(id+"-result.json"),options:.atomic)
                print("RESULT \(id): headings \(result.analyses.first?.sharedHeadings?.map(\.recognizedText) ?? []); issues \(result.issues.map(\.message))")
                fflush(stdout)
                let image=NativeScorePageAnalyzer.render(pdf.page(at:page-1)!,maximumWidth:2200,maximumHeight:3200)!
                var observed:[Observation]=[],failures:[String]=[]
                let observedHeadings=ScoreSharedHeadingDetector.detect(in:image,page:analysis,profile:profile,observedText:{ anchor,lines in
                    observed += lines.map { Observation(anchor:anchor,text:$0.text,confidence:$0.confidence,bounds:[$0.bounds.minX,$0.bounds.minY,$0.bounds.maxX,$0.bounds.maxY]) }
                },observedFailure:{ anchor,error in failures.append("staff \(anchor): \(error)") })
                try encoder.encode(OCRLog(observations:observed,failures:failures,headings:observedHeadings)).write(to:work.appendingPathComponent(id+"-ocr.json"),options:.atomic)
            }
        }
    }
}
