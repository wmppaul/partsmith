Durable baseline replay evidence.

These are actual workflow result/OCR files, not recreated outputs. Packaging performed no rerun.

Reconstruct Core using the baseline frozen-core.tar.xz; for candidate or production replace only Detection/ScoreSharedHeadingDetector.swift with the candidate receipt file. Compile the archived replay.swift and, when present, export_score_plan.swift together with all Core Swift sources. Core hashes are listed in core-hashes.json. The production receipt reused the candidate binary.

The harness accepts a work-directory argument containing inputs/<score-id>.json. The archived inputs retain exactly the one page consumed by each recorded run. Full original input hashes and the exact derivation are in replay-provenance.json. Original score PDFs must be present at the bound repository paths. Profiles belong at Tests/quality_control/profiles/<score-id>.json relative to the repository, as expected by the unchanged harness.

outputs/ contains the immutable observed results and OCR. logs/ contains actual build/run logs. Native macOS Vision access was required. This archive is source-copy evidence only, not new source-review coverage or a polished output claim.
