from pathlib import Path
import shutil,json,hashlib
p=Path('.build/numbered-line-monotone-compatibility-2026-10-03');cause=Path('.build/envelope-compatibility-corpus-2026-10-03/cause-242312');d=p/'source-observer/Core';assert not d.exists();shutil.copytree(p/'candidate/Core',d)
f=d/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text()
patches=[('        let original = ink','        let original = ink\n        Probe.save(original,width,height,"original")\n        Probe.saveRaw(Array(raw),width,height,"gray")'),('        var preservedMusicalConnection = false','        Probe.subset(ink,musicalFeatureInk,width,height,"after-lines-\\(retainMusicalEvidence)")\n        var preservedMusicalConnection = false'),('        struct Run { var left: Int; var right: Int; var y: Int }','        Probe.subset(ink,musicalFeatureInk,width,height,"after-connectors-\\(retainMusicalEvidence)")\n        struct Run { var left: Int; var right: Int; var y: Int }')]
for old,new in patches:assert s.count(old)==1;s=s.replace(old,new)
f.write_text(s)
h=(cause/'trace.swift').read_text().replace('  let directory=URL(fileURLWithPath:CommandLine.arguments[3])','  let directory=URL(fileURLWithPath:CommandLine.arguments[3])\n  let profile=try JSONDecoder().decode(ScoreExtractionProfile.self,from:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[4])))').replace('   try encoder.encode(page).write(to:Probe.directory.appendingPathComponent("page.json"))','   try encoder.encode(page).write(to:Probe.directory.appendingPathComponent("page.json"))\n   try encoder.encode(ScoreExtractionPlanner.plan(pages:[page],profile:profile)).write(to:Probe.directory.appendingPathComponent("plan.json"))')
h=h.replace(' static func save(_ ink:', ''' static func subset(_ ink:[Bool],_ legacy:[Bool],_ w:Int,_ h:Int,_ name:String){
  let added=zip(ink,legacy).filter{$0.0 && !$0.1}.count
  precondition(added==0,"Measured mask restored legacy-removed pixels")
  save(ink,w,h,name);save(legacy,w,h,name+"-legacy")
  let obj:[String:Any]=["structuralInkPixels":ink.filter{$0}.count,"legacyInkPixels":legacy.filter{$0}.count,"restoredPixels":added]
  try!JSONSerialization.data(withJSONObject:obj,options:[.prettyPrinted,.sortedKeys]).write(to:directory.appendingPathComponent(name+"-subset.json"))
 }
 static func save(_ ink:''')
(p/'source-observer/trace.swift').write_text(h)
sh=(cause/'run.sh').read_text().replace('p=.build/envelope-compatibility-corpus-2026-10-03/cause-242312','p=.build/numbered-line-monotone-compatibility-2026-10-03').replace('v=$1','v=source-observer').replace('"$p/trace.swift"','"$p/$v/trace.swift"')
profile=next(i['profile'] for i in json.load(open(cause.parent/'inputs.json')) if i['id']=='lightly-skewed-10-brahms-string-quartet-no3-op67-imslp-242312')
sh=sh.rstrip()+' "'+profile+'"\n';(p/'run-source-observer.sh').write_text(sh)
