import Foundation
import CoreGraphics
import PDFKit
import ImageIO
@main enum Trace {
 struct Inventory:Decodable {var pages:[ScorePageAnalysis]}
 static func main()throws{
  let inventory=try JSONDecoder().decode(Inventory.self,from:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[1])))
  let pdf=PDFDocument(url:URL(fileURLWithPath:CommandLine.arguments[2]))!
  let directory=URL(fileURLWithPath:CommandLine.arguments[3])
  let profile=try JSONDecoder().decode(ScoreExtractionProfile.self,from:Data(contentsOf:URL(fileURLWithPath:CommandLine.arguments[4])))
  let encoder=JSONEncoder();encoder.outputFormatting=[.sortedKeys,.prettyPrinted]
  for number in [1,2,16] {
   var page=inventory.pages[number-1]
   Probe.directory=directory.appendingPathComponent("p\(number)")
   try FileManager.default.createDirectory(at:Probe.directory,withIntermediateDirectories:true)
   let image=NativeScorePageAnalyzer.render(pdf.page(at:number-1)!)!
   precondition(image.width==page.imageWidth && image.height==page.imageHeight)
   let destination=CGImageDestinationCreateWithURL(Probe.directory.appendingPathComponent("native-source.png") as CFURL,"public.png" as CFString,1,nil)!
   CGImageDestinationAddImage(destination,image,nil);CGImageDestinationFinalize(destination)
   let candidates=page.staves.map {StaffBandCandidate(id:$0.id,staffLineFractions:$0.staffLineFractions,topFraction:$0.topFraction,bottomFraction:$0.bottomFraction,confidence:$0.confidence,warnings:$0.warnings)}
   page.inkComponents=NativeScorePageAnalyzer.notationComponents(image:image,candidates:candidates,skewDegrees:page.analysisSkewDegrees)!
   try encoder.encode(page).write(to:Probe.directory.appendingPathComponent("page.json"))
   try encoder.encode(ScoreExtractionPlanner.plan(pages:[page],profile:profile)).write(to:Probe.directory.appendingPathComponent("plan.json"))
   print("p\(number): \(page.inkComponents!.count) components")
  }
 }
}
enum Probe {
 static var directory=URL(fileURLWithPath:".")
 static func subset(_ ink:[Bool],_ legacy:[Bool],_ w:Int,_ h:Int,_ name:String){
  let added=zip(ink,legacy).filter{$0.0 && !$0.1}.count
  precondition(added==0,"Measured mask restored legacy-removed pixels")
  save(ink,w,h,name);save(legacy,w,h,name+"-legacy")
  let obj:[String:Any]=["structuralInkPixels":ink.filter{$0}.count,"legacyInkPixels":legacy.filter{$0}.count,"restoredPixels":added]
  try!JSONSerialization.data(withJSONObject:obj,options:[.prettyPrinted,.sortedKeys]).write(to:directory.appendingPathComponent(name+"-subset.json"))
 }
 static func save(_ ink:[Bool],_ w:Int,_ h:Int,_ name:String){saveRaw(ink.map{$0 ? 0:255},w,h,name)}
 static func saveRaw(_ values:[UInt8],_ w:Int,_ h:Int,_ name:String){var d=Data("P5\n\(w) \(h)\n255\n".utf8);d.append(contentsOf:values);try!d.write(to:directory.appendingPathComponent(name+".pgm"))}
}
