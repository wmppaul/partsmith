from pathlib import Path
import json,hashlib,collections
import numpy as np
from PIL import Image
R=Path('.build/numbered-monotone-independent-2026-10-03');A=Path('.build/numbered-line-monotone-compatibility-2026-10-03');W=Path('.build/envelope-compatibility-corpus-2026-10-03');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Every original input payload is still byte-identical to its frozen manifest.
small=read(R/'small-input-bindings-before-results.json');assert sha(R/'evaluate.swift')==small['evaluatorSHA256'];inputRows=[]
for name in ['musical-span-independent-2026-10-03','musical-span-attached-addendum-2026-10-03']:
 p=Path('.build')/name;m=read(p/'input-manifest.json');assert sha(p/'input-manifest.json')==small[name]['inputManifestSHA256'] and sha(p/'baseline/results.json')==small[name]['baselineResultsSHA256']
 for rel,h in m.items():assert sha(p/rel)==h,(name,rel)
 inputRows.append({'study':name,'inputFilesVerified':len(m),'manifestSHA256':sha(p/'input-manifest.json')})
# Separate per-owner neighbor relations ensure aggregate equality cannot hide a swap.
old=read(R/'baseline/controls297-pixels-run/results.json');new=read(R/'candidate/controls297-pixels-run/results.json');relations=[]
for i,(a,b)in enumerate(zip(old,new)):
 for at,bt in zip(a['targets'],b['targets']):
  owner=at['owner'];assert owner==bt['owner'];cores=[(j,180+150*j,228+150*j)for j in range(3)if j!=owner]
  get=lambda t:[j for j,y,z in cores if t['crop'][1]<=y and t['crop'][3]>=z]
  x,y=get(at),get(bt);relations.append({'caseIndex':i,'kind':a['kind'],'owner':owner,'beforeForeignIDs':x,'afterForeignIDs':y,'newForeignIDs':sorted(set(y)-set(x)),'removedForeignIDs':sorted(set(x)-set(y))})
assert sum(len(x['beforeForeignIDs'])for x in relations)==sum(x['wholeNeighborCount']for x in old)
assert sum(len(x['afterForeignIDs'])for x in relations)==sum(x['wholeNeighborCount']for x in new)
assert not any(x['newForeignIDs']for x in relations)
(R/'per-owner-neighbor-relations297.json').write_text(json.dumps(relations,indent=2)+'\n')
# Reconstruct observer modifications exactly; all other frozen Core files are equal.
frozen=A/'candidate/Core/Detection/NativeScorePageAnalyzer.swift';s=frozen.read_text();replacements=[('        let original = ink','        let original = ink\n        Probe.save(original,width,height,"original")\n        Probe.saveRaw(Array(raw),width,height,"gray")'),('        var preservedMusicalConnection = false','        Probe.subset(ink,musicalFeatureInk,width,height,"after-lines-\\(retainMusicalEvidence)")\n        var preservedMusicalConnection = false'),('        struct Run { var left: Int; var right: Int; var y: Int }','        Probe.subset(ink,musicalFeatureInk,width,height,"after-connectors-\\(retainMusicalEvidence)")\n        struct Run { var left: Int; var right: Int; var y: Int }')]
for a,b in replacements:assert s.count(a)==1;s=s.replace(a,b)
assert s==(A/'source-observer/Core/Detection/NativeScorePageAnalyzer.swift').read_text()
for p in (A/'candidate/Core').rglob('*.swift'):
 if p.name!='NativeScorePageAnalyzer.swift':assert sha(p)==sha(A/'source-observer/Core'/p.relative_to(A/'candidate/Core'))
sid='lightly-skewed-10-brahms-string-quartet-no3-op67-imslp-242312';inp=next(x for x in read(W/'inputs.json')if x['id']==sid);base=read(W/'baseline'/f'{sid}.json');binding=read('.build/envelope-corpus-independent-2026-10-03/baseline-binding.json');bind=next(x for x in binding['rows']if x['id']==sid)
assert sha(W/'baseline'/f'{sid}.json')==bind['replannedBaselineSHA256'] and sha(inp['source'])==inp['sourceSHA256'] and sha(inp['profile'])==inp['profileSHA256'];rows=[]
for n,target in [(1,'p1-s1-cello'),(2,'p2-s2-cello'),(16,'p16-s5-viola')]:
 folder=A/'source-observer'/f'p{n}';pg=read(folder/'page.json');plan=read(folder/'plan.json');pp=plan['pages'][0];oldpg=base['pages'][n-1];oldpp=base['plan']['pages'][n-1]
 assert {k:v for k,v in pg.items()if k!='inkComponents'}=={k:v for k,v in oldpg.items()if k!='inkComponents'}
 assert {k:v for k,v in pp.items()if k!='assignments'}=={k:v for k,v in oldpp.items()if k!='assignments'}
 assert [b['id']for b in pp['assignments']]==[b['id']for b in oldpp['assignments']]
 changed=[];newForeign=[];bandRects=[]
 for x,y in zip(oldpp['assignments'],pp['assignments']):
  skip=['leftFraction','rightFraction','topFraction','bottomFraction','warnings'];assert {k:v for k,v in x.items()if k not in skip}=={k:v for k,v in y.items()if k not in skip}
  rect=lambda b:[b['leftFraction']*pg['pageWidth'],b['topFraction']*pg['pageHeight'],(1-b['rightFraction'])*pg['pageWidth'],b['bottomFraction']*pg['pageHeight']]
  foreign=lambda b:[s['id']for s in pg['staves']if s['id']not in b['candidateIDs'] and b['topFraction']<=min(s['staffLineFractions']) and b['bottomFraction']>=max(s['staffLineFractions'])]
  rec={'bandID':x['id'],'before':rect(x),'after':rect(y),'beforeForeign':foreign(x),'afterForeign':foreign(y),'newForeign':sorted(set(foreign(y))-set(foreign(x)))};bandRects.append(rec)
  if rec['before']!=rec['after']:changed.append(rec)
  if rec['newForeign']:newForeign.append(rec)
 targetRow=next(r for r in bandRects if r['bandID']==target);assert targetRow['before']==targetRow['after'] and not newForeign
 masks=[]
 for stage in ['after-lines-true','after-connectors-true']:
  p=folder/(stage+'.pgm');q=folder/(stage+'-legacy.pgm');newMask=np.asarray(Image.open(p))==0;oldMask=np.asarray(Image.open(q))==0;assert newMask.shape==oldMask.shape==(pg['imageHeight'],pg['imageWidth'])
  calc={'structuralInkPixels':int(newMask.sum()),'legacyInkPixels':int(oldMask.sum()),'restoredPixels':int((newMask & ~oldMask).sum())};assert calc==read(folder/(stage+'-subset.json')) and calc['restoredPixels']==0
  masks.append({'stage':stage,**calc,'newMaskSHA256':sha(p),'legacyMaskSHA256':sha(q)})
 rows.append({'page':n,'bandsCompared':len(bandRects),'target':targetRow,'changedCrops':changed,'newForeignRelations':newForeign,'subsetChecksIndependentlyRecomputed':masks,'nativePageSHA256':sha(folder/'page.json'),'planSHA256':sha(folder/'plan.json')})
report={'scope':'Read-only independent comparison of author native component replay using frozen staff candidates, no duplicate native analysis. Original PDF and profile bindings exact. This is geometry/mask verification, not a new visual source review.','source':inp['source'],'sourceSHA256':inp['sourceSHA256'],'profile':inp['profile'],'profileSHA256':inp['profileSHA256'],'baselineSHA256':sha(W/'baseline'/f'{sid}.json'),'observerSourceExactlyLoggingOnly':True,'inputChecks':inputRows,'rows':rows,'summary':{'pages':3,'bands':sum(x['bandsCompared']for x in rows),'changedCrops':sum(len(x['changedCrops'])for x in rows),'threePriorRegressionsExactlyBaseline':True,'noNewForeignRelations':True,'allSixOriginalMaskSubsetChecksPassed':True,'perOwner297NewForeignRelations':0}}
(R/'three-source-page-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['summary'],indent=2))
