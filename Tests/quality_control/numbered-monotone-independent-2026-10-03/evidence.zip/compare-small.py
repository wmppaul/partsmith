from pathlib import Path
import json,collections,hashlib
R=Path('.build/numbered-monotone-independent-2026-10-03')
for name,study in [('original29','musical-span-independent-2026-10-03'),('addendum6','musical-span-attached-addendum-2026-10-03')]:
 old=json.loads((Path('.build')/study/'baseline/results.json').read_text());new=json.loads((R/name/'results.json').read_text());owners=[];cases=[]
 assert len(old['cases'])==len(new['cases'])==(29 if name=='original29' else 6)
 for b,c in zip(old['cases'],new['cases']):
  for f in ['id','family','scale','sourceRawSHA256','sourceShape','analysisShape','bandCount']:assert b[f]==c[f]
  assert b['canApply'] and c['canApply']
  key={f:b[f]for f in ['id','family','scale']}
  count=lambda v,alt:collections.Counter(json.dumps(x,sort_keys=True)for x in v['components']if(x.get('isOwnershipAlternative')is True)==alt)
  cases.append(dict(key,ordinaryComponentsEqual=count(b,False)==count(c,False),removedBaselineAlternatives=[json.loads(z)for z in(count(b,True)-count(c,True)).elements()],addedAlternativeComponents=[json.loads(z)for z in(count(c,True)-count(b,True)).elements()]))
  for bt,ct in zip(b['targets'],c['targets']):
   for f in ['owner','partID','sourcePixels','sourceEnvelope','sourceMaskSHA256','allowedWholeNeighborIDs','candidateIDs']:assert bt[f]==ct[f]
   oi=set(bt['lostPixelIndices']);ni=set(ct['lostPixelIndices'])
   owners.append(dict(key,owner=bt['owner'],sourceMaskSHA256=bt['sourceMaskSHA256'],sourcePixels=bt['sourcePixels'],sourceEnvelope=bt['sourceEnvelope'],baselineCrop=bt['crop'],candidateCrop=ct['crop'],baselineLost=len(oi),candidateLost=len(ni),newlyLostPixelIndices=sorted(ni-oi),recoveredPixelIndices=sorted(oi-ni),baselineSpuriousWholeNeighborIDs=bt['spuriousWholeNeighborCoreIDs'],candidateSpuriousWholeNeighborIDs=ct['spuriousWholeNeighborCoreIDs'],newSpuriousWholeNeighborIDs=sorted(set(ct['spuriousWholeNeighborCoreIDs'])-set(bt['spuriousWholeNeighborCoreIDs']))))
 summary={'sourceScaleCases':len(cases),'ownerObservations':len(owners),'sourceBindingsExact':True,'baselineCompleteOwners':sum(x['baselineLost']==0 for x in owners),'candidateCompleteOwners':sum(x['candidateLost']==0 for x in owners),'baselineLostPixels':sum(x['baselineLost']for x in owners),'candidateLostPixels':sum(x['candidateLost']for x in owners),'newlyLostPixels':sum(len(x['newlyLostPixelIndices'])for x in owners),'recoveredPixels':sum(len(x['recoveredPixelIndices'])for x in owners),'newSpuriousWholeNeighborRelations':sum(len(x['newSpuriousWholeNeighborIDs'])for x in owners),'ordinaryChangedCases':sum(not x['ordinaryComponentsEqual']for x in cases),'removedBaselineAlternativeCases':sum(bool(x['removedBaselineAlternatives'])for x in cases),'nativeElapsedSeconds':new['elapsedSeconds'],'sourceSpanInference':'Absent from this candidate; it has no sourceSpanV4 helper or raw span records. Only baseline-compatible sole-owner supports are added.'}
 (R/name/'comparison.json').write_text(json.dumps({'summary':summary,'cases':cases,'owners':owners},indent=2)+'\n');(R/name/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(name,json.dumps(summary,indent=2))
 assert not summary['newlyLostPixels'] and not summary['newSpuriousWholeNeighborRelations']
