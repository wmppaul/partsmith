import Foundation
import PDFKit
import ImageIO
import UniformTypeIdentifiers
@main enum RenderOnly {
    struct Config: Decodable { let source: String; let pageIndices: [Int]; let out: String }
    static func main() throws {
        let config = try JSONDecoder().decode(Config.self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
        let pdf = PDFDocument(url: URL(fileURLWithPath: config.source))!
        let out = URL(fileURLWithPath: config.out)
        try FileManager.default.createDirectory(at: out, withIntermediateDirectories: true)
        let start = Date()
        var records: [[String: Any]] = []
        for index in config.pageIndices {
            try autoreleasepool {
                let page = pdf.page(at: index)!
                guard let image = NativeScorePageAnalyzer.render(page) else { fatalError("Render failed on page \(index+1)") }
                let url = out.appendingPathComponent("page-\(index+1).png")
                let destination = CGImageDestinationCreateWithURL(url as CFURL, UTType.png.identifier as CFString, 1, nil)!
                CGImageDestinationAddImage(destination, image, nil)
                precondition(CGImageDestinationFinalize(destination))
                records.append(["pageIndex": index, "imageWidth": image.width, "imageHeight": image.height,
                                "bitsPerComponent": image.bitsPerComponent, "bitsPerPixel": image.bitsPerPixel,
                                "mediaBox": [page.bounds(for: .mediaBox).origin.x, page.bounds(for: .mediaBox).origin.y,
                                             page.bounds(for: .mediaBox).width, page.bounds(for: .mediaBox).height],
                                "image": url.path])
                print("Rendered page \(index+1)")
            }
        }
        let receipt: [String: Any] = ["pages": records, "elapsedSeconds": Date().timeIntervalSince(start),
                                     "method": "NativeScorePageAnalyzer.render only; no analyze, notationComponents or staff detection call"]
        try JSONSerialization.data(withJSONObject: receipt, options: [.prettyPrinted, .sortedKeys]).write(to: out.appendingPathComponent("render-receipt.json"))
    }
}
