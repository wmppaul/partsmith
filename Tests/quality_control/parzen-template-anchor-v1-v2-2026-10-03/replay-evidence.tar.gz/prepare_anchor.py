from pathlib import Path
import json,hashlib,shutil,difflib
w=Path('.build/parzen-template-probe-2026-10-03');c=w/'candidate-v1';c.mkdir(exist_ok=True);shutil.copytree(w/'observer/Core',c/'Core',dirs_exist_ok=True);p=c/'Core/Detection/ScoreSystemTemplateMatcher.swift';s=p.read_text()
old='''        return PageFeatures(pageIndex: page.pageIndex, groups: groups.enumerated().map { index, members in
            let space = members.map(\\.space).min()!
            return Group(systemIndex: index, staves: members,'''
new='''        return PageFeatures(pageIndex: page.pageIndex, groups: groups.enumerated().map { index, originalMembers in
            let members = boundaryAnchoredPatches(originalMembers, raster: raster, slope: slope, pageIndex: page.pageIndex)
            let space = members.map(\\.space).min()!
            return Group(systemIndex: index, staves: members,'''
assert old in s;s=s.replace(old,new)
pos=s.index('    private enum Connection')
helper='''    // Private experiment: source patch origin only. Existing group partition,
    // original starts/bounds and all similarity/connection gates stay unchanged.
    private static func boundaryAnchoredPatches(_ members: [StaffFeature], raster: Raster,
                                                slope: Double, pageIndex: Int) -> [StaffFeature] {
        guard members.count > 1 else { return members }
        let outerStart = members.map(\\.start).min()!
        var anchors = [[Int]](repeating: [], count: members.count)
        for i in 1..<members.count {
            let upper = members[i-1], lower = members[i]
            let space = min(upper.space, lower.space)
            let xCenter = (upper.start + lower.start) / 2
            let shift = slope * (Double(xCenter) - Double(raster.width) / 2)
            let gapTop = Int((upper.lines[4] + shift + space * 0.25).rounded())
            let gapBottom = Int((lower.lines[0] + shift - space * 0.25).rounded())
            guard gapBottom > gapTop, gapTop >= 0, gapBottom < raster.height else { continue }
            let reach = max(2, Int((space * 0.65).rounded()))
            let left = max(0, outerStart - reach)
            let right = min(raster.width-1, max(upper.start, lower.start) + reach)
            let top = max(0, Int((upper.lines[0] + shift).rounded()))
            let bottom = min(raster.height-1, Int((lower.lines[4] + shift).rounded()))
            var firstCluster: [Int] = []
            for x in left...right {
                var occupied=0, gapOccupied=0, missingRun=0, longestMissing=0
                for y in top...bottom {
                    let has = (-1...1).contains { raster.hasInk(x+$0,y) }
                    if has { occupied += 1; missingRun=0 } else { missingRun += 1; longestMissing=max(longestMissing,missingRun) }
                    if y >= gapTop && y <= gapBottom && has { gapOccupied += 1 }
                }
                let qualifies = Double(occupied)/Double(bottom-top+1) >= 0.94
                    && Double(gapOccupied)/Double(gapBottom-gapTop+1) >= 0.96
                    && Double(longestMissing) <= max(1,space*0.4)
                if qualifies { firstCluster.append(x) } else if !firstCluster.isEmpty { break }
            }
            guard let edge = firstCluster.last else { continue }
            anchors[i-1].append(edge);anchors[i].append(edge)
            MatcherProbe.record(["kind":"anchorEvidence","pageIndex":pageIndex,"upper":upper.id,"lower":lower.id,"searchX":[left,right],"firstQualifyingColumnCluster":firstCluster,"rightEdge":edge])
        }
        return members.enumerated().map { i, original in
            guard !anchors[i].isEmpty else { return original }
            let start = Int((Double(anchors[i].reduce(0,+))/Double(anchors[i].count)).rounded())
            var source = original;source.start=start
            var result = original;result.patch=clefPatch(staff:source,raster:raster,slope:slope)
            MatcherProbe.record(["kind":"anchoredStaff","pageIndex":pageIndex,"id":original.id,"oldStart":original.start,"patchStart":start,"anchorColumns":anchors[i],"patch":result.patch.map { $0 ? 1 : 0 }])
            return result
        }
    }

'''
s=s[:pos]+helper+s[pos:];p.write_text(s)
run=(w/'observer/run.swift').read_text().replace('"confidence":s.confidence.rawValue,','"confidence":s.confidence.rawValue,"staffCounts":s.staffCounts,');(c/'run.swift').write_text(run)
# A separate unchanged instrumented serializer exposes actual production staffCounts.
(w/'observer/run-with-counts.swift.txt').write_text(run)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(c/'protocol-before-results.json').write_text(json.dumps(dict(scope='Private clef-patch origin experiment only; no production changes, no connection/clef threshold change, no staff-count identity fallback.',mechanism='After unchanged source partition and outside-connection validation, inspect every adjacent pair using unchanged94%full,96%gap,0.4space gap gates. Search begins at complete group minimum measured horizontal start minus unchangedreach; take right edge of leftmost qualifying contiguous source-column cluster. Average adjacent source edge observations at each staff. Resample same28x64 patch at that anchor, preserving original start/end/sourceBounds and single-staff behavior.',risks=['Measured complete-group left margin is still a horizontal-run estimate; require old negative cases and source review to rule out interior-barline or brace origins.','Patch origin can alter which instrument-name letters are sampled; similarity alone remains a proposal, not semantic instrument identification.','No prospective claim that all staff local boundary curvature is represented by straight pair columns.'],inputSHA256=sha(w/'input.json'),old32InputSHA256=sha(Path('Tests/quality_control/system-template-independent-2026-10-03/challenge-inputs.json')),matcherSHA256=sha(p),oldThresholdsPreserved=True),indent=2)+'\n');(c/'matcher.diff').write_text(''.join(difflib.unified_diff((w/'observer/Core/Detection/ScoreSystemTemplateMatcher.swift').read_text().splitlines(True),s.splitlines(True),fromfile='observer',tofile='candidate-v1')))
