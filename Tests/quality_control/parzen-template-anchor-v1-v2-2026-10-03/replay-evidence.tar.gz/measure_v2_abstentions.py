import pathlib,json,math,numpy as np
from PIL import Image
w=pathlib.Path('.build/parzen-template-probe-2026-10-03');o=w/'candidate-v2';e=json.load(open(o/'results.json.events.json'));staff={(z['pageIndex']+1,z['id']):z for z in e if z['kind']=='staff'};anchors={(z['pageIndex']+1,z['id']):z for z in e if z['kind']in['anchoredStaff','anchorAbstention']};images={p:np.asarray(Image.open(o/f'native-source/page-{p}.png').convert('L'))<210 for p in [2,3,4,7,8,16]};rows=[];patchChecks=[]
def rnd(z):return math.floor(z+.5) if z>=0 else math.ceil(z-.5)
for p,i in [(2,9),(3,9),(4,9),(8,9),(4,7),(16,7),(4,10),(7,10)]:
 s=staff[p,i];a=anchors[p,i];im=images[p];h,W=im.shape;sp=s['space'];slope=s['slope'];lines=s['lines'];tol=max(1,rnd(sp*.15));reach=max(2,rnd(sp*.65));n=max(8,rnd(4*sp));outer=min(q['start']for(k,j),q in staff.items()if k==p)
 def ink(x,y):return 0<=x<W and 0<=y<h and bool(im[y,x])
 def hits(line,x,phase):
  y=rnd(line+phase+slope*(x-W/2));return any(ink(x,y+dy)for dy in range(-tol,tol+1))
 patch=[]
 for yy in range(64):
  dy=yy/8-2
  for xx in range(28):
   if any(abs(dy-j)<=.15 for j in range(5)):patch.append(0);continue
   x=s['start']+(xx/8+.35)*sp;y=lines[0]+dy*sp+slope*(x-W/2);patch.append(int(ink(rnd(x),rnd(y))))
 diff=sum(x!=y for x,y in zip(patch,s['patch']));patchChecks.append({'page':p,'staffID':i,'productionPatchPixelsDifferent':diff,'total':len(patch)})
 for x in a['candidateColumns']:
  trials=[]
  for phase in range(-math.ceil(sp*2),math.ceil(sp*2)+1):
   run=0;begin=None
   for xx in range(max(0,outer-n-reach),min(W-1,x+n+reach)+1):
    run=run+1 if sum(hits(line,xx,phase)for line in lines)>=4 else 0
    if run>=n:begin=xx-run+1;break
   right=[sum(hits(line,xx,phase)for xx in range(x+1,x+n+1))/n for line in lines]
   leftRange=range(x-n,x-reach);left=[sum(hits(line,xx,phase)for xx in leftRange)/len(leftRange)for line in lines]
   trials.append({'phase':phase,'firstHorizontalStart':begin,'endpointGate':begin is not None and abs(begin-x)<=reach,'fiveLineMinimum':min(right),'fiveRightCoverage':right,'fiveExteriorCoverage':left,'allFiveGate':min(right)>=.94,'exteriorGate':max(left)<=.25})
  row={'page':p,'staffID':i,'anchor':x,'space':sp,'oldStart':s['start'],'actualCandidateAction':a['kind'],'bestFiveLineTrial':max(trials,key=lambda t:(t['fiveLineMinimum'],-abs(t['phase']))),'bestAllOtherGatesTrial':max([t for t in trials if t['endpointGate']and t['exteriorGate']],key=lambda t:t['fiveLineMinimum'],default=None),'passingTrials':[t for t in trials if t['endpointGate']and t['allFiveGate']and t['exteriorGate']],'trials':trials};rows.append(row)
result={'scope':'Read-only failed-gate measurement, no retuned criteria or matcher output; original native render method verified identical. Pillow threshold raster accepted only where complete production patch reproduces exactly.','patchReproduction':patchChecks,'allSelectedProductionPatchesExact':all(x['productionPatchPixelsDifferent']==0 for x in patchChecks),'measurements':rows};(o/'abstention-measurements.json').write_text(json.dumps(result,indent=2)+'\n')
print('patch differences',patchChecks)
for r in rows:
 print(r['page'],r['staffID'],r['anchor'],'bestFive',r['bestFiveLineTrial'],'passing',len(r['passingTrials']))
