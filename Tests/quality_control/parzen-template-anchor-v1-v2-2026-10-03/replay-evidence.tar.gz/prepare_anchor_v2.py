from pathlib import Path
import json,hashlib,shutil,difflib
w=Path('.build/parzen-template-probe-2026-10-03');v1=w/'candidate-v1';v2=w/'candidate-v2';v2.mkdir(exist_ok=True);shutil.copytree(v1/'Core',v2/'Core',dirs_exist_ok=True);shutil.copy2(v1/'run.swift',v2/'run.swift');p=v2/'Core/Detection/ScoreSystemTemplateMatcher.swift';s=p.read_text();start=s.index('    // Private experiment:');end=s.index('    private enum Connection',start)
helper='''    // Private v2: a vertical connection is only a clef origin when all five
    // actual horizontal staff ridges begin there. Distinct source paths are not averaged.
    private static func boundaryAnchoredPatches(_ members: [StaffFeature], raster: Raster,
                                                slope: Double, pageIndex: Int) -> [StaffFeature] {
        guard members.count > 1 else { return members }
        let outerStart = members.map(\\.start).min()!
        var anchors = [[Int]](repeating: [], count: members.count)
        for i in 1..<members.count {
            let upper=members[i-1], lower=members[i], space=min(members[i-1].space,members[i].space)
            let shift=slope*(Double((upper.start+lower.start)/2)-Double(raster.width)/2)
            let gapTop=Int((upper.lines[4]+shift+space*0.25).rounded())
            let gapBottom=Int((lower.lines[0]+shift-space*0.25).rounded())
            guard gapBottom>gapTop, gapTop>=0, gapBottom<raster.height else {continue}
            let reach=max(2,Int((space*0.65).rounded()))
            let left=max(0,outerStart-reach),right=min(raster.width-1,max(upper.start,lower.start)+reach)
            let top=max(0,Int((upper.lines[0]+shift).rounded())),bottom=min(raster.height-1,Int((lower.lines[4]+shift).rounded()))
            var clusters=[[Int]](),cluster=[Int]()
            for x in left...right {
                var occupied=0,gapOccupied=0,missingRun=0,longestMissing=0
                for y in top...bottom {
                    let has=(-1...1).contains {raster.hasInk(x+$0,y)}
                    if has {occupied+=1;missingRun=0} else {missingRun+=1;longestMissing=max(longestMissing,missingRun)}
                    if y>=gapTop && y<=gapBottom && has {gapOccupied+=1}
                }
                let qualifies=Double(occupied)/Double(bottom-top+1)>=0.94
                    && Double(gapOccupied)/Double(gapBottom-gapTop+1)>=0.96
                    && Double(longestMissing)<=max(1,space*0.4)
                if qualifies {cluster.append(x)} else if !cluster.isEmpty {clusters.append(cluster);cluster=[]}
            }
            if !cluster.isEmpty {clusters.append(cluster)}
            let edges=clusters.compactMap(\\.last);anchors[i-1]+=edges;anchors[i]+=edges
            MatcherProbe.record(["kind":"anchorEvidence","pageIndex":pageIndex,"upper":upper.id,"lower":lower.id,"searchX":[left,right],"qualifyingColumnClusters":clusters])
        }
        return members.enumerated().map { i, original in
            let space=original.space,tolerance=max(1,Int((space*0.15).rounded()))
            let reach=max(2,Int((space*0.65).rounded())),runLength=max(8,Int((4*space).rounded()))
            var choices=[(x:Int,phase:Int,support:Double,start:Int)]()
            for anchor in Set(anchors[i]).sorted() {
                let firstX=max(0,outerStart-runLength-reach),lastX=min(raster.width-1,anchor+runLength+reach)
                guard anchor-runLength>=0,anchor+runLength<raster.width else {continue}
                var best:(phase:Int,support:Double,start:Int)?
                for phase in -Int(ceil(space*2))...Int(ceil(space*2)) {
                    func lineHits(_ line:Double,_ x:Int)->Bool {
                        let y=Int((line+Double(phase)+slope*(Double(x)-Double(raster.width)/2)).rounded())
                        return (-tolerance...tolerance).contains {raster.hasInk(x,y+$0)}
                    }
                    var run=0,begin:Int?
                    for x in firstX...lastX {
                        let supported=original.lines.filter {lineHits($0,x)}.count>=4
                        run=supported ? run+1:0
                        if run>=runLength {begin=x-run+1;break}
                    }
                    guard let begin,abs(begin-anchor)<=reach else {continue}
                    let rightRange=(anchor+1)...(anchor+runLength)
                    let rightSupport=original.lines.map { line in Double(rightRange.filter {lineHits(line,$0)}.count)/Double(rightRange.count) }
                    guard let minimum=rightSupport.min(),minimum>=0.94 else {continue}
                    let leftRange=(anchor-runLength)...(anchor-reach-1)
                    let exterior=original.lines.map {line in Double(leftRange.filter {lineHits(line,$0)}.count)/Double(leftRange.count)}
                    guard exterior.allSatisfy({$0<=0.25}) else {continue}
                    if best == nil || minimum>best!.support || (minimum==best!.support && abs(phase)<abs(best!.phase)) {best=(phase,minimum,begin)}
                }
                if let best {choices.append((anchor,best.phase,best.support,best.start))}
            }
            // Pick one observed source path. A rightmost valid edge lies inside
            // the bounded horizontal-line start corridor, never a late barline.
            guard let choice=choices.max(by: {$0.x < $1.x}) else {
                MatcherProbe.record(["kind":"anchorAbstention","pageIndex":pageIndex,"id":original.id,"candidateColumns":Set(anchors[i]).sorted()])
                return original
            }
            var source=original;source.start=choice.x;source.lines=original.lines.map {$0+Double(choice.phase)}
            var result=original;result.patch=clefPatch(staff:source,raster:raster,slope:slope)
            MatcherProbe.record(["kind":"anchoredStaff","pageIndex":pageIndex,"id":original.id,"oldStart":original.start,"patchStart":choice.x,"localPhase":choice.phase,"minimumFiveLineSupport":choice.support,"measuredHorizontalStart":choice.start,"candidateColumns":Set(anchors[i]).sorted(),"patch":result.patch.map {$0 ? 1:0}])
            return result
        }
    }

'''
s=s[:start]+helper+s[end:];p.write_text(s);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(v2/'protocol-before-results.json').write_text(json.dumps(dict(scope='Private source-boundary/line-phase patch measurement; current system grouping/identity and match thresholds unchanged. No production edit.',evidence='Each candidate source column first passes unchanged94% full/96% gap/0.4space gap vertical gates. Scan local phase within2staffspaces. Require earliest4-space run of existing4-of-five-column support to begin within existing0.65space reach of column; independently every one of5rightward line ridges must have94% support over4spaces. Each numbered line must have at most25%left support over exterior interval. This rejects bracket-only and interior-barline paths. Choose one rightmost surviving source edge; never average structures. If no evidence, keep original patch rather than combine scores.',newMeasurementParametersFrozenBeforeResults={'phaseSearchSpaces':2,'exteriorMaximumEachLineFraction':.25,'eachFiveLineMinimumRightSupport':.94,'rightRunSpaces':4},remainingRisk='Nominal per-line offsets/spacing remain; severe local spacing distortion may abstain. Exterior text may force conservative abstention. Source edge proof is not semantic instrument identity; output remains assistive.',matcherSHA256=sha(p),inputSHA256=sha(w/'input.json'),historical32InputsUnchanged=True),indent=2)+'\n');(v2/'versus-v1.diff').write_text(''.join(difflib.unified_diff((v1/'Core/Detection/ScoreSystemTemplateMatcher.swift').read_text().splitlines(True),s.splitlines(True),fromfile='v1',tofile='v2')))
