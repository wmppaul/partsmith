import pathlib,json,hashlib,tarfile,collections,shutil
w=pathlib.Path('.build/parzen-template-probe-2026-10-03');out=pathlib.Path('Tests/quality_control/parzen-template-anchor-v1-v2-2026-10-03');out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
base=json.load(open(w/'baseline-results.json'))[0];oldPages={s['pageIndex']+1 for s in base['suggestions']};expected={s['pageIndex']:s for s in json.load(open(w/'expected-before-result.json'))['unseededSystems']};records={};profile=json.load(open(w/'input.json'))[0]['profile'];write(w/'profile.json',profile)
for label in ['candidate-v1','candidate-v2']:
 r=json.load(open(w/label/'results.json'))[0];e=json.load(open(w/label/'results.json.events.json'));err=[]
 for s in r['suggestions']:
  ex=expected[s['pageIndex']]
  for k in ['candidateIDs','staffCounts','presentPartIDs']:
   a,b=s[k],ex[k]
   if k=='presentPartIDs':a,b=sorted(a),sorted(b)
   if a!=b:err.append([s['pageIndex'],k])
  assert s['barCount'] is None and s['startBarNumber'] is None
 pages={s['pageIndex']+1 for s in r['suggestions']};rows=[{'page':z['pageIndex']+1,'templatePage':z['templatePageIndex']+1,'candidateIDs':z['candidateIDs'],'scores':z['scores'],'minimum':min(z['scores']),'failingStaffs':[{'id':i,'score':v}for i,v in zip(z['candidateIDs'],z['scores'])if v<.48]}for z in e if z['kind']=='comparison'];write(w/label/'per-staff-scores.json',rows)
 records[label]={'suggestions':len(pages),'unseededSystems':24,'physicalPages':sorted(pages),'confidenceCounts':dict(collections.Counter(s['confidence']for s in r['suggestions'])),'sourceGroupingErrors':err,'baselinePagesRetained':sorted(pages&oldPages),'baselinePagesLost':sorted(oldPages-pages),'newPages':sorted(pages-oldPages),'abstentions':len(r['diagnostics']),'elapsedSeconds':r['elapsedSeconds'],'matcherSHA256':sha(w/label/'Core/Detection/ScoreSystemTemplateMatcher.swift'),'resultSHA256':sha(w/label/'results.json'),'historical32ComparableOutputsUnchanged':True,'historicalOriginalExpectations':{'pass':31,'fail':1,'existingConflict':'notte-changed-profile-count: per-system count API now learns reviewed counts; original expectation still records failure.'}}
 assert not err
summary={'scope':'Private diagnosis only; v1 and v2 not promoted. All26 source music systems, 24unseeded,568physical staves. No source notes/crops/export changed.','source':json.load(open(w/'input.json'))[0]['sourcePath'],'sourceSHA256':sha(json.load(open(w/'input.json'))[0]['sourcePath']),'baseline':{'suggestions':6,'physicalPages':sorted(oldPages),'allNeedsReview':True,'completeGroups':26,'connectedPairChecks':542,'causeOf18Abstentions':'Per-staff clef-patch score below unchanged0.48; not connection partition or staff counts.'},'extraReviewedSeeds':{'addedPhysicalPages':[3,19],'suggestions':11,'remainingUnseeded':22,'allNeedsReview':True,'limit':'Additional manual setup, not an algorithm gain. Old serializer lacks actual staffCounts, unlike both private candidates.'},'candidates':records,'productionUnchanged':{'matcherSHA256':sha('Partsmith/Core/Detection/ScoreSystemTemplateMatcher.swift'),'NativeSHA256':sha('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift')},'limitations':['Candidate historical equivalence excludes elapsed time and actual staffCounts field newly added to serializer; actual Parzen staffCounts are independently compared to frozen source.','v1 chooses a bracket for one adjacent pair and barline for the other on p8 staff9, then averages unlike structures.','v2 rejects useful true thick/double barline endpoints because the measured earliest line start and chosen right edge differ by more than existing reach; it changes seed p4 staff7 but abstains target p16 staff7, losing a previous valid proposal.','Neither candidate qualifies as a robust improvement. No production changes or cleanup promotion.']}
write(out/'summary.json',summary)
write(out/'source-regression-examples.json',{'sourceSHA256':summary['sourceSHA256'],'cases':[{'page':2,'staffID':9,'finding':'Nominal x454 samples notes after F clef; actual left boundary anchor320. v2 phase-7 has100% five-line support but first horizontal start309, so endpoint/exterior proof abstains.','panel':'candidate-v2/source-review/p2-staff9.png'},{'page':8,'staffID':9,'finding':'v1 adjacent columns72outer bracket and89staff boundary are distinct structures; averaging to81 introduces wrong ink. v2 abstains.','panel':'candidate-v2/source-review/p8-staff9.png'},{'page':16,'staffID':7,'finding':'Five lines100% supported; start73 vs boundary rightedges81/83 fails endpoint proof. Changed seed p4 versus unchanged target loses baseline page16.','panel':'candidate-v2/source-review/p16-staff7.png'}],'measurement':'candidate-v2/abstention-measurements.json','exactSourcePixelCheck':'All8selected production patches reproduce1792/1792pixels from original native source rasters. No detector replay for these6render-only pages.'})
readme='''# Parzen template matching: two rejected private anchor trials

Production recognizes 6 of 24 unseeded full systems. All 26 source systems form the correct complete connected groups, and all 542 inter-staff connections pass. The 18 abstentions arise from clef-patch similarity. Some patch origins include a bracket or instrument label; the opening Trombone III/Tuba patch lands on notes after the F clef.

| Run | Reviewed seeds | Correct suggestions | Remaining abstentions | Previously suggested pages lost |
| --- | --- | --- | --- | --- |
| Shipping production | 2, 4 | 6/24 | 18 | — |
| Production with extra manual seeds | 2, 3, 4, 19 | 11/22 | 11 | Not comparable denominator |
| Private v1 | 2, 4 | 15/24 | 9 | 8 |
| Private v2 | 2, 4 | 11/24 | 13 | 16 |

Every v1/v2 suggestion has the exact frozen source candidate IDs, present parts, and actual per-part staffCounts. V1 averages two distinct structures at a bracket. V2 measures all five horizontal ridges and local phase, but a true thick/double boundary has different left and right edges; treating it as one point rejects useful patches. Neither trial is promoted.

All 32 historical comparable outputs are byte-equivalent after excluding elapsed time and the newly serialized staffCounts field. The unchanged original assessor reports 31 passes and the existing `notte-changed-profile-count` conflict: the released per-system grouping API now honors reviewed counts. That failure is preserved, not waived. Parzen grouping is independently checked using the new actual staffCounts field.

The archive preserves exact inputs, expected source maps, current Core snapshot with observation-only instrumentation, both private Core snapshots, protocols frozen before results, complete result/event JSON, per-staff score vectors, build/run logs, source panels, and six native render-only pages used for the failed-gate measurements. Eight production patches reproduce all 1,792 pixels each from those original rasters. Source PDF is hash-linked and is not duplicated. Instrument guesses, missing bar counts, crop algorithms, and production files were not changed.

Future work should represent the whole observed boundary band, keeping its horizontal-line intersection separate from the right edge used to sample the clef. It must reject bracket-only paths, preserve old rejection behavior, and avoid comparing a normalized seed against an unnormalized target without compatible evidence. This is a proposal, not validated code.
'''
(out/'README.md').write_text(readme)
# Preserve actual baseline Core separately from observed matcher without duplicating every other file.
assert summary['productionUnchanged']['matcherSHA256']=='6abb036e0b6c1e3678d78cb6702ad2f558ddb4b8b8fd5436e350186f139a0351'
shutil.copy2('Partsmith/Core/Detection/ScoreSystemTemplateMatcher.swift',w/'production-ScoreSystemTemplateMatcher.swift')
# Small actual command receipt. Archives omit executable binaries, whose hashes remain bound.
write(w/'executables-and-commands.json',{'binaries':{str(p):sha(p)for p in [w/'observer/run',w/'candidate-v1/run',w/'candidate-v2/run',pathlib.Path('.build/divisi-assignment-release-v2-2026-10-03/challenges/run')]},'compile':'DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer xcrun swiftc -O -module-cache-path .build/ModuleCache <variant>/Core/**/*.swift <variant>/run.swift -o <variant>/run > <variant>/build.log 2>&1','parzen':'<variant>/run .build/parzen-template-probe-2026-10-03/input.json <variant>/results.json','historical':'<variant>/run Tests/quality_control/system-template-independent-2026-10-03/challenge-inputs.json <variant>/challenge-results.json','extraSeeds':'Unchanged .build/divisi-assignment-release-v2-2026-10-03/challenges/run with extra-seeds-input.json -> extra-seeds-results.json','historicalInputSHA256':sha('Tests/quality_control/system-template-independent-2026-10-03/challenge-inputs.json')})
files=[]
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.name=='run' or 'candidate-v3' in p.parts:continue
 if p.suffix in ['.json','.swift','.py','.log','.png','.diff','.txt']:files.append((p,p.relative_to(w).as_posix()))
for name in ['challenge-inputs.json','assess_challenges.py']:
 p=pathlib.Path('Tests/quality_control/system-template-independent-2026-10-03')/name;files.append((p,'historical/'+name))
for name in ['results.json','results-assessment.json']:
 p=pathlib.Path('.build/divisi-assignment-release-v2-2026-10-03/challenges')/name;files.append((p,'historical/production-'+name))
for name in ['render.swift','executable-binding.json']:
 p=pathlib.Path('.build/brahms-raw-corrected-review-reuse-2026-10-03')/name;files.append((p,'native-render-helper/'+name))
archive=out/'replay-evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz')as tar:
 for p,name in files:tar.add(p,arcname=name);members.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
with tarfile.open(archive,'r:gz')as tar:
 for m in members:
  data=tar.extractfile(m['path']).read();assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
write(out/'archive-members.json',members)
write(out/'manifest.json',{'scope':'Bounded v1/v2 diagnosis frozen; no production promotion.','verifiedArchiveMembers':len(members),'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in out.iterdir()if p.is_file()and p.name!='manifest.json'}})
print(out,sha(out/'manifest.json'),len(members),archive.stat().st_size)
