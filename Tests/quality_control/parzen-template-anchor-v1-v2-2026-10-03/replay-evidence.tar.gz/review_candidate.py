import pathlib,json,pymupdf as f
from PIL import Image,ImageDraw
w=pathlib.Path('.build/parzen-template-probe-2026-10-03');e=json.load(open(w/'candidate-v1/results.json.events.json'));s={(x['pageIndex']+1,x['id']):x for x in e if x['kind']=='staff'};a={(x['pageIndex']+1,x['id']):x for x in e if x['kind']=='anchoredStaff'};d=f.open(json.load(open(w/'input.json'))[0]['sourcePath']);out=w/'candidate-v1/source-review';out.mkdir(exist_ok=True)
print('disagreements',[(p,i,q['anchorColumns']) for (p,i),q in a.items() if len(q['anchorColumns'])==2 and abs(q['anchorColumns'][0]-q['anchorColumns'][1])>s[p,i]['space']*.65])
cases=[(2,9),(3,9),(4,9),(8,9),(4,10),(7,10)];ims=[]
for p,i in cases:
 q=s[p,i];ar=a[p,i];sp=q['space'];top=q['lines'][0];ratio=595.2/1800;xs=[q['start'],ar['patchStart']];rect=[(min(xs)-2*sp)*ratio,(top-2.5*sp)*ratio,(max(xs)+7*sp)*ratio,(top+7*sp)*ratio];pix=d[p-1].get_pixmap(matrix=f.Matrix(6,6),clip=f.Rect(rect));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);draw=ImageDraw.Draw(im)
 for start,col in [(q['start'],'red'),(ar['patchStart'],'blue')]:
  r=[(start+.35*sp)*ratio,(top-2*sp)*ratio,(start+3.725*sp)*ratio,(top+5.875*sp)*ratio];draw.rectangle([(r[0]*6-pix.x,r[1]*6-pix.y),(r[2]*6-pix.x,r[3]*6-pix.y)],outline=col,width=2)
 can=Image.new('RGB',(im.width+230,max(im.height,256)+45),'white');can.paste(im,(0,45))
 for n,bits in enumerate([q['patch'],ar['patch']]):
  patch=Image.new('L',(28,64));patch.putdata([0 if z else 255 for z in bits]);patch=patch.resize((112,256));can.paste(patch,(im.width+3+115*n,45))
 ImageDraw.Draw(can).text((5,5),f'p{p} staff{i}: red old{q["start"]}; blue anchor{ar["patchStart"]}; pair columns{ar["anchorColumns"]}',fill='black');path=out/f'p{p}-staff{i}.png';can.save(path);ims.append(can)
for k in range(0,len(ims),2):
 rr=ims[k:k+2];sheet=Image.new('RGB',(max(i.width for i in rr),sum(i.height for i in rr)+12),'#ccc');y=0
 for im in rr:sheet.paste(im,(0,y));y+=im.height+12
 sheet.save(out/f'contact-{k//2+1:02}.png')
