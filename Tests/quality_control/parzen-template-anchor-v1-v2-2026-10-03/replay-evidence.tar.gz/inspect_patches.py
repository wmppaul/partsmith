from pathlib import Path
import json,pymupdf as f
from PIL import Image,ImageDraw
w=Path('.build/parzen-template-probe-2026-10-03');e=json.load(open(w/'observer/results.json.events.json'));s={(x['pageIndex']+1,x['id']):x for x in e if x['kind']=='staff'};d=f.open(json.load(open(w/'input.json'))[0]['sourcePath']);out=w/'patch-review';out.mkdir(exist_ok=True)
cases=[(4,10),(7,10),(4,9),(12,9),(4,15),(11,15),(2,9),(3,9),(4,4),(26,4),(4,3),(26,3)]
ims=[];records=[]
for p,i in cases:
 q=s[(p,i)];ratio=d[p-1].rect.width/q['imageWidth'];sp=q['space'];x=q['start'];top=q['lines'][0];rect=[(x-2*sp)*ratio,(top-2.5*sp)*ratio,(x+7*sp)*ratio,(top+7*sp)*ratio];pix=d[p-1].get_pixmap(matrix=f.Matrix(8,8),clip=f.Rect(rect));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);draw=ImageDraw.Draw(im);actual=[(x+.35*sp)*ratio,(top-2*sp)*ratio,(x+3.725*sp)*ratio,(top+5.875*sp)*ratio];draw.rectangle([(actual[0]*8-pix.x,actual[1]*8-pix.y),(actual[2]*8-pix.x,actual[3]*8-pix.y)],outline='red',width=2)
 patch=Image.new('L',(28,64));patch.putdata([0 if v else 255 for v in q['patch']]);patch=patch.resize((112,256));can=Image.new('RGB',(max(im.width,320)+120,max(im.height,256)+40),'white');can.paste(im,(0,40));can.paste(patch,(max(im.width,320)+5,40));ImageDraw.Draw(can).text((5,5),f'p{p} staff{i}: original + exact sampled patch; start{x} space{sp:.2f}',fill='black');path=out/f'p{p}-staff{i}.png';can.save(path);ims.append(can);records.append(dict(page=p,staffID=i,context=rect,patchSourceBox=actual,sourceStart=x,space=sp,path=str(path)))
for k in range(0,len(ims),4):
 rows=ims[k:k+4];sw=max(i.width for i in rows);sh=max(i.height for i in rows);sheet=Image.new('RGB',(sw*2,sh*2),'#ccc')
 for n,im in enumerate(rows):sheet.paste(im,((n%2)*sw,(n//2)*sh))
 sheet.save(out/f'contact-{k//4+1:02}.png')
(out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
