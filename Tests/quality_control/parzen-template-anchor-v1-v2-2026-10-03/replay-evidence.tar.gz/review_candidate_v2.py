import pathlib,json,hashlib,pymupdf as f
from PIL import Image,ImageDraw
w=pathlib.Path('.build/parzen-template-probe-2026-10-03');out=w/'candidate-v2/source-review';out.mkdir(exist_ok=True)
e=json.load(open(w/'candidate-v2/results.json.events.json'));e1=json.load(open(w/'candidate-v1/results.json.events.json'));s={(x['pageIndex']+1,x['id']):x for x in e if x['kind']=='staff'};a={(x['pageIndex']+1,x['id']):x for x in e if x['kind']in ['anchoredStaff','anchorAbstention']};a1={(x['pageIndex']+1,x['id']):x for x in e1 if x['kind']=='anchoredStaff'};d=f.open(json.load(open(w/'input.json'))[0]['sourcePath']);index=[];images=[]
for p,i in [(2,9),(3,9),(4,9),(8,9),(4,7),(16,7),(4,10),(7,10)]:
 q=s[p,i];ar=a[p,i];ar1=a1[p,i];sp=q['space'];top=q['lines'][0];rx=d[p-1].rect.width/q['imageWidth'];ry=d[p-1].rect.height/q['imageHeight'];starts=[q['start'],ar.get('patchStart',q['start']),ar1['patchStart']];phases=[0,ar.get('localPhase',0),0];colors=['red','green','blue'];names=['production','v2','v1'];shift=q['slope']*(min(starts)-q['imageWidth']/2);rect=[(min(starts)-2*sp)*rx,(top-2.8*sp+shift)*ry,(max(starts)+7*sp)*rx,(top+7*sp+shift)*ry];pix=d[p-1].get_pixmap(matrix=f.Matrix(6,6),clip=f.Rect(rect));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);draw=ImageDraw.Draw(im)
 for name,x,phase,col in zip(names,starts,phases,colors):
  corners=[]
  for nx,ny in [(x+.35*sp,top-2*sp+phase),(x+3.725*sp,top-2*sp+phase),(x+3.725*sp,top+5.875*sp+phase),(x+.35*sp,top+5.875*sp+phase)]:corners.append((nx*rx*6-pix.x,(ny+q['slope']*(nx-q['imageWidth']/2))*ry*6-pix.y))
  draw.line(corners+[corners[0]],fill=col,width=2)
 can=Image.new('RGB',(im.width+348,max(im.height,270)+75),'white');can.paste(im,(0,75));dr=ImageDraw.Draw(can);dr.text((5,5),f'p{p}, staff {i}: production {q["start"]}; v1 {ar1["patchStart"]}; v2 {ar.get("patchStart","abstain")} phase {ar.get("localPhase","-")}',fill='black');dr.text((5,22),f'Candidates {ar["candidateColumns"]}; source-native ratios x={rx:.7f}, y={ry:.7f}',fill='black');dr.text((5,39),'Red production; blue v1; green v2. Source render, not whiteout or crop alteration.',fill='black')
 for n,(name,bits) in enumerate(zip(names,[q['patch'],ar.get('patch',q['patch']),ar1['patch']])):
  patch=Image.new('L',(28,64));patch.putdata([0 if z else 255 for z in bits]);patch=patch.resize((112,256));can.paste(patch,(im.width+3+115*n,95));dr.text((im.width+3+115*n,78),name,fill=colors[n])
 path=out/f'p{p}-staff{i}.png';can.save(path);images.append(can);index.append({'page':p,'staffID':i,'sourceClipPDFPoints':rect,'image':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sourceNativeDimensions':[q['imageWidth'],q['imageHeight']],'productionStart':q['start'],'v1Start':ar1['patchStart'],'v2Evidence':{k:v for k,v in ar.items()if k!='patch'}})
for j in range(0,len(images),2):
 ims=images[j:j+2];can=Image.new('RGB',(max(t.width for t in ims),sum(t.height for t in ims)+12),'#ccc');y=0
 for im in ims:can.paste(im,(0,y));y+=im.height+12
 can.save(out/f'contact-{j//2+1:02}.png')
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n')
