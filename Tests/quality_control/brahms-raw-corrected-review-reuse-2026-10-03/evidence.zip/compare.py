from pathlib import Path
import json,hashlib,collections
import numpy as np
from PIL import Image
R=Path('.build/brahms-raw-corrected-review-reuse-2026-10-03');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();sid='medium-skewed-06-brahms-string-quartet-no3-op67-imslp-93521'
for p,h in read(R/'input-bindings-before-results.json').items():assert sha(p)==h
raw0=read(Path('.build/envelope-compatibility-corpus-2026-10-03/baseline')/(sid+'.json'));raw1=read(Path('.build/monotone-line-corpus-2026-10-03/candidate')/(sid+'.json'));corrected0=read('.build/ownership-alternatives-2026-10-03/actual.json');corrected1=read('.build/brahms-monotone-compatibility-full-2026-10-03/candidate.json');e32=read('.build/brahms-envelope-compatibility-full-2026-10-03/candidate.json');combo=read('.build/brahms-numbered-spans-v4-full-2026-10-03/candidate.json');assert e32['plan']==combo['plan']
reviewRoot=Path('Tests/quality_control/monotone-corrected39-independent-2026-10-03');central=read(reviewRoot/'review.json');assert sha('.build/brahms-monotone-compatibility-full-2026-10-03/candidate.json')==central['candidateSHA256'];assert sha('.build/ownership-alternatives-2026-10-03/actual.json')==central['originalBaselineSHA256'];assert sha('.build/brahms-envelope-compatibility-full-2026-10-03/candidate.json')==central['previousE32SHA256']
# Complete decoded full-page pixel comparison; neither dimensions nor encoded PNG hashes substitute for pixel equality.
pixelRows=[];render=read(R/'native-raw-renders/render-receipt.json')
for entry in render['pages']:
 n=entry['pageIndex']+1;a=Path(entry['image']);b=Path('.build/brahms-source-span-full-replay-2026-10-03/rasters')/f'page-{n}.png';aa=np.asarray(Image.open(a).convert('RGBA'));bb=np.asarray(Image.open(b).convert('RGBA'));same=aa.shape==bb.shape and np.array_equal(aa,bb)
 pixelRows.append({'page':n,'nativeRenderPNG':str(a),'nativePNG_SHA256':sha(a),'savedRaster':str(b),'savedPNG_SHA256':sha(b),'nativeDecodedShape':list(aa.shape),'savedDecodedShape':list(bb.shape),'nativeDecodedRGBA_SHA256':hashlib.sha256(aa.tobytes()).hexdigest(),'savedDecodedRGBA_SHA256':hashlib.sha256(bb.tobytes()).hexdigest(),'decodedPixelsExactlyEqual':same,'differingPixels':int(np.any(aa!=bb,axis=2).sum())if aa.shape==bb.shape else None})
(R/'decoded-pixel-comparison.json').write_text(json.dumps(pixelRows,indent=2)+'\n');pixels={x['page']:x for x in pixelRows}
# Bind each actual source-review leaf rather than treating every unchanged area as reviewed.
leaves={};refs=[]
def load(p):d=read(p);refs.append({'path':str(p),'sha256':sha(p)});return d
def add(bid,p,entry,route):leaves[bid]={'leafReceipt':str(p),'leafReceiptSHA256':sha(p),'leafEntry':entry,'route':route}
for p in [reviewRoot/'own54-source-review.json',reviewRoot/'ending-review/review.json']:
 for row in load(p)['rows']:add(row['band'],p,row,'direct monotone corrected-source review')
priorSources=[('Tests/quality_control/numbered-v2-source-v4-independent-2026-10-03/review.json','records','bandID'),('Tests/quality_control/combined-span-v4-real-pages20-29-2026-10-03/per-band-review.json',None,'band'),('Tests/quality_control/brahms-numbered-spans-v4-full-2026-10-03/root-source-review-pages30-39.json','bands','band')]
priorLeaves={}
for path,key,idKey in priorSources:
 p=Path(path);d=load(p);arr=d[key]if key else d
 for row in arr:priorLeaves[row[idKey]]={'path':p,'entry':row}
assert len(priorLeaves)==252
area=load(reviewRoot/'independent-previous-area-comparison.json');sameAreas=set(area['exactPreviousAreas'])
for bid,leaf in priorLeaves.items():
 if bid in sameAreas and bid not in leaves:add(bid,leaf['path'],leaf['entry'],'exact e32 area, whose complete plan equals the prior reviewed combined plan')
assert len(leaves)==267
correctedPages={x['pageIndex']+1 for x in corrected0['rectifications']};reused=[];remaining=[];pages=[]
rect=lambda b,p:[b['leftFraction']*p['pageWidth'],b['topFraction']*p['pageHeight'],(1-b['rightFraction'])*p['pageWidth'],b['bottomFraction']*p['pageHeight']]
geomKeys=['pageIndex','pageWidth','pageHeight','imageWidth','imageHeight','analysisSkewDegrees','staves'];identityKeys=['id','pageIndex','systemIndex','partID','candidateIDs','kind','generatedRest']
for n in range(1,40):
 pages.append({'page':n,'savedCorrectionPresent':n in correctedPages,'pixelIdentityProved':n in pixels and pixels[n]['decodedPixelsExactlyEqual'],'rawBaselineAndCorrectedGeometryExact':all(raw0['pages'][n-1].get(k)==corrected0['pages'][n-1].get(k)for k in geomKeys),'rawCandidateAndCorrectedGeometryExact':all(raw1['pages'][n-1].get(k)==corrected1['pages'][n-1].get(k)for k in geomKeys)})
for job in read(R/'pending-before.json'):
 n=job['page'];bid=job['bandID'];reasons=[];rawpg0,rawpg1,corpg0,corpg1=[v['pages'][n-1]for v in [raw0,raw1,corrected0,corrected1]];bands=[]
 for v in [raw0,raw1,corrected0,corrected1]:bands.append(next((b for b in v['plan']['pages'][n-1]['assignments']if b['id']==bid),None))
 if n in correctedPages:reasons.append('Saved corrected page; no uncorrected-pixel review reuse permitted')
 if n not in pixels or not pixels[n]['decodedPixelsExactlyEqual']:reasons.append('Exact decoded native/raw versus saved raster pixels not proved')
 if not pages[n-1]['rawBaselineAndCorrectedGeometryExact']or not pages[n-1]['rawCandidateAndCorrectedGeometryExact']:reasons.append('Page geometry or staff records differ')
 if any(b is None for b in bands):reasons.append('Matching complete assignment ID missing')
 else:
  a,b,c,d=bands
  if not all(a.get(k)==c.get(k)and b.get(k)==d.get(k)for k in identityKeys):reasons.append('Intended part/system/staff assignment differs')
  if rect(a,rawpg0)!=rect(c,corpg0):reasons.append('Production baseline crop differs between raw and corrected runs')
  if rect(b,rawpg1)!=rect(d,corpg1):reasons.append('Monotone crop differs between raw and corrected runs')
 if bid not in leaves:reasons.append('No actual reviewed source-area leaf for this candidate crop')
 if reasons:remaining.append({**job,'reuseRejectedReasons':reasons})
 else:
  leaf=leaves[bid];reused.append({'id':sid,'bandID':bid,'page':n,'sourceSHA256':corrected0['sourceSHA256'],'candidateIDs':b['candidateIDs'],'partID':b['partID'],'beforePDFBounds':rect(a,rawpg0),'afterPDFBounds':rect(b,rawpg1),'pixelProof':pixels[n],'pageAndAssignmentGeometryExact':True,**leaf})
summary={'pendingBefore':253,'renderedUncorrectedPages':len(pixelRows),'decodedPixelIdenticalPages':sum(x['decodedPixelsExactlyEqual']for x in pixelRows),'reusedReviewedBands':len(reused),'remainingPendingBands':len(remaining),'remainingByPage':dict(sorted(collections.Counter(x['page']for x in remaining).items())),'remainingReasons':dict(collections.Counter(r for x in remaining for r in x['reuseRejectedReasons'])),'method':'Native render-only, full decoded RGBA pixel equality, exact raw/corrected geometry/ownership and both crop rectangles, actual hash-bound source-review leaves.','limits':'No analyzer run, no new musical visual review, no old guard waived, no broad source completeness approval. Missing pixel or geometry proof remains pending.'}
for name,data in [('summary.json',summary),('reused-reviewed-bands.json',reused),('remaining-pending-bands.json',remaining),('page-geometry-checks.json',pages),('source-review-leaf-bindings.json',refs)]: (R/name).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(summary,indent=2))
