from pathlib import Path
import json,hashlib
R=Path('.build/brahms-raw-corrected-review-reuse-2026-10-03');read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();rows=read(R/'reused-reviewed-bands.json');old=read('.build/ownership-alternatives-2026-10-03/actual.json');prev=read('.build/brahms-envelope-compatibility-full-2026-10-03/candidate.json');new=read('.build/brahms-monotone-compatibility-full-2026-10-03/candidate.json');combo=read('.build/brahms-numbered-spans-v4-full-2026-10-03/candidate.json');rect=lambda b,p:[b['leftFraction']*p['pageWidth'],b['topFraction']*p['pageHeight'],(1-b['rightFraction'])*p['pageWidth'],b['bottomFraction']*p['pageHeight']]
checked=[]
for r in rows:
 n=r['page']-1;bid=r['bandID'];a=next(b for b in old['plan']['pages'][n]['assignments']if b['id']==bid);b=next(b for b in new['plan']['pages'][n]['assignments']if b['id']==bid);e=next(b for b in prev['plan']['pages'][n]['assignments']if b['id']==bid);c=next(b for b in combo['plan']['pages'][n]['assignments']if b['id']==bid);assert e==c;assert sha(r['leafReceipt'])==r['leafReceiptSHA256'];entry=r['leafEntry']
 if r['route'].startswith('exact e32'):
  assert rect(b,new['pages'][n])==rect(e,prev['pages'][n]);expectedBefore=rect(a,old['pages'][n]);expectedAfter=rect(e,prev['pages'][n])
 else:expectedBefore=rect(e,prev['pages'][n]);expectedAfter=rect(b,new['pages'][n])
 if 'before'in entry:assert entry['before']==expectedBefore
 if 'after'in entry:assert entry['after']==expectedAfter
 if 'oldY'in entry:assert entry['oldY']==[expectedBefore[1],expectedBefore[3]]
 if 'newY'in entry:assert entry['newY']==[expectedAfter[1],expectedAfter[3]]
 panel=entry.get('contextPath')or entry.get('annotatedPanel')or entry.get('context');panel=panel['path']if isinstance(panel,dict)else panel;h=entry.get('contextSHA256')or entry.get('annotatedSHA256');assert panel and h and sha(panel)==h
 checked.append({'bandID':bid,'page':n+1,'leafReceipt':r['leafReceipt'],'leafReceiptSHA256':r['leafReceiptSHA256'],'sourceContext':panel,'contextSHA256':h,'exactLeafBeforeAfterBoundsVerified':True})
(R/'review-leaf-coordinate-validation.json').write_text(json.dumps(checked,indent=2)+'\n');print(len(checked),'actual review leaves and context hashes verified')
