from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path('.build/brahms-raw-corrected-review-reuse-2026-10-03');D=Path('Tests/quality_control/brahms-raw-corrected-review-reuse-2026-10-03');D.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
for p,h in read(R/'input-bindings-before-results.json').items():assert sha(p)==h
s=read(R/'summary.json');assert s['reusedReviewedBands']==193 and s['remainingPendingBands']==60
(R/'executable-binding.json').write_text(json.dumps({'binarySHA256':sha(R/'render-only'),'harnessSHA256':sha(R/'render.swift'),'runnerSHA256':sha(R/'render-only.sh'),'calls':'NativeScorePageAnalyzer.render only'},indent=2)+'\n')
files={str(p.relative_to(R)):p for p in R.rglob('*')if p.is_file()and p.suffix in ['.json','.md','.py','.sh','.swift','.log']}
for p,h in read(R/'input-bindings-before-results.json').items():
 path=Path(p)
 if path.suffix=='.swift':files['compiled-Core/'+path.name]=path
for row in read(R/'source-review-leaf-bindings.json'):p=Path(row['path']);assert sha(p)==row['sha256'];files['review-chain/'+str(p)]=p
for p in ['.build/brahms-source-span-full-replay-2026-10-03/inputs.json','Tests/quality_control/envelope-compatibility-independent-2026-10-03/independent-source-area-reuse.json','Tests/quality_control/monotone-corrected39-independent-2026-10-03/independent-previous-area-comparison.json']:files['review-chain/'+p]=Path(p)
man={n:sha(p)for n,p in sorted(files.items())};(D/'archive-manifest.json').write_text(json.dumps(man,indent=2)+'\n')
with zipfile.ZipFile(D/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for n,p in files.items():z.write(p,n)
 z.write(D/'archive-manifest.json','archive-manifest.json')
with zipfile.ZipFile(D/'evidence.zip')as z:
 for n,h in man.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
for n in ['README.md','summary.json','protocol-before-results.json','input-bindings-before-results.json','decoded-pixel-comparison.json','reused-reviewed-bands.json','remaining-pending-bands.json','review-leaf-coordinate-validation.json']:shutil.copy2(R/n,D/n)
m={str(p.relative_to(D)):sha(p)for p in D.rglob('*')if p.is_file()and p.name!='manifest.json'};(D/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for n,h in m.items():assert sha(D/n)==h
print(json.dumps({'path':str(D),'README':sha(D/'README.md'),'manifest':sha(D/'manifest.json'),'artifacts':len(m),'archivePayloads':len(man)},indent=2))
