#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
p=.build/brahms-raw-corrected-review-reuse-2026-10-03
core=.build/numbered-line-monotone-compatibility-2026-10-03/candidate/Core/Detection
xcrun swiftc -O -module-cache-path .build/ModuleCache "$core/StaffBandDetector.swift" "$core/ScoreExtractionPlanner.swift" "$core/ScoreSharedEnding.swift" "$core/ScoreSharedEndingDetector.swift" "$core/ScoreLocalEndingPreservation.swift" "$core/NativeScorePageAnalyzer.swift" "$p/render.swift" -o "$p/render-only" > "$p/build.log" 2>&1
"$p/render-only" "$p/render-config.json" > "$p/render.log" 2>&1
