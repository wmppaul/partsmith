import AppKit
import Foundation
import PDFKit
import CryptoKit
@main enum ReexportProject {
 struct Envelope: Codable { var project: ProjectData }
 static func hash(_ data:Data)->String { SHA256.hash(data:data).map{String(format:"%02x",$0)}.joined() }
 static func top(_ r:CGRect,_ b:CGRect)->[Double] {[r.minX-b.minX,b.maxY-r.maxY,r.maxX-b.minX,b.maxY-r.minY]}
 static func main() throws {
  let input=URL(fileURLWithPath:CommandLine.arguments[1]);let output=URL(fileURLWithPath:CommandLine.arguments[2]);let manager=FileManager.default
  guard !manager.fileExists(atPath:output.path) else {fatalError("Refusing overwrite")}
  let decoder=JSONDecoder();decoder.dateDecodingStrategy = .iso8601
  let json=try Data(contentsOf:input.appendingPathComponent("project.json"));let decoded=try decoder.decode(Envelope.self,from:json)
  let encoder=JSONEncoder();encoder.dateEncodingStrategy = .iso8601;encoder.outputFormatting=[.prettyPrinted,.sortedKeys,.withoutEscapingSlashes]
  guard try encoder.encode(decoded)==json else{fatalError("Package did not roundtrip exactly")}
  let source=try Data(contentsOf:input.appendingPathComponent("source.pdf"));let document=PartsmithDocument(project:decoded.project,sourcePDFData:source)
  guard let pdf=document.pdfDocument else {fatalError("Source missing")}
  try manager.createDirectory(at:output,withIntermediateDirectories:true)
  var parts:[[String:Any]]=[]
  for part in decoded.project.parts {
   let plan=try PartLayoutEngine.makePlan(project:document.project,pageBoundsProvider:{pdf.page(at:$0)?.bounds(for:.mediaBox)},partID:part.id)
   let file=part.name+".pdf";try PartPDFExporter.export(partID:part.id,document:document,to:output.appendingPathComponent(file))
   let rows=plan.pages.flatMap{p in p.placements.map{b -> [String:Any] in
    let page=pdf.page(at:b.sourcePageIndex)!.bounds(for:.mediaBox);let bounds=CGRect(origin:.zero,size:plan.pageSize)
    return ["sourcePage":b.sourcePageIndex+1,"outputPage":p.index+1,"sourceRect":top(b.sourceRect,page),"destinationRect":top(b.destinationRect,bounds),"sourceMarkings":b.sourceMarkings.map{["sourceRect":top($0.sourceRect,page),"destinationRect":top($0.destinationRect,bounds)]}]
   }}
   parts.append(["name":part.name,"file":file,"pages":plan.pages.count,"placements":rows,"sha256":hash(try Data(contentsOf:output.appendingPathComponent(file)))])
   print("Reopened \(part.name): \(plan.pages.count) pages, \(rows.count) strips")
  }
  let record:[String:Any]=["sourceSHA256":hash(source),"projectSHA256":hash(json),"packageRoundtripExact":true,"explicitBreaks":decoded.project.bands.filter{$0.pageBreakBefore}.count,"parts":parts]
  try JSONSerialization.data(withJSONObject:record,options:[.prettyPrinted,.sortedKeys]).write(to:output.appendingPathComponent("reexport.json"))
 }
}
