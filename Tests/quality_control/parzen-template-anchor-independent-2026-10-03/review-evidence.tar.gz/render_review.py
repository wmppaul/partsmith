import json,hashlib,math
from pathlib import Path
import pymupdf
from PIL import Image,ImageDraw,ImageFont
W=Path('.build/parzen-template-probe-2026-10-03'); O=Path('.build/parzen-independent-review-2026-10-03'); O.mkdir(exist_ok=True)
read=lambda p:json.loads(Path(p).read_text())
case=read(W/'input.json')[0]; source=Path(case['sourcePath']); pdf=pymupdf.open(source)
v3=read(W/'candidate-v3/results.json')[0]; old=read(W/'baseline-results.json')[0]
gained=sorted({x['pageIndex'] for x in v3['suggestions']}-{x['pageIndex'] for x in old['suggestions']})
events=read(W/'candidate-v3/results.json.events.json'); old_events=read(W/'observer/results.json.events.json')
staff={(e['pageIndex'],e['id']):e for e in events if e['kind']=='staff'}; anchored={(e['pageIndex'],e['id']):e for e in events if e['kind']=='anchoredStaff'}
expected=read(W/'expected-before-result.json'); exp={(x['pageIndex'],x['systemIndex']):x for x in expected['unseededSystems']}
checks=[]
for s in v3['suggestions']:
 e=exp[(s['pageIndex'],s['systemIndex'])]; assert s['candidateIDs']==e['candidateIDs']; assert s['staffCounts']==e['staffCounts'];assert set(s['presentPartIDs'])==set(e['presentPartIDs']);checks.append(s['pageIndex']+1)
selected={(1,9),(7,9),(15,7)}
for e in old_events:
 if e['kind']=='comparison' and e['pageIndex'] in gained:
  for tid,oid,score in zip(e['templateIDs'],e['candidateIDs'],e['scores']):
   if score<.48: selected|={(e['pageIndex'],oid),(e['templatePageIndex'],tid)}
font=ImageFont.truetype('/System/Library/Fonts/Monaco.ttf',15)
# All14 gained pages: original left context, highlighting only staff numbers at source left.
page_panels=[]
for pi in gained:
 page=pdf[pi]; pix=page.get_pixmap(matrix=pymupdf.Matrix(2,2),clip=pymupdf.Rect(0,0,200,page.rect.height)); im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples); panel=Image.new('RGB',(440,im.height+35),'white');panel.paste(im,(40,35));draw=ImageDraw.Draw(panel);draw.text((4,4),f'Original PDF p{pi+1}',font=font,fill='black')
 for s in case['pages'][pi]['staves']:
  y=(s['staffLineFractions'][0]+s['staffLineFractions'][-1])/2*page.rect.height*2+35;draw.text((0,y-8),str(s['id']),font=font,fill='red')
 panel.save(O/f'source-p{pi+1:02d}.png');page_panels.append(panel)
for i in range(0,len(page_panels),3):
 sheet=Image.new('RGB',(440*min(3,len(page_panels)-i),max(x.height for x in page_panels[i:i+3])),'white')
 for j,p in enumerate(page_panels[i:i+3]):sheet.paste(p,(440*j,0))
 sheet.save(O/f'page-contact-{i//3+1:02d}.png')
# Independently derive exact sampled patch span and broader raw-source context.
rows=[];panels=[]
for pi,si in sorted(selected):
 s=staff[(pi,si)];a=anchored.get((pi,si));space=s['space'];x=a['patchStart'] if a else s['start'];phase=a['localPhase'] if a else 0;page=pdf[pi]
 sx=page.rect.width/s['imageWidth'];sy=page.rect.height/s['imageHeight']; slope=s['slope']
 points=[((x+xx*space)*sx,(s['lines'][0]+phase+yy*space+slope*(x+xx*space-s['imageWidth']/2))*sy) for xx,yy in[(.35,-2),(3.725,-2),(3.725,5.875),(.35,5.875)]]
 clip=pymupdf.Rect(max(0,min(q[0] for q in points)-space*sx*2),max(0,min(q[1] for q in points)-space*sy),min(page.rect.width,max(q[0] for q in points)+space*sx*2),min(page.rect.height,max(q[1] for q in points)+space*sy))
 pix=page.get_pixmap(matrix=pymupdf.Matrix(5,5),clip=clip); im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples); draw=ImageDraw.Draw(im); pts=[(int(q[0]*5-pix.x),int(q[1]*5-pix.y)) for q in points];draw.line(pts+[pts[0]],fill='red',width=2)
 # No resizing source panel; enough room for all practical patch sizes.
 panel=Image.new('RGB',(max(390,im.width),max(220,im.height+30)),'white');panel.paste(im,((panel.width-im.width)//2,30));ImageDraw.Draw(panel).text((3,5),f'p{pi+1} staffID {si} '+('anchored' if a else 'original'),font=font,fill='black');panel.save(O/f'patch-p{pi+1:02d}-s{si:02d}.png');panels.append(panel);rows.append({'physicalPage':pi+1,'staffID':si,'sourceClipPDFPoints':list(clip),'patchPolygonPDFPoints':points,'boundaryProven':bool(a),'phasePixels':phase,'sourceBand':a['sourceBand'] if a else None})
for i in range(0,len(panels),8):
 block=panels[i:i+8];cw=max(p.width for p in block);ch=max(p.height for p in block);sheet=Image.new('RGB',(cw*4,ch*math.ceil(len(block)/4)),'white')
 for j,p in enumerate(block):sheet.paste(p,(cw*(j%4),ch*(j//4)))
 sheet.save(O/f'patch-contact-{i//8+1:02d}.png')
(O/'review-index.json').write_text(json.dumps({'gainedPhysicalPages':[p+1 for p in gained],'allSuggestionIdentityChecks':checks,'sourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'patches':rows},indent=2)+'\n')
print('Gained pages:',len(gained),'patches:',len(rows),'page sheets',math.ceil(len(page_panels)/3),'patch sheets',math.ceil(len(panels)/8))
