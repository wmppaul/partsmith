from pathlib import Path
import json,hashlib,shutil,difflib
R=Path('.build/combined-span-v4-independent-2026-10-03');study=Path('.build/numbered-lines-source-spans-v4-2026-10-03');src=study/'candidate/Core';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(src/'Detection/NativeScorePageAnalyzer.swift')=='87e515434e671bc11f7c304342112401fcd0fc3d800015b8f93f7b29ab013487'
assert sha(study/'protocol-before-results.json')=='e2a31249983f182093c4eec093b36f942c1ab796fd6da3be7ed9bfa216ed767d'
for v,core in [('baseline',Path('.build/musical-span-independent-2026-10-03/baseline/Core')),('candidate',src)]:
 shutil.copytree(core,R/v/'Core',dirs_exist_ok=True);(R/v/'source-hashes.json').write_text(json.dumps({str(p.relative_to(core)):sha(p)for p in sorted(core.rglob('*'))if p.is_file()},indent=2)+'\n')
assert sha(R/'baseline/Core/Detection/NativeScorePageAnalyzer.swift')=='9f8d7ef80a27569ca3f5711388ad5876326a2931d60ecd77b2703d0aba235f01'
for f in['controls297.swift','expanded336.swift','protocol-before-results.json']:shutil.copyfile(study/f,R/f)
assert (R/'controls297.swift').read_bytes()==Path('.build/brahms-numbered-lines-2026-10-03/controls297.swift').read_bytes()
assert (R/'expanded336.swift').read_bytes()==Path('.build/brahms-numbered-lines-2026-10-03/expanded336.swift').read_bytes()
old=(R/'controls297.swift').read_text();s=old.replace('import Foundation\n','import Foundation\nimport CryptoKit\n',1)
s=s.replace('var preserved:Bool }','var preserved:Bool; var sourcePixels:Int; var sourcePixelIndices:[Int]; var sourceMaskSHA256:String; var lostPixelIndices:[Int] }',1)
s=s.replace('var bounds:[[Double]]; var componentCount:Int','var bounds:[[Double]]; var componentCount:Int; var sourceRawSHA256:String; var sourceOwnershipSHA256:String; var components:[ScoreInkComponent]',1)
s=s.replace('''    static func main() throws {''','''    static func digest(_ bytes:[UInt8])->String { SHA256.hash(data:Data(bytes)).map { String(format:"%02x",$0) }.joined() }
    static func main() throws {''',1)
s=s.replace('''                var x0=width,y0=height,x1=0,y1=0''','''                var x0=width,y0=height,x1=0,y1=0
                var sourcePixelIndices:[Int]=[]''',1)
s=s.replace('''                    x0=min(x0,x);y0=min(y0,y);x1=max(x1,x+1);y1=max(y1,y+1)''','''                    x0=min(x0,x);y0=min(y0,y);x1=max(x1,x+1);y1=max(y1,y+1)
                    precondition(transformed[y*width+x] == 0)
                    sourcePixelIndices.append(y*width+x)''',1)
needle='''                targets.append(.init(owner:owner,sourceEnvelope:envelope,crop:crop,preserved:retained))''';assert s.count(needle)==1
s=s.replace(needle,'''                let lostPixelIndices=sourcePixelIndices.filter { index in
                    guard crop.count == 4 else { return true }
                    let x=Double(index%width),y=Double(index/width)
                    return x<crop[0]-1e-9 || y<crop[1]-1e-9 || x+1>crop[2]+1e-9 || y+1>crop[3]+1e-9
                }
                precondition(retained == lostPixelIndices.isEmpty)
                let mask=ownership.map { value -> UInt8 in value & UInt8(1<<owner) != 0 ? 1 : 0 }
                targets.append(.init(owner:owner,sourceEnvelope:envelope,crop:crop,preserved:retained,
                    sourcePixels:sourcePixelIndices.count,sourcePixelIndices:sourcePixelIndices,
                    sourceMaskSHA256:digest(mask),lostPixelIndices:lostPixelIndices))''',1)
s=s.replace('''wholeNeighborCount:neighbors,planCanApply:plan.canApply,bounds:bounds,componentCount:ink.count))''','''wholeNeighborCount:neighbors,planCanApply:plan.canApply,bounds:bounds,componentCount:ink.count,
                sourceRawSHA256:digest(transformed),sourceOwnershipSHA256:digest(ownership),components:ink))''',1)
(R/'controls297-pixels.swift').write_text(s);(R/'observer297.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='unchanged/controls297.swift',tofile='loss-observer/controls297-pixels.swift')))
inputs={str(p):sha(p)for p in[study/'controls297.swift',study/'expanded336.swift',Path('.build/ownership-alternatives-2026-10-03/results297.json'),Path('.build/ownership-alternatives-2026-10-03/results336.json'),Path('.build/musical-span-independent-2026-10-03/input-manifest.json'),Path('.build/musical-span-attached-addendum-2026-10-03/input-manifest.json')]};(R/'input-bindings-before-results.json').write_text(json.dumps(inputs,indent=2)+'\n')
protocol={'scope':'Unchanged297 exact original source-owned pixel loss sets, unchanged336 source envelopes, and frozen29+6. No new fixture or source oracle.','nativeSHA256':sha(src/'Detection/NativeScorePageAnalyzer.swift'),'constructor297SHA256':sha(R/'controls297.swift'),'observer297SHA256':sha(R/'controls297-pixels.swift'),'constructor336SHA256':sha(R/'expanded336.swift'),'sourceConvention':'297 source constructor, transforms, raster scales, analyzer calls and planner are unmodified; observer records original full-resolution owned pixel indices/mask hashes and exact loss sets using same1e-9 unit-cell containment as original envelope predicate. Source indices/hashes must match baseline and candidate for every case.','baselineBinding':'Run the same297 observer against frozen production9f8d7ef; strip observer-only fields and require exact equality to original production results before interpreting candidate. Reuse original336 result only if immutable constructor matches.','gates':'No newly lost source-owned pixel, including in an existing failing case; fullcase176 allowners. Compare whole-neighbor counts separately.336must preserve all fixed source envelopes; no new missing high target.29+6 unchanged masks and raw source-span records.','execution':'Private standalone combined testing only. Stop and report concrete regression. No real39/fullcorpus/export/production changes by this evaluator.'};(R/'independent-protocol-before-results.json').write_text(json.dumps(protocol,indent=2)+'\n');print(json.dumps({'protocolSHA256':sha(R/'independent-protocol-before-results.json'),'observerSHA256':sha(R/'controls297-pixels.swift'),'inputsSHA256':sha(R/'input-bindings-before-results.json')},indent=2))
