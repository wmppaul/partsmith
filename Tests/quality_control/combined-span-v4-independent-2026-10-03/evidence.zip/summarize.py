from pathlib import Path
import json,hashlib
R=Path('.build/combined-span-v4-independent-2026-10-03')
r=json.loads((R/'comparison297.json').read_text());h=[x for x in r['cases']if x['kind']=='headAtJunction']
byKind=[]
for k in dict.fromkeys(x['kind']for x in r['cases']):
 a=[x for x in r['cases']if x['kind']==k];byKind.append({'kind':k,'cases':len(a),'baselineCompleteCases':sum(x['baselineAllTargetsPreserved']for x in a),'candidateCompleteCases':sum(x['candidateAllTargetsPreserved']for x in a),'baselineWholeNeighborRelations':sum(x['baselineWholeNeighbors']for x in a),'candidateWholeNeighborRelations':sum(x['candidateWholeNeighbors']for x in a),'increasedCases':sum(x['wholeNeighborChange']>0 for x in a),'decreasedCases':sum(x['wholeNeighborChange']<0 for x in a)})
small=[]
for name,root in [('original29','musical-span-independent-2026-10-03'),('addendum6','musical-span-attached-addendum-2026-10-03')]:
 a=json.loads((R/name/'span-witnesses.json').read_text());b=json.loads((Path('.build')/root/'candidate-v4/span-witnesses.json').read_text());assert a==b
 c=json.loads((R/name/'full-comparison-to-candidate-v4.json').read_text())
 small.append({'suite':name,'rawSpanWitnessesEqualStandaloneV4':True,'completeOwners':c['candidateCompleteOwners'],'totalOwners':c['ownerObservations'],'newlyLostPixelsVersusStandaloneV4':c['newlyLostPixels'],'recoveredPixelsVersusStandaloneV4':c['recoveredPixels'],'remainingLostPixels':sum(x['candidateLost']for x in c['owners']),'negativeObservationsWithSpans':c['negativeObservationsWithSpans'],'sourceScaleCases':c['sourceScaleCases'],'negativeSourceScaleCases':c['negativeSourceScaleObservations']})
out={'preservationVerdict':'All original297 masks fully retained, all336 source envelopes retained; unchanged29+6 lose no baseline or V4 owned pixels. Known29+6 misses remain.','cleanlinessVerdict':'Existing independent headAtJunction oracle fails separation in all27 variants; 84 new whole-neighbor relations. This is an ownership false positive under the unchanged oracle, while recovering 24 source pixels in three previously incomplete variants; the other 24 variants already preserved all owned pixels.','promotionVerdict':'Preservation gates pass, but this reviewer cannot certify no crop-quality regression. Parent owns actual-score evidence and release decision. No production/output changes or new variant were made.','junctionCases':27,'junctionAddedWholeNeighborRelations':sum(x['wholeNeighborChange']for x in h),'cases297ByKind':byKind,'smallSuites':small,'scope':'297 baseline and combined each run once; combined336 once; combined29+6 each once with logging-only observer. Earlier original336 baseline reused only after exact constructor hash verification. No standalone V4 297 attribution run or full score run by this reviewer.'}
(R/'verdict.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
