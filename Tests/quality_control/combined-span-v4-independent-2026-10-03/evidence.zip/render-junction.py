from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image,ImageDraw
R=Path('.build/combined-span-v4-independent-2026-10-03');b=json.loads((R/'baseline/controls297-pixels-run/results.json').read_text())[202];c=json.loads((R/'candidate/controls297-pixels-run/results.json').read_text())[202]
a=np.full((760,720),255,np.uint8)
def rect(x0,y0,x1,y1):a[y0:y1,x0:x1]=0
for t in [180,330,480]:
 for k in range(5):rect(40,t+12*k,603,t+12*k+1)
rect(40,180,43,529);rect(600,180,603,529)
for t in b['targets']:
 for i in t['sourcePixelIndices']:a[i//720,i%720]=0
assert hashlib.sha256(a.tobytes()).hexdigest()==b['sourceRawSHA256']
im=Image.fromarray(a);im.save(R/'case202-original-source.png')
canvas=Image.new('RGB',(1450,2440),'#ddd');d=ImageDraw.Draw(canvas)
for j,(version,r)in enumerate([('Production baseline',b),('Combined candidate',c)]):
 for i,t in enumerate(r['targets']):
  x=j*725;y=i*810;d.text((x+6,y+8),f'{version}: target {i+1}; crop {t["crop"][1]:.1f} to {t["crop"][3]:.1f}',fill='black')
  panel=im.convert('RGB');pd=ImageDraw.Draw(panel);box=t['crop'];pd.rectangle((box[0],box[1],box[2]-1,box[3]),outline=(0,130,230),width=2)
  for k in t['sourcePixelIndices']:panel.putpixel((k%720,k//720),(170,0,40))
  canvas.paste(panel,(x,y+30))
canvas.save(R/'case202-crop-comparison.png')
head=[x for x in json.loads((R/'comparison297.json').read_text())['cases']if x['kind']=='headAtJunction']
print('Junction false ownership:',len(head),'cases;',sum(x['wholeNeighborChange']for x in head),'added whole-neighbor relations;',sum(x['wholeNeighborChange']>0 for x in head),'worse cases')
print('Source raw verified',b['sourceRawSHA256'])
