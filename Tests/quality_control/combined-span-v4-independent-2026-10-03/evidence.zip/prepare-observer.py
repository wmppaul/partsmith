from pathlib import Path
import shutil,json,hashlib,difflib
r=Path('.build/combined-span-v4-independent-2026-10-03');src=r/'candidate/Core';out=r/'candidate-observer';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(src/'Detection/NativeScorePageAnalyzer.swift')=='87e515434e671bc11f7c304342112401fcd0fc3d800015b8f93f7b29ab013487'
for inputs in [Path('.build/musical-span-independent-2026-10-03'),Path('.build/musical-span-attached-addendum-2026-10-03')]:
 for p,h in json.loads((inputs/'input-manifest.json').read_text()).items():assert sha(inputs/p)==h
shutil.copytree(src,out/'Core',dirs_exist_ok=True)
p=out/'Core/Detection/NativeScorePageAnalyzer.swift';old=p.read_text();needle='            for span in sourceSpans {';assert old.count(needle)==1
insert='''            if let data = try? JSONEncoder().encode(sourceSpans) {
                FileHandle.standardError.write(Data("SOURCE_SPANS ".utf8))
                FileHandle.standardError.write(data)
                FileHandle.standardError.write(Data("\\n".utf8))
            }
''';new=old.replace(needle,insert+needle);p.write_text(new)
(out/'logging-only.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='frozen/NativeScorePageAnalyzer.swift',tofile='observer/NativeScorePageAnalyzer.swift')))
shutil.copyfile('.build/musical-span-independent-2026-10-03/candidate-v1-witnesses/evaluate.swift',out/'evaluate.swift')
shutil.copyfile('.build/musical-span-independent-2026-10-03/run.sh',out/'run.sh')
(out/'observer-source-hashes.json').write_text(json.dumps({str(p.relative_to(out/'Core')):sha(p)for p in sorted((out/'Core').rglob('*'))if p.is_file()},indent=2)+'\n')
(out/'run-bindings.json').write_text(json.dumps({'frozenNativeSHA256':sha(src/'Detection/NativeScorePageAnalyzer.swift'),'observerNativeSHA256':sha(p),'original29InputManifestSHA256':sha(Path('.build/musical-span-independent-2026-10-03/input-manifest.json')),'addendumInputManifestSHA256':sha(Path('.build/musical-span-attached-addendum-2026-10-03/input-manifest.json')),'execution':'One instrumented native execution per unchanged suite; only returned source spans and case IDs are logged. No uninstrumented duplicate run.'},indent=2)+'\n')
