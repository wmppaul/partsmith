from pathlib import Path
import hashlib,json,shutil,zipfile
R=Path('.build/combined-span-v4-independent-2026-10-03');D=Path('Tests/quality_control/combined-span-v4-independent-2026-10-03');D.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Assert still-bound source snapshots and original inputs before archiving.
for name in ['baseline','candidate']:
 for rel,h in json.loads((R/name/'source-hashes.json').read_text()).items():assert sha(R/name/'Core'/rel)==h,(name,rel)
for rel,h in json.loads((R/'input-bindings-before-results.json').read_text()).items():assert sha(Path(rel))==h,rel
for name in ['musical-span-independent-2026-10-03','musical-span-attached-addendum-2026-10-03']:
 root=Path('.build')/name
 for rel,h in json.loads((root/'input-manifest.json').read_text()).items():assert sha(root/rel)==h
files={}
def add(p,name=None):files[name or str(p.relative_to(R))]=p
for name in ['baseline','candidate','candidate-observer']:
 for p in sorted((R/name/'Core').rglob('*')):
  if p.is_file():add(p)
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R)
 if any(t in ['Core','module-cache']for t in rel.parts):continue
 if p.suffix in ['.json','.swift','.py','.sh','.patch','.log','.png','.md']:add(p)
for name in ['results297.json','results336.json']:add(Path('.build/ownership-alternatives-2026-10-03')/name,'reused-baseline/'+name)
for name,study in [('original29','musical-span-independent-2026-10-03'),('addendum6','musical-span-attached-addendum-2026-10-03')]:
 root=Path('.build')/study
 for v in ['baseline','candidate-v4']:
  add(root/v/'results.json',f'reused-small/{name}/{v}/results.json')
  if v=='candidate-v4':add(root/v/'span-witnesses.json',f'reused-small/{name}/{v}/span-witnesses.json')
 for n in ['input-manifest.json','protocol-before-results.json']:
  if(root/n).is_file():add(root/n,f'reused-small/{name}/{n}')
binaries={str(p.relative_to(R)):sha(p)for p in [R/'baseline/controls297-pixels-run/runner',R/'candidate/controls297-pixels-run/runner',R/'candidate/expanded336-run/runner',R/'original29/evaluate']}
(R/'executable-hashes.json').write_text(json.dumps(binaries,indent=2)+'\n');add(R/'executable-hashes.json')
archiveManifest={n:sha(p)for n,p in sorted(files.items())};(D/'archive-manifest.json').write_text(json.dumps(archiveManifest,indent=2)+'\n')
with zipfile.ZipFile(D/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,p in sorted(files.items()):z.write(p,n)
 z.write(D/'archive-manifest.json','archive-manifest.json')
for name in ['README.md','verdict.json','summary297.json','baseline297-reproduction.json','independent-protocol-before-results.json','input-bindings-before-results.json','case202-original-source.png','case202-crop-comparison.png']:
 shutil.copyfile(R/name,D/name)
for name in ['original29','addendum6']:
 (D/name).mkdir(exist_ok=True)
 for f in ['summary.json','span-witnesses.json']:shutil.copyfile(R/name/f,D/name/f)
with zipfile.ZipFile(D/'evidence.zip')as z:
 assert set(z.namelist())==set(archiveManifest)|{'archive-manifest.json'}
 for n,h in archiveManifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
manifest={str(p.relative_to(D)):sha(p)for p in sorted(D.rglob('*'))if p.is_file()and p.name!='manifest.json'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n,h in manifest.items():assert sha(D/n)==h
print(json.dumps({'report':str(D),'README_SHA256':sha(D/'README.md'),'manifest_SHA256':sha(D/'manifest.json'),'artifacts':len(manifest),'archivePayloads':len(archiveManifest),'archiveBytes':(D/'evidence.zip').stat().st_size},indent=2))
