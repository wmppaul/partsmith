from pathlib import Path
import hashlib,json,shutil,zipfile

p=Path('.build/numbered-line-envelope-compatibility-2026-10-03')
r=Path('Tests/quality_control/numbered-line-envelope-compatibility-2026-10-03')
ind=Path('Tests/quality_control/numbered-envelope-independent-2026-10-03')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert sha(p/'candidate/Core/Detection/NativeScorePageAnalyzer.swift')=='e32b5a76928b505efbeba6fa5bc9aef4b58ed0e2b7d11ddeef3269b73570996f'
assert sha(p/'existing795.swift')==sha(Path('tools/test_crop_quality.swift'))
assert sha(Path('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'))=='9f8d7ef80a27569ca3f5711388ad5876326a2931d60ecd77b2703d0aba235f01'
assert (ind/'manifest.json').exists(), 'Independent manifest must be frozen first'
r.mkdir(exist_ok=True)
for name,f in {
 'protocol-before-results.json':p/'protocol-before-results.json',
 'source-bindings-before-results.json':p/'source-bindings-before-results.json',
 'fourcore-exact-pixel-comparison.json':p/'candidate/fourcore-exact-pixel-comparison.json',
 'permanent796.log':p/'candidate/existing795.log',
 'case176-comparison.json':p/'candidate/case176-comparison.json',
 'case176-correspondence.json':p/'case176-correspondence.json',
}.items():shutil.copy2(f,r/name)
bindings=[ind/'manifest.json',Path('Tests/quality_control/numbered-lines-source-spans-v4-2026-10-03/manifest.json'),Path('Tests/quality_control/brahms-numbered-lines-2026-10-03/manifest.json'),Path('Tests/quality_control/brahms-case176-ownership-2026-10-03/manifest.json'),Path('Tests/quality_control/four-core-independent-2026-10-03/controls.swift'),Path('tools/test_crop_quality.swift'),Path('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'),p/'candidate/Core/Detection/NativeScorePageAnalyzer.swift']
(r/'bindings.json').write_text(json.dumps({str(f):sha(f) for f in bindings},indent=2,sort_keys=True)+'\n')
files={}
for name in ['prepare.py','build-run.sh','protocol-before-results.json','source-bindings-before-results.json','compare-fourcore-exact.py','freeze-report.py','case176.swift','fourcore.swift','existing795.swift','controls297.swift','expanded336.swift','case176-correspondence.json']:
 files[name]=p/name
for name in ['StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift','NativeScorePageAnalyzer.swift']:
 files['candidate/Core/Detection/'+name]=p/'candidate/Core/Detection'/name
for f in (p/'candidate').glob('*'):
 if f.is_file() and f.suffix in ['.json','.log','.pgm','.diff']:files['candidate/'+f.name]=f
for f in (p/'candidate/fourcore-sources').glob('*.png'):files['candidate/fourcore-sources/'+f.name]=f
files['baseline/fourcore.json']=Path('.build/brahms-numbered-lines-2026-10-03/baseline/fourcore.json')
archive=r/'implementation-and-controls.zip';members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,f in sorted(files.items()):
  z.write(f,name);members[name]={'sha256':sha(f),'bytes':f.stat().st_size}
with zipfile.ZipFile(archive) as z:
 for name,v in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==v['sha256']
(r/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),'members':members,'omitted':'Rebuildable executables/module caches and independent suites already hash-bound in their own verified archive. Real39 review is parent-owned and outside this limited control receipt.'},indent=2,sort_keys=True)+'\n')
manifest={str(f.relative_to(r)):{'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(r.rglob('*')) if f.is_file() and f.name!='manifest.json'}
(r/'manifest.json').write_text(json.dumps({'scope':'Private limited control result; no production change or real-score promotion claim.','files':manifest},indent=2,sort_keys=True)+'\n')
for name,v in manifest.items():assert sha(r/name)==v['sha256']
print('members',len(members),'bytes',archive.stat().st_size,'manifest',sha(r/'manifest.json'))
