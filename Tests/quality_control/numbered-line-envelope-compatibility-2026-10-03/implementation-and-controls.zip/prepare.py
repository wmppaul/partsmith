from pathlib import Path
import hashlib,json,shutil,difflib
p=Path('.build/numbered-line-envelope-compatibility-2026-10-03')
old=Path('.build/brahms-numbered-lines-2026-10-03/candidate-v2/Core')
core=p/'candidate/Core'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert sha(old/'Detection/NativeScorePageAnalyzer.swift')=='b5f86b6597f35d6507c1ffc5cd97efb5d8c5bacef9226e59b2e5616f9babbf09'
shutil.copytree(old,core)
f=core/'Detection/NativeScorePageAnalyzer.swift';base=f.read_text()
block='''        // Preserve established single-owner crop support only when actual
        // retained source pixels still have the same sole owner. The legacy
        // feature mask already carries the identical structural cuts; it does
        // not rerun rasterization, connector proofs, or musical recognition.
        var legacyRuns: [Run] = [], legacyParents: [Int] = []
        func legacyRoot(_ value: Int) -> Int {
            var index = value
            while legacyParents[index] != index {
                legacyParents[index] = legacyParents[legacyParents[index]]
                index = legacyParents[index]
            }
            return index
        }
        var legacyPrevious: [Int] = []
        for y in 0..<height {
            if y % 128 == 0 && isCancelled() { return nil }
            var current: [Int] = [], x = 0, previousOffset = 0
            while x < width {
                if !musicalFeatureInk[y * width + x] { x += 1; continue }
                let left = x
                while x < width && musicalFeatureInk[y * width + x] { x += 1 }
                let index = legacyRuns.count
                legacyRuns.append(Run(left: left, right: x, y: y))
                legacyParents.append(index); current.append(index)
                while previousOffset < legacyPrevious.count && legacyRuns[legacyPrevious[previousOffset]].right < left { previousOffset += 1 }
                var offset = previousOffset
                while offset < legacyPrevious.count && legacyRuns[legacyPrevious[offset]].left <= x {
                    let other = legacyRoot(legacyPrevious[offset]), own = legacyRoot(index)
                    if other != own { legacyParents[other] = own }
                    offset += 1
                }
            }
            legacyPrevious = current
        }
        var legacyBoxes: [Int: Bounds] = [:]
        var children: [Int: Set<Int>] = [:]
        var currentOffset = 0
        for (index, run) in legacyRuns.enumerated() {
            if index % 4096 == 0 && isCancelled() { return nil }
            let key = legacyRoot(index)
            if var box = legacyBoxes[key] {
                box.left = min(box.left, run.left); box.right = max(box.right, run.right)
                box.top = min(box.top, run.y); box.bottom = max(box.bottom, run.y + 1)
                box.area += run.right - run.left
                legacyBoxes[key] = box
            } else {
                legacyBoxes[key] = Bounds(left: run.left, top: run.y, right: run.right, bottom: run.y + 1, area: run.right - run.left)
            }
            // Same-row strict interval overlap is an actual retained pixel;
            // touching boxes or adjacent pixels cannot establish correspondence.
            while currentOffset < runs.count && (runs[currentOffset].y < run.y || (runs[currentOffset].y == run.y && runs[currentOffset].right <= run.left)) { currentOffset += 1 }
            var offset = currentOffset
            while offset < runs.count && runs[offset].y == run.y && runs[offset].left < run.right {
                if runs[offset].right > run.left { children[key, default: []].insert(root(offset)) }
                offset += 1
            }
        }
        func ownersOf(_ box: Bounds) -> [Int] {
            lines.indices.filter { Double(box.top) <= lines[$0][4] && Double(box.bottom) >= lines[$0][0] }
        }
        let currentOwners = boxes.mapValues { ownersOf($0) }
        var legacyEnvelopeSupports: [ScoreInkComponent] = []
        for key in legacyBoxes.keys.sorted() {
            if isCancelled() { return nil }
            let box = legacyBoxes[key]!
            let owners = ownersOf(box)
            guard box.area >= 2, owners.count == 1, let linked = children[key], !linked.isEmpty else { continue }
            guard linked.allSatisfy({ currentOwners[$0]?.isEmpty == true || currentOwners[$0] == owners }) else { continue }
            let ownedChildren = linked.filter { currentOwners[$0] == owners }.compactMap { boxes[$0] }
            guard !ownedChildren.isEmpty else { continue }
            let retainedTop = ownedChildren.map(\\.top).min()!
            let retainedBottom = ownedChildren.map(\\.bottom).max()!
            guard box.top < retainedTop || box.bottom > retainedBottom else { continue }
            var support = ScoreInkComponent(bounds: [Double(box.left) / Double(width), Double(box.top) / Double(height),
                Double(box.right) / Double(width), Double(box.bottom) / Double(height)], staffIDs: owners.map { ordered[$0].id })
            support.isOwnershipAlternative = true
            legacyEnvelopeSupports.append(support)
        }
'''
needle='        let typicalSpace = spaces.sorted()[spaces.count / 2]\n';assert base.count(needle)==1
s=base.replace(needle,block+needle,1)
needle2='        if retainMusicalEvidence && preservedMusicalConnection {\n';assert s.count(needle2)==1
s=s.replace(needle2,'        result.append(contentsOf: legacyEnvelopeSupports)\n'+needle2,1)
assert 'SourceSpan' not in s and 'sourceMusicalSpans' not in s
f.write_text(s)
(p/'candidate/versus-numbered-v2.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='numbered-v2/NativeScorePageAnalyzer.swift',tofile='compatibility-v1/NativeScorePageAnalyzer.swift')))
previous=Path('.build/numbered-lines-source-spans-v4-2026-10-03')
for name in ['existing795.swift','fourcore.swift','case176.swift','controls297.swift','expanded336.swift']:
 shutil.copy2(previous/name,p/name)
(p/'build-run.sh').write_text((previous/'build-run.sh').read_text().replace('p=.build/numbered-lines-source-spans-v4-2026-10-03','p=.build/numbered-line-envelope-compatibility-2026-10-03'))
(p/'compare-fourcore-exact.py').write_text((previous/'compare-fourcore-exact.py').read_text().replace('.build/numbered-lines-source-spans-v4-2026-10-03','.build/numbered-line-envelope-compatibility-2026-10-03'))
(p/'source-bindings-before-results.json').write_text(json.dumps({
 'candidateNative':sha(f),'numberedV2Native':sha(old/'Detection/NativeScorePageAnalyzer.swift'),
 'protocol':sha(p/'protocol-before-results.json'),
 'sixCompiledDependencies':{name:sha(core/'Detection'/name) for name in ['NativeScorePageAnalyzer.swift','StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift']},
 'unchangedHarnesses':{name:sha(p/name) for name in ['existing795.swift','fourcore.swift','case176.swift','controls297.swift','expanded336.swift']},
},indent=2,sort_keys=True)+'\n')
print('Frozen candidate',sha(f),'protocol',sha(p/'protocol-before-results.json'))
