from pathlib import Path
import json,hashlib,shutil,difflib
p=Path('.build/source-musical-spans-2026-10-03');r=Path('.build/numbered-lines-source-spans-v4-2026-10-03');r.mkdir(exist_ok=True)
sha=lambda s:hashlib.sha256(s).hexdigest()
numbered=Path('.build/brahms-numbered-lines-2026-10-03/candidate-v2/Core/Detection/NativeScorePageAnalyzer.swift').read_text();span=(p/'candidate-v4/Core/Detection/NativeScorePageAnalyzer.swift').read_text();base=(p/'baseline/Core/Detection/NativeScorePageAnalyzer.swift').read_text()
assert sha(numbered.encode())=='b5f86b6597f35d6507c1ffc5cd97efb5d8c5bacef9226e59b2e5616f9babbf09'
assert sha(span.encode())=='ab60944ddeb2bd428329d71877039001f71ca5cae7d24b84ef344310f1f1607d'
helper=span[span.index('    struct SourceSpanSeed'):span.index('    static func analyze(')]
seedvar='        var sourceSpanSeeds: [SourceSpanSeed] = []\n'
seedblock='''                    if retainMusicalEvidence {
                        for stroke in physicalStrokes {
                            sourceSpanSeeds.append(SourceSpanSeed(left: stroke.left, right: stroke.right,
                                y: (start + end) / 2, space: space))
                        }
                    }
'''
start=span.index('        if retainMusicalEvidence {\n            let sourceSpans = sourceMusicalSpans(');end=span.index('        result.sort {',start);emit=span[start:end]
def add(s):
 assert s.count('    static func analyze(')==1
 s=s.replace('    static func analyze(',helper+'    static func analyze(',1)
 assert s.count('        var preservedMusicalConnection = false')==1
 s=s.replace('        var preservedMusicalConnection = false',seedvar+'        var preservedMusicalConnection = false',1)
 assert s.count('                    let mergedPair = physicalStrokes.count == 2')==1
 s=s.replace('                    let mergedPair = physicalStrokes.count == 2',seedblock+'                    let mergedPair = physicalStrokes.count == 2',1)
 assert s.count('        result.sort {')==1
 s=s.replace('        result.sort {',emit+'        result.sort {',1)
 return s
assert add(base)==span
combined=add(numbered)
# Removing exactly the four source-span additions must recover the numbered V2 file byte-for-byte.
back=combined.replace(helper,'',1).replace(seedvar,'',1).replace(seedblock,'',1).replace(emit,'',1);assert back==numbered
core=r/'candidate/Core';shutil.copytree(p/'candidate-v4/Core',core);(core/'Detection/NativeScorePageAnalyzer.swift').write_text(combined)
for h in ['case176','fourcore']:
 shutil.copy2(p/(h+'.swift'),r/(h+'.swift'))
for h in ['existing795','controls297','expanded336']:shutil.copy2(Path('.build/brahms-numbered-lines-2026-10-03')/(h+'.swift'),r/(h+'.swift'))
script=(p/'build-run.sh').read_text().replace('p=.build/source-musical-spans-2026-10-03','p=.build/numbered-lines-source-spans-v4-2026-10-03');(r/'build-run.sh').write_text(script)
(r/'combined-versus-numbered-v2.diff').write_text(''.join(difflib.unified_diff(numbered.splitlines(True),combined.splitlines(True),fromfile='numbered-v2/NativeScorePageAnalyzer.swift',tofile='combined/NativeScorePageAnalyzer.swift')))
(r/'combined-versus-production.diff').write_text(''.join(difflib.unified_diff(base.splitlines(True),combined.splitlines(True),fromfile='production/NativeScorePageAnalyzer.swift',tofile='combined/NativeScorePageAnalyzer.swift')))
record={'numberedV2':sha(numbered.encode()),'sourceSpanV4':sha(span.encode()),'production':sha(base.encode()),'combined':sha(combined.encode()),'addingSpanToBaselineReproducesExactV4':True,'removingOnlySourceSpanAdditionsReproducesExactNumberedV2':True,'sourceSpanHelperExact':True,'compiledDependencyHashes':{str(f.relative_to(core)):sha(f.read_bytes()) for f in sorted(core.rglob('*.swift'))}}
(r/'source-bindings-before-results.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['combined'])
