from pathlib import Path
import hashlib, json
import numpy as np
from PIL import Image, ImageDraw

root = Path('.build/numbered-lines-source-spans-v4-2026-10-03')
ind = Path('.build/combined-span-v4-independent-2026-10-03')
out = root / 'ownership-diagnosis'
out.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline = json.loads((ind / 'baseline/controls297-pixels-run/results.json').read_text())
candidate = json.loads((ind / 'candidate/controls297-pixels-run/results.json').read_text())
records = []

for case in [176, 202]:
    old, new = baseline[case], candidate[case]
    assert old['scale'] == 1 and old['tilt'] == 0
    source = np.full((760, 720), 255, np.uint8)
    # Original constructor's structural ink only, transformed by its explicit
    # source-column transform. All musical pixels come from unchanged source
    # masks, never from candidate geometry or inferred ownership.
    structural = np.full_like(source, 255)
    for top in [180, 330, 480]:
        for line in range(5):
            structural[top + line * 12, 40:603] = 0
    structural[180:529, 40:43] = 0
    if old['kind'] == 'headAtJunction':
        structural[180:529, 600:603] = 0
    for x in range(720):
        value = old['bow'] * min(1, max(0, (x - 360) / 240))
        # Swift .rounded(): nearest, ties away from zero. Cases here nonnegative.
        shift = int(np.floor(value + .5))
        source[shift:, x] = structural[:760-shift, x]
    for target in old['targets']:
        for pixel in target['sourcePixelIndices']:
            source[pixel // 720, pixel % 720] = 0
    assert hashlib.sha256(source.tobytes()).hexdigest() == old['sourceRawSHA256']
    image = Image.fromarray(source)
    image.save(out / f'case{case}-original-source.png')
    # Independent ownership shown separately per source mask; intersecting
    # structural and musical pixels are not deleted or recolored in originals.
    contact = Image.new('RGB', (720 * 3, 800), '#eeeeee')
    draw = ImageDraw.Draw(contact)
    for index, target in enumerate(old['targets']):
        panel = image.convert('RGB')
        for pixel in target['sourcePixelIndices']:
            panel.putpixel((pixel % 720, pixel // 720), (170, 0, 40))
        contact.paste(panel, (index * 720, 40))
        draw.text((index * 720 + 12, 10), f'Case {case}; original owner {index}; colored source pixels only', fill='black')
    contact.save(out / f'case{case}-source-owners.png')
    records.append({
        'caseIndex': case, 'kind': old['kind'], 'scale': old['scale'],
        'tilt': old['tilt'], 'bow': old['bow'],
        'sourceRawSHA256': old['sourceRawSHA256'],
        'sourceOwnershipSHA256': old['sourceOwnershipSHA256'],
        'sourcePNG': f'case{case}-original-source.png',
        'sourcePNGSHA256': sha(out / f'case{case}-original-source.png'),
        'expectsSeparation': old['expectsSeparation'],
        'baselineWholeNeighbors': old['wholeNeighborCount'],
        'candidateWholeNeighbors': new['wholeNeighborCount'],
        'candidateAlternatives': [c for c in new['components'] if c.get('isOwnershipAlternative')],
        'owners': [{
            'owner': a['owner'], 'sourceEnvelope': a['sourceEnvelope'],
            'sourceMaskSHA256': a['sourceMaskSHA256'],
            'sourcePixelCount': a['sourcePixels'],
            'baselineCrop': a['crop'], 'candidateCrop': b['crop'],
            'baselineLostPixels': len(a['lostPixelIndices']),
            'candidateLostPixels': len(b['lostPixelIndices']),
        } for a, b in zip(old['targets'], new['targets'])],
    })

comparison = json.loads((ind / 'comparison297.json').read_text())
junctions = [c for c in comparison['cases'] if c['kind'] == 'headAtJunction']
record = {
    'scope': 'Read-only diagnosis. No native rerun, new candidate, threshold edit, or oracle change.',
    'cases': records,
    'allJunctionCases': len(junctions),
    'junctionCasesWithIncreasedNeighbors': sum(c['wholeNeighborChange'] > 0 for c in junctions),
    'junctionAddedWholeNeighborRelations': sum(c['wholeNeighborChange'] for c in junctions),
    'junctionOwnerContract': 'Each of three heads and its short local stem belongs only to its own staff; the long right barline is structural. Exact original constructor and masks predate this candidate.',
    'case176OwnerContract': 'The interrupted long head-to-head musical shaft and both heads belong to all three owners under the unchanged source constructor. Source-mask intersection, not visible connectivity alone, defines this test.',
    'sourceGeometry202': {
        'structuralSpine': [600, 180, 603, 529],
        'localMusicalStems': [[600, t-22, 603, t+26] for t in [180,330,480]],
        'headCenters': [[596, t+24] for t in [180,330,480]],
        'headSourceRadii': [8,4],
    },
    'codeCause': {
        'bodyMembership': 'Actual direct body attachment and filledness are correct here: these are genuine noteheads.',
        'spanFormation': 'Every accepted body on one physical corridor is joined into a single first-to-last span without a separate common musical-owner test.',
        'ownerAssignment': 'Every five-line staff core intersected by that span and occupied source shaft is assigned ownership of the complete span.',
        'plannerEffect': 'Expansion-only alternative therefore grows all three owners to include other independently owned local heads and staffs.',
    },
    'inference': 'Filledness and original-pixel connectivity prove a body is attached, but cannot distinguish a shared musical shaft from independent local stems superimposed on a structural barline. This failure is semantic ownership, not false body recognition. Structural and musical labels may overlap on identical raster pixels.',
    'nextEvidenceNeeded': 'Separate a proven structural backbone from local note-stem/beam ownership hypotheses. Common ownership requires notation evidence beyond sharing that backbone; body presence or absence, gap size, position, head count, or a universal continuing-barline veto alone cannot resolve the mixed four-core positives. When source notation supplies no discriminating evidence, retain an explicit ambiguity/review path rather than certify every contacted staff as one shared owner.',
    'bindings': {str(p): sha(p) for p in [
        ind/'controls297.swift', ind/'controls297-pixels.swift',
        ind/'baseline/controls297-pixels-run/results.json',
        ind/'candidate/controls297-pixels-run/results.json',
        root/'candidate/Core/Detection/NativeScorePageAnalyzer.swift',
    ]},
}
(out/'diagnosis.json').write_text(json.dumps(record, indent=2, sort_keys=True)+'\n')
print(json.dumps({k: record[k] for k in ['allJunctionCases','junctionCasesWithIncreasedNeighbors','junctionAddedWholeNeighborRelations']}, indent=2))
