from pathlib import Path
import hashlib, json, shutil, zipfile

p=Path('.build/numbered-lines-source-spans-v4-2026-10-03')
r=Path('Tests/quality_control/numbered-lines-source-spans-v4-2026-10-03')
r.mkdir(exist_ok=True)
ind=Path('Tests/quality_control/combined-span-v4-independent-2026-10-03')
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert sha(p/'candidate/Core/Detection/NativeScorePageAnalyzer.swift')=='87e515434e671bc11f7c304342112401fcd0fc3d800015b8f93f7b29ab013487'
assert sha(ind/'manifest.json')=='2bdd457496a1e8db64811987914c35919ee432b665ddc65824e3d15b891d66ba'
assert sha(Path('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'))=='9f8d7ef80a27569ca3f5711388ad5876326a2931d60ecd77b2703d0aba235f01'
assert sha(p/'existing795.swift')==sha(Path('tools/test_crop_quality.swift'))

copies={
 'protocol-before-results.json':p/'protocol-before-results.json',
 'source-bindings-before-results.json':p/'source-bindings-before-results.json',
 'fourcore-exact-pixel-comparison.json':p/'candidate/fourcore-exact-pixel-comparison.json',
 'permanent796.log':p/'candidate/existing795.log',
 'case176.json':p/'candidate/case176.json',
 'ownership-diagnosis.json':p/'ownership-diagnosis/diagnosis.json',
}
for name,f in copies.items():shutil.copy2(f,r/name)
for f in (p/'ownership-diagnosis').glob('*.png'):shutil.copy2(f,r/f.name)

bindings=[
 ind/'manifest.json',
 Path('Tests/quality_control/source-musical-spans-v4-2026-10-03/manifest.json'),
 Path('Tests/quality_control/brahms-numbered-lines-2026-10-03/manifest.json'),
 Path('Tests/quality_control/four-core-independent-2026-10-03/controls.swift'),
 Path('tools/test_crop_quality.swift'),
 Path('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'),
 p/'candidate/Core/Detection/NativeScorePageAnalyzer.swift',
 Path('.build/source-musical-spans-2026-10-03/candidate-v4/Core/Detection/NativeScorePageAnalyzer.swift'),
 Path('.build/brahms-numbered-lines-2026-10-03/candidate-v2/Core/Detection/NativeScorePageAnalyzer.swift'),
 Path('.build/brahms-numbered-lines-2026-10-03/baseline/fourcore.json'),
]
(r/'bindings.json').write_text(json.dumps({str(f):sha(f) for f in bindings},indent=2,sort_keys=True)+'\n')

files={}
for name in ['build-run.sh','protocol-before-results.json','source-bindings-before-results.json','combined-versus-numbered-v2.diff','combined-versus-production.diff','compare-fourcore-exact.py','diagnose-junction-ownership.py','freeze-report.py','case176.swift','fourcore.swift','existing795.swift','controls297.swift','expanded336.swift']:
 files[name]=p/name
files['make-combined-v4.py']=Path('.build/source-musical-spans-2026-10-03/make-combined-v4.py')
for name in ['StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift','NativeScorePageAnalyzer.swift']:
 files['candidate/Core/Detection/'+name]=p/'candidate/Core/Detection'/name
for f in (p/'candidate').glob('*'):
 if f.is_file() and f.suffix in ['.json','.log','.pgm']:files['candidate/'+f.name]=f
for f in (p/'candidate/fourcore-sources').glob('*.png'):files['candidate/fourcore-sources/'+f.name]=f
for f in (p/'ownership-diagnosis').glob('*'):files['ownership-diagnosis/'+f.name]=f
files['baseline/fourcore.json']=Path('.build/brahms-numbered-lines-2026-10-03/baseline/fourcore.json')
archive=r/'implementation-controls-and-diagnosis.zip'
members={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,f in sorted(files.items()):
  z.write(f,name);members[name]={'sha256':sha(f),'bytes':f.stat().st_size}
with zipfile.ZipFile(archive) as z:
 for name,data in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==data['sha256']
(r/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),'members':members,'omitted':'Rebuildable executables/module caches, uncompiled snapshot Core files, and independent297/336/29/6 evidence already archived in the hash-bound independent report. Source-binding field compiledDependencyHashes historically records the full snapshot; only six archived Detection dependencies were compiled by these runners.'},indent=2,sort_keys=True)+'\n')
print(len(members),archive.stat().st_size)
