from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
p=Path('.build/brahms-numbered-lines-2026-10-03')
ims=[Image.open(p/q).convert('RGB') for q in ['baseline-probe/original.pgm','baseline-probe/line-erased.pgm','candidate-v1-probe/line-erased.pgm']]
box=(286,93,314,124);scale=10
out=Image.new('RGB',(3*(box[2]-box[0])*scale, (box[3]-box[1])*scale+40),'white');d=ImageDraw.Draw(out)
for i,(im,label) in enumerate(zip(ims,['Untouched source','Legacy staff removal','Measured staff removal'])):
 out.paste(im.crop(box).resize(((box[2]-box[0])*scale,(box[3]-box[1])*scale)),(i*(box[2]-box[0])*scale,40));d.text((i*(box[2]-box[0])*scale+3,10),label,fill='black')
out.save(p/'failure38-endpoint-panel.png')
a=np.array(ims[1])[:,:,0]<190;b=np.array(ims[2])[:,:,0]<190
removed=np.argwhere(a&~b);restored=np.argwhere(b&~a)
r={'case':{'scale':.5,'tilt':0,'headStyle':1,'inset':3},'newlyErasedTotal':len(removed),'restoredTotal':len(restored),'newlyErasedAtEndpoint':[[int(x),int(y)] for y,x in removed if box[0]<=x<box[2] and box[1]<=y<box[3]],'restoredAtEndpoint':[[int(x),int(y)] for y,x in restored if box[0]<=x<box[2] and box[1]<=y<box[3]]}
(p/'failure38-mask-delta.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
