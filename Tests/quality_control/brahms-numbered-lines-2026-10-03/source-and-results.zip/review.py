from pathlib import Path
import json
from PIL import Image,ImageDraw
p=Path('.build/brahms-numbered-lines-2026-10-03');out=p/'source-review';out.mkdir(exist_ok=True)
b=json.load(open('.build/ownership-alternatives-2026-10-03/actual.json'));c=json.load(open(p/'candidate-v1/replay.json'));records=[]
for page in c['pages']:
 idx=page['pageIndex'];im=Image.open(f'.build/ownership-alternatives-2026-10-03/rasters/page-{idx+1}.png').convert('RGB');w,h=im.size
 bs=next(q for q in b['plan']['pages'] if q['pageIndex']==idx)['assignments'];cs=next(q for q in c['plan']['pages'] if q['pageIndex']==idx)['assignments']
 for old,new in zip(bs,cs):
  if (old['topFraction'],old['bottomFraction'])==(new['topFraction'],new['bottomFraction']):continue
  y0=max(0,int(min(old['topFraction'],new['topFraction'])*h)-70);y1=min(h,int(max(old['bottomFraction'],new['bottomFraction'])*h)+70)
  source=im.crop((0,y0,w,y1));canvas=Image.new('RGB',(w,source.height+40),'white');canvas.paste(source,(0,40));draw=ImageDraw.Draw(canvas)
  draw.text((15,10),new['id']+' / blue baseline, red candidate',(0,0,0))
  for bd,color in [(old,'blue'),(new,'red')]:
   for k in ['topFraction','bottomFraction']:
    y=bd[k]*h-y0+40;draw.line((0,y,w,y),fill=color,width=3)
  image=out/(new['id']+'.png');canvas.save(image)
  records.append({'id':new['id'],'page':idx+1,'oldPoints':[old[k]*page['pageHeight'] for k in ['topFraction','bottomFraction']],'newPoints':[new[k]*page['pageHeight'] for k in ['topFraction','bottomFraction']],'image':str(image),'sourcePixels':[0,y0,w,y1]})
(p/'source-review/index.json').write_text(json.dumps(records,indent=2)+'\n');print(len(records))
