from pathlib import Path
import shutil,hashlib,json
p=Path('.build/brahms-numbered-lines-2026-10-03')
c=p/'candidate-v1/Core'
shutil.copytree(p/'baseline/Core',c,dirs_exist_ok=True)
f=c/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text()
a=s.index('        for (index, staff) in lines.enumerated() {\n            if isCancelled()')
b=s.index('        var preservedMusicalConnection',a)
s=s[:a]+'''        for (index, staff) in lines.enumerated() {
            if isCancelled() { return nil }
            let thickness = max(0, Int((spaces[index] * 0.09).rounded()))
            let curves = measuredLineColumns(original: original, width: width, height: height,
                                             staff: staff, space: spaces[index], slope: slope)
            for (ordinal, line) in staff.enumerated() {
                for x in 0..<width {
                    let nominal = line + slope * (Double(x) - Double(width) / 2)
                    let y = Int(nominal.rounded())
                    let above = min(height - 1, max(0, y - thickness - 1))
                    let below = min(height - 1, max(0, y + thickness + 1))
                    // Keep every original crossing veto, even when a curved
                    // estimate suggests a different row through this column.
                    if original[above * width + x] && original[below * width + x] { continue }
                    if let curve = curves[ordinal][x] {
                        let center = nominal + curve.offset
                        var best: (top: Int, bottom: Int, distance: Double)?
                        for yy in (max(0, Int(center.rounded()) - 1))...min(height - 1, Int(center.rounded()) + 1) {
                            guard original[yy * width + x] else { continue }
                            var top = yy, bottom = yy + 1
                            while top > 0 && original[(top - 1) * width + x] { top -= 1 }
                            while bottom < height && original[bottom * width + x] { bottom += 1 }
                            let runCenter = Double(top + bottom - 1) / 2
                            let distance = abs(runCenter - center)
                            guard distance <= 1, bottom - top <= curve.thickness + 1,
                                  Double(bottom - top) < spaces[index] * 0.45 else { continue }
                            if best == nil || distance < best!.distance { best = (top, bottom, distance) }
                        }
                        if let run = best {
                            let radius = max(0, Int((Double(curve.thickness - 1) / 2).rounded()))
                            let measuredY = Int(center.rounded())
                            let upper = max(0, measuredY - radius - 1)
                            let lower = min(height - 1, measuredY + radius + 1)
                            if original[upper * width + x] && original[lower * width + x] { continue }
                            for yy in run.top..<run.bottom { ink[yy * width + x] = false }
                        }
                    } else {
                        for dy in -thickness...thickness where y + dy >= 0 && y + dy < height {
                            ink[(y + dy) * width + x] = false
                        }
                    }
                }
            }
        }
''' + s[b:]
pos=s.index('    static func analyze(')
helper='''    private struct MeasuredLineColumn {
        var offset: Double
        var thickness: Int
    }

    /// Analysis-only measured numbered line channels. A thin isolated run is
    /// insufficient: the source window and at least three other line identities
    /// must support the common local curve without crossing a half-space phase.
    private static func measuredLineColumns(original: [Bool], width: Int, height: Int,
                                            staff: [Double], space: Double, slope: Double) -> [[MeasuredLineColumn?]] {
        let empty = [[MeasuredLineColumn?]](repeating: [MeasuredLineColumn?](repeating: nil, count: width), count: 5)
        guard space > 2, staff.count == 5 else { return empty }
        let corridor = space * 0.45
        var samples = empty
        for ordinal in 0..<5 {
            for x in 0..<width {
                let nominal = staff[ordinal] + slope * (Double(x) - Double(width) / 2)
                let top = max(0, Int((nominal - corridor).rounded(.down)))
                let bottom = min(height - 1, Int((nominal + corridor).rounded(.up)))
                guard top <= bottom else { continue }
                var y = top
                var best: MeasuredLineColumn?
                var tied = false
                while y <= bottom {
                    if !original[y * width + x] { y += 1; continue }
                    var first = y, last = y + 1
                    while first > 0 && original[(first - 1) * width + x] { first -= 1 }
                    while last < height && original[last * width + x] { last += 1 }
                    y = last
                    let offset = Double(first + last - 1) / 2 - nominal
                    guard Double(last - first) < corridor, abs(offset) < corridor else { continue }
                    if best == nil || abs(offset) < abs(best!.offset) - 0.00001 {
                        best = MeasuredLineColumn(offset: offset, thickness: last - first); tied = false
                    } else if abs(abs(offset) - abs(best!.offset)) < 0.00001 { tied = true }
                }
                samples[ordinal][x] = tied ? nil : best
            }
        }
        let radius = max(1, Int((space * 3).rounded()))
        var windows = empty
        for ordinal in 0..<5 {
            for x in 0..<width {
                let left = max(0, x - radius), right = min(width, x + radius + 1)
                guard Double(right - left) >= space * 2 else { continue }
                let values = samples[ordinal][left..<right].compactMap { $0 }
                guard Double(values.count) >= Double(right - left) * 0.8 else { continue }
                let sorted = values.map(\\.offset).sorted()
                let offset = sorted[sorted.count / 2]
                let agreeing = values.filter { abs($0.offset - offset) <= 1 }
                guard Double(agreeing.count) >= Double(right - left) * 0.8 else { continue }
                let thicknesses = agreeing.map(\\.thickness).sorted()
                windows[ordinal][x] = MeasuredLineColumn(offset: offset, thickness: thicknesses[thicknesses.count / 2])
            }
        }
        var result = empty
        for x in 0..<width {
            let valid = (0..<5).compactMap { windows[$0][x] }
            guard valid.count >= 3 else { continue }
            let offsets = valid.map(\\.offset).sorted(), median = offsets[offsets.count / 2]
            let agreeing = valid.filter { abs($0.offset - median) <= max(1, space * 0.15) }
            guard agreeing.count >= 3 else { continue }
            let thicknesses = agreeing.map(\\.thickness).sorted()
            let shared = MeasuredLineColumn(offset: median, thickness: thicknesses[thicknesses.count / 2])
            for ordinal in 0..<5 {
                let own = windows[ordinal][x]
                let selected = own != nil && abs(own!.offset - median) <= max(1, space * 0.15) ? own! : shared
                if x > 0, let prior = result[ordinal][x - 1], abs(prior.offset - selected.offset) > 1 { continue }
                result[ordinal][x] = selected
            }
        }
        return result
    }

'''
s=s[:pos]+helper+s[pos:];f.write_text(s)
(p/'candidate-v1/source-hashes.json').write_text(json.dumps({str(q.relative_to(c)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(c.rglob('*.swift'))},indent=2)+'\n')
print(hashlib.sha256(f.read_bytes()).hexdigest())
