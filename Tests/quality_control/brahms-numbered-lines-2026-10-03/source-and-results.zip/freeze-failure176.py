import json,hashlib
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
p=Path('.build/brahms-numbered-lines-2026-10-03');v=p/'candidate-v2'
b=json.load(open('.build/ownership-alternatives-2026-10-03/results297.json'))[176];c=json.load(open(v/'controls297.json'))[176];single=json.load(open(v/'failure176.json'))[0]
assert c==single
mask=np.array(Image.open(v/'case176-middle-owner.pgm'))<190;source=np.array(Image.open(v/'case176-source.pgm'))<190;assert np.all(~mask|source)
a=b['targets'][1]['crop'];d=c['targets'][1]['crop'];ys,xs=np.where(mask)
old=((xs>=a[0]-1e-9)&(ys>=a[1]-1e-9)&(xs+1<=a[2]+1e-9)&(ys+1<=a[3]+1e-9));new=((xs>=d[0]-1e-9)&(ys>=d[1]-1e-9)&(xs+1<=d[2]+1e-9)&(ys+1<=d[3]+1e-9))
newlost=[[int(x),int(y)] for x,y in zip(xs[old&~new],ys[old&~new])];recovered=[[int(x),int(y)] for x,y in zip(xs[~old&new],ys[~old&new])]
r={'status':'CandidateV2 rejected: verified new source-pixel loss in an already failing case.','fixtureIndex':176,'fixtureKind':'edgeMusicBroken','scale':1,'tilt':0,'bow':10,'owner':1,'sourceEnvelope':b['targets'][1]['sourceEnvelope'],'baselineCrop':a,'candidateCrop':d,'baselineLostPixels':int((~old).sum()),'candidateLostPixels':int((~new).sum()),'newlyLostSourcePixels':newlost,'recoveredSourcePixels':recovered,'fixtureUnchanged':True,'sourceFixtureSHA256':hashlib.sha256((p/'controls297.swift').read_bytes()).hexdigest(),'diagnosticHarnessSHA256':hashlib.sha256((p/'failure176.swift').read_bytes()).hexdigest(),'sourceMaskSHA256':hashlib.sha256((v/'case176-source.pgm').read_bytes()).hexdigest(),'ownerMaskSHA256':hashlib.sha256((v/'case176-middle-owner.pgm').read_bytes()).hexdigest()}
assert len(newlost)==9 and not recovered
(v/'failure176-source-loss.json').write_text(json.dumps(r,indent=2)+'\n')
im=Image.open(v/'case176-source.pgm').convert('RGB');box=(570,180,630,250);crop=im.crop(box).resize((360,420));draw=ImageDraw.Draw(crop)
for y,color in [(a[1],'blue'),(d[1],'red')]:draw.line((0,(y-box[1])*6,crop.width,(y-box[1])*6),fill=color,width=2)
for x,y in newlost:draw.rectangle(((x-box[0])*6,(y-box[1])*6,(x-box[0]+1)*6-1,(y-box[1]+1)*6-1),outline='magenta',width=1)
canvas=Image.new('RGB',(600,460),'white');canvas.paste(crop,(0,40));dr=ImageDraw.Draw(canvas);dr.text((5,8),'Case176 source: blue old crop; red candidate; pink lost stem pixels',fill='black');dr.text((370,70),'9 new lost source pixels\nx600-602, y212-214\nScan gap: y227-234\nSource owner unchanged',fill='black');canvas.save(p/'failure176-source-panel.png')
print(json.dumps(r,indent=2));print('evidenceSHA',hashlib.sha256((v/'failure176-source-loss.json').read_bytes()).hexdigest())
