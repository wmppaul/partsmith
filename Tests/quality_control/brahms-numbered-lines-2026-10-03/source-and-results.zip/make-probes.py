from pathlib import Path
import shutil
p=Path('.build/brahms-numbered-lines-2026-10-03')
h=(p/'expanded336.swift').read_text();h=h.replace('for scale in [0.5, 0.6, 1.0, 1.5]', 'for scale in [0.5]').replace('for tilt in [-1.5, 0.0, 1.5]','for tilt in [0.0]').replace('for headStyle in 0...3','for headStyle in 1...1').replace('for inset in [0, 1, 2, 3, 4, 5, 6] as [Int?]','for inset in [3] as [Int?]')
h += '''\nenum Probe { static func save(_ ink:[Bool],_ w:Int,_ h:Int,_ name:String) {
 let url=URL(fileURLWithPath:CommandLine.arguments[1]).deletingLastPathComponent().appendingPathComponent(name+".pgm")
 var data=Data("P5\\n\\(w) \\(h)\\n255\\n".utf8);data.append(contentsOf:ink.map{$0 ? UInt8(0):UInt8(255)});try!data.write(to:url)
} }\n'''
(p/'probe.swift').write_text(h)
for v in ['baseline','candidate-v1']:
 c=p/(v+'-probe')/'Core';shutil.copytree(p/v/'Core',c,dirs_exist_ok=True)
 f=c/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text().replace('        var preservedMusicalConnection = false','        Probe.save(original,width,height,"original");Probe.save(ink,width,height,"line-erased")\n        var preservedMusicalConnection = false')
 s=s.replace('                        if ownsTerminalHead {','                        print("CONNECTOR",clearLeft,clearRight,"musical",ownsTerminalHead,"retain",retainMusicalEvidence)\n                        if ownsTerminalHead {')
 f.write_text(s)
