from pathlib import Path
import json,hashlib,shutil,zipfile
p=Path('.build/brahms-numbered-lines-2026-10-03');r=Path('Tests/quality_control/brahms-numbered-lines-2026-10-03');r.mkdir(exist_ok=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
for f in ['inputs-before-results.json','hypothesis-before-results.json','implementation-before-results.json','v2-protocol-before-results.json','failure38-endpoint-panel.png','failure38-mask-delta.json','failure176-source-panel.png']:
 shutil.copy2(p/f,r/f)
shutil.copy2(p/'candidate-v2/failure176-source-loss.json',r/'failure176-source-loss.json')
findings=json.load(open(p/'source-review/index.json'))
notes={
'p24-s1-cello':'Raised top excludes a little more of the previous Viola staff. Cello poco a poco in tempo, rests, clef, notes, final low ledger/slur/hairpin remain.',
'p24-s2-violin1':'Raised bottom removes a small amount of following ViolinII ink; all ViolinI notes, cresc., forte, dots and ending hairpins remain.',
'p24-s2-viola':'Raised bottom removes lower Cello notation but still includes most Cello staff. Viola notes, low forte, slurs and final hairpins remain; not a clean isolated part.',
'p24-s2-cello':'Raised top removes previous ViolinII residue; nearly the complete Viola staff remains. Cello low opening ledger/slur, cresc., forte, ending high notes and hairpins remain.',
'p24-s4-violin2':'Raised bottom trims adjacent Viola stem/ledger fragments. Entire ViolinII rest staff and clef remain.',
'p24-s4-viola':'Raised top trims previous ViolinII staff residue. Viola slurred heads/stems, low hairpins and forte remain.',
'p28-s1-violin1':'Raised bottom trims some ViolinII low ink but still includes neighboring staff. ViolinI printed24, high notes/slurs, hairpin and forte remain.',
'p28-s1-violin2':'Raised top removes most ViolinI upper notation while retaining about four neighboring lines. Own ViolinII clef, notes, dots, low slurs/hairpin/forte remain; not clean.',
'p28-s1-viola':'Raised top removes some previous ViolinII residue. Viola high notes, beams/slurs and low forte/arco/hairpins remain.',
'p28-s2-violin1':'Raised top removes previous-system Cello staff/fragments and its low dynamics. Current ViolinI high ledger notes, slurs, clef, hairpins and forte remain.',
'p28-s3-viola':'Lowered bottom adds source area and cannot remove old pixels. Existing low Viola hairpin remains; more Cello upper staff residue appears.',
'p28-s4-viola':'Raised top trims previous ViolinII notes. Viola initial clef/accidental/rest, all arco/slur notation, final fermata and pp remain; previous ViolinII pp still visible.'}
for x in findings:
 x['sourceReview']='No newly omitted target notation observed in the full-width source strip.';x['finding']=notes[x['id']];x['imageSHA256']=sha(Path(x['image']))
 x['imageArchivePath']=str(Path(x['image']).relative_to(p))
(r/'real-crop-findings.json').write_text(json.dumps(findings,indent=2)+'\n')
summary={
 'status':'Both candidates rejected; production Native unchanged. No broad corpus or export run.',
 'baselineNativeSHA256':sha(p/'baseline/Core/Detection/NativeScorePageAnalyzer.swift'),
 'candidateV1NativeSHA256':sha(p/'candidate-v1/Core/Detection/NativeScorePageAnalyzer.swift'),
 'candidateV2NativeSHA256':sha(p/'candidate-v2/Core/Detection/NativeScorePageAnalyzer.swift'),
 'permanentCropControls':{'v1':796,'v2':796,'knownLimit':'Existing detached three-row-gap annotation remains outside upper crop.'},
 'frozen297':{'baselineCompleteCases':238,'v1CompleteCases':238,'v2CompleteCases':238,'existingFailureWorsenedByBoth':'case176 middle owner loses9 additional exact source stem pixels;650→659'},
 'frozen336':{'baselineCompleteCases':336,'v1CompleteCases':318,'v1NewFailedCases':18,'v2CompleteCases':336,'v2NewOrWorsenedEnvelopeIntersections':0},
 'fourCore36':{'newOrWorsenedSourceLossV1':0,'newOrWorsenedSourceLossV2':0,'changedOwnerCrops':24,'changes':'One-point outward expansions on staff3 at1×/1.5×; existing omissions stay recorded.'},
 'actualReplay':{'pages':[24,28],'changedCropRectangles':12,'assignmentIdentityOrStaffGeometryChanges':0,'v1v2PlansIdentical':True,'v1v2ComponentMultisetsIdentical':True,'sourceReview':'All12 changed source strips viewed; no newly lost target observed. Many neighboring staff lines remain.','candidateV2ReplaySHA256':sha(p/'candidate-v2/replay.json')},
 'decision':'RejectV1 for18 new full-envelope omissions and existing damaged-stem regression. RejectV2 despite336 recovery because exact source-owner mask confirms9 additional stem pixels omitted in case176.',
 'nextRequirement':'Musical ownership across scan interruptions must survive an improved line representation. Preserve source-owned branches rather than relying on incidental line remnants to expand crops; no threshold tuning or candidate promotion is justified.'
}
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Freeze all reproducible source/harness/result/visual evidence without executables.
allowed={'.swift','.py','.sh','.json','.log','.png','.pgm'};files=[]
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.suffix not in allowed:continue
 if '__pycache__' in f.parts:continue
 files.append(f)
# Add original baseline result records actually compared, not source-generated replacements.
extras=[Path('.build/ownership-alternatives-2026-10-03')/x for x in ['results297.json','results336.json','actual.json']]
with zipfile.ZipFile(r/'source-and-results.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:z.write(f,str(f.relative_to(p)))
 for f in extras:z.write(f,'prior-baseline/'+f.name)
with zipfile.ZipFile(r/'source-and-results.zip') as z:
 contents={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
(r/'archive-manifest.json').write_text(json.dumps(contents,indent=2)+'\n')
with zipfile.ZipFile(r/'source-and-results.zip') as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in contents.items())
print('archive',len(contents),'files', (r/'source-and-results.zip').stat().st_size, 'bytes')
