from pathlib import Path
import json,hashlib,shutil
p=Path('.build/brahms-numbered-lines-2026-10-03');c=p/'candidate-v2/Core';shutil.copytree(p/'candidate-v1/Core',c,dirs_exist_ok=True)
f=c/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text();old=(p/'baseline/Core/Detection/NativeScorePageAnalyzer.swift').read_text()
a=old.index('        for (index, staff) in lines.enumerated() {\n            if isCancelled()');b=old.index('        var preservedMusicalConnection',a)
legacy=old[a:b].replace('ink[','musicalFeatureInk[')
s=s.replace('        for (index, staff) in lines.enumerated() {\n            if isCancelled()', '        // Preserve the established musical feature representation separately\n        // from the curved-line structural component representation.\n        var musicalFeatureInk = original\n'+legacy+'        for (index, staff) in lines.enumerated() {\n            if isCancelled()',1)
a=s.index('                        let ownsTerminalHead');b=s.index('                        if ownsTerminalHead',a)
s=s[:a]+s[a:b].replace('ink[','musicalFeatureInk[')+s[b:]
s=s.replace('for column in clearLeft..<clearRight { ink[y * width + column] = false }','for column in clearLeft..<clearRight {\n                                ink[y * width + column] = false\n                                musicalFeatureInk[y * width + column] = false\n                            }')
f.write_text(s)
(p/'candidate-v2/source-hashes.json').write_text(json.dumps({str(q.relative_to(c)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(c.rglob('*.swift'))},indent=2)+'\n');print(hashlib.sha256(f.read_bytes()).hexdigest())
