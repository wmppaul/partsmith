import json,sys
from pathlib import Path
p=Path('.build/brahms-numbered-lines-2026-10-03');v=sys.argv[1];summary={}
for h,old,field in [('controls297','results297.json','allTargetsPreserved'),('expanded336','results336.json','bothCropsPreserveSource')]:
 b=json.load(open('.build/ownership-alternatives-2026-10-03/'+old));c=json.load(open(p/v/(h+'.json')));newfail=[];gains=[];changed=[];worse=[]
 for i,(x,y) in enumerate(zip(b,c)):
  if x.get(field) and not y.get(field):newfail.append(i)
  if not x.get(field) and y.get(field):gains.append(i)
  if x!=y:changed.append(i)
  if h=='controls297':
   for a,d in zip(x['targets'],y['targets']):
    assert a['sourceEnvelope']==d['sourceEnvelope'] and a['owner']==d['owner']
    e=a['sourceEnvelope'];ac=a['crop'];dc=d['crop'];inter=[max(e[0],ac[0]),max(e[1],ac[1]),min(e[2],ac[2]),min(e[3],ac[3])]
    if inter[0]<inter[2] and inter[1]<inter[3] and not(dc[0]<=inter[0]+1e-9 and dc[1]<=inter[1]+1e-9 and dc[2]>=inter[2]-1e-9 and dc[3]>=inter[3]-1e-9):worse.append({'index':i,'kind':x['kind'],'scale':x['scale'],'tilt':x['tilt'],'bow':x['bow'],'owner':a['owner'],'baseline':a,'candidate':d})
  else:
   e=x.get('sourceEnvelope');assert e==y.get('sourceEnvelope')
   if e:
    for j,(ac,dc) in enumerate(zip(x['bounds'],y['bounds'])):
     lo=max(e[1],ac[0]);hi=min(e[3],ac[1])
     if lo<hi and not(dc[0]<=lo+1e-9 and dc[1]>=hi-1e-9):worse.append({'index':i,'owner':j,'baseline':x,'candidate':y})
 summary[h]={'cases':len(c),'baselineFullyPreserved':sum(bool(x.get(field)) for x in b),'candidateFullyPreserved':sum(bool(x.get(field)) for x in c),'newFailedCases':newfail,'improvedCases':gains,'changedCases':changed,'newOrWorsenedEnvelopeIntersections':worse}
 print(h,'newfailed',len(newfail),'new/worse',len(worse),'changed',len(changed))
(p/v/'control-comparison-strict.json').write_text(json.dumps(summary,indent=2)+'\n')
