#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
r=.build/generated-rest-heading-review-2026-10-03
core=("$r"/Core/{DocumentModel,Detection,Layout,Export}/*.swift)
xcrun swiftc -O -module-cache-path .build/ModuleCache "${core[@]}" "$r/review.swift" -o "$r/review"
"$r/review" > "$r/run.log" 2>&1
