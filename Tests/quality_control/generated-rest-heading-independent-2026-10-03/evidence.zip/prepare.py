from pathlib import Path
import shutil,hashlib,json
r=Path('.build/generated-rest-heading-review-2026-10-03');shutil.copytree('Partsmith/Core',r/'Core',dirs_exist_ok=True)
(r/'source-hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path('Partsmith/Core').rglob('*.swift'))},indent=2)+'\n')
