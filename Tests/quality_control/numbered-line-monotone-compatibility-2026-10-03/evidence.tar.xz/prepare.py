from pathlib import Path
import shutil,hashlib,json
p=Path('.build/numbered-line-monotone-compatibility-2026-10-03');old=Path('.build/numbered-line-envelope-compatibility-2026-10-03');dst=p/'candidate/Core';assert not dst.exists();shutil.copytree(old/'candidate/Core',dst)
f=dst/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text();oldtext=s
anchor='''        for (index, staff) in lines.enumerated() {
            if isCancelled() { return nil }
            let thickness = max(0, Int((spaces[index] * 0.09).rounded()))
            let curves = measuredLineColumns'''
assert s.count(anchor)==1
s=s.replace(anchor,'''        // Measured line removal may remove additional source evidence, but
        // must not restore nominally removed endpoints into a new staff owner.
        ink = musicalFeatureInk
'''+anchor)
f.write_text(s)
for name in ['existing795.swift','fourcore.swift','compare-fourcore-exact.py']:shutil.copy2(old/name,p/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
protocol={'purpose':'Additional-only numbered staff-line erasure; prevent restored nominal-line pixels from making a prior single-owner component touch another staff core.','base':str(old/'candidate/Core'),'baseNativeSHA256':hashlib.sha256(oldtext.encode()).hexdigest(),'nativeSHA256':sha(f),'change':'Initialize structural ink from existing musicalFeatureInk immediately before the measured-line removal loop. Existing curve, crossing veto, original-source connector proof, legacy feature image and matched single-owner compatibility support stay unchanged.','noNewThresholds':True,'sourceCause':str(Path('.build/envelope-compatibility-corpus-2026-10-03/cause-242312/cause-manifest.json')),'sourceCauseSHA256':sha(Path('.build/envelope-compatibility-corpus-2026-10-03/cause-242312/cause-manifest.json')),'gates':['unchanged796 permanent','unchanged36 four-core exact pixel losses','independent297 exact loss sets and separate ownership','independent336 envelopes','independent29+6','native242312 pages1/2/16 source cause must no longer produce false shared component; no new original pixel loss gate relaxation','later parent corrected39 and full36 only after limited gates pass'],'diagnosticInvariant':'After identical source-based structural cuts and before component labeling, every retained structural ink pixel must also be retained in musicalFeatureInk. Instrument observer copies only, record mask hashes and output equality.'}
(p/'protocol-before-results.json').write_text(json.dumps(protocol,indent=2)+'\n');(p/'source-bindings-before-results.json').write_text(json.dumps({str(f.relative_to(dst)):sha(f) for f in sorted(dst.rglob('*.swift'))},indent=2)+'\n')
import difflib
(p/'candidate/versus-e32.diff').write_text(''.join(difflib.unified_diff(oldtext.splitlines(True),s.splitlines(True),fromfile='e32/NativeScorePageAnalyzer.swift',tofile='monotone/NativeScorePageAnalyzer.swift')))
build=(old/'build-run.sh').read_text().replace('.build/numbered-line-envelope-compatibility-2026-10-03',str(p));(p/'build-run.sh').write_text(build)
print('NATIVE',sha(f));print('PROTOCOL',sha(p/'protocol-before-results.json'))
