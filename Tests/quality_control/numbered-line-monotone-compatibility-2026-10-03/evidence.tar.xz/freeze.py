from pathlib import Path
import json,hashlib,tarfile,shutil
p=Path('.build/numbered-line-monotone-compatibility-2026-10-03');out=Path('Tests/quality_control/numbered-line-monotone-compatibility-2026-10-03');out.mkdir(exist_ok=True);assert not (out/'manifest.json').exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['README.md','protocol-before-results.json','source-bindings-before-results.json','source-comparison.json']:
 shutil.copy2(p/name,out/name)
shutil.copy2(p/'candidate/fourcore-exact-pixel-comparison.json',out/'fourcore-exact-pixel-comparison.json')
review=out/'root-three-page-review';review.mkdir(exist_ok=True)
for duplicate in review.glob("page-*-sheet-*.png"):duplicate.unlink()
for f in (p/'root-three-page-review').iterdir():
 if f.name=='review.json' or (f.suffix=='.png' and f.name.startswith('p') and '-s' in f.name and not f.name.startswith('page-')):shutil.copy2(f,review/f.name)
assert len(list(review.glob('*.png')))==30
names=['StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift','NativeScorePageAnalyzer.swift']
files=[p/f for f in ['prepare.py','build-run.sh','compare-fourcore-exact.py','compare-source.py','prepare-source-observer.py','run-source-observer.sh','existing795.swift','fourcore.swift','freeze.py']]
files += [p/'candidate/Core/Detection'/n for n in names]
files += [p/'candidate'/f for f in ['versus-e32.diff','existing795.log','fourcore.log','fourcore.json']]+list((p/'candidate/fourcore-sources').glob('*'))
files += [p/'source-observer'/f for f in ['trace.swift','run.log','observational-only.diff']]+[p/'source-observer/Core/Detection/NativeScorePageAnalyzer.swift']
for n in [1,2,16]:
 d=p/'source-observer'/f'p{n}';files+=list(d.glob('*.json'))+list(d.glob('*.pgm'))
entries={str(f.relative_to(p)):sha(f) for f in files};archive=out/'evidence.tar.xz'
with tarfile.open(archive,'w:xz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(p)))
with tarfile.open(archive) as t:
 for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==entries[m.name]
(out/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n')
refs=['Tests/quality_control/brahms-restored-endpoint-regression-2026-10-03/manifest.json','Tests/quality_control/envelope-compatibility-locked-workflow-2026-10-03/manifest.json','Tests/quality_control/monotone-line-mask-independent-2026-10-03/review.json']
(out/'external-bindings.json').write_text(json.dumps({f:sha(Path(f)) for f in refs},indent=2)+'\n')
(out/'binary-bindings.json').write_text(json.dumps({str(p/'candidate'/name):sha(p/'candidate'/name) for name in ['existing795','fourcore']},indent=2)+'\n')
manifest={str(f.relative_to(out)):sha(f) for f in sorted(out.rglob('*')) if f.is_file()};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');assert all(sha(out/f)==v for f,v in manifest.items())
print('manifest',sha(out/'manifest.json'),'archivebytes',archive.stat().st_size,'members',len(entries))
