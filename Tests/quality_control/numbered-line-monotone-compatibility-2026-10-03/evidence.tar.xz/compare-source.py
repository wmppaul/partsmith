from pathlib import Path
import json,hashlib,collections
import numpy as np
from PIL import Image
p=Path('.build/numbered-line-monotone-compatibility-2026-10-03');root=Path('.build/envelope-compatibility-corpus-2026-10-03');ident='lightly-skewed-10-brahms-string-quartet-no3-op67-imslp-242312';old=json.load(open(root/'baseline'/f'{ident}.json'));e32=json.load(open(root/'candidate'/f'{ident}.json'))
read=lambda p:np.asarray(Image.open(p))<190
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for n,target in [(1,'p1-s1-cello'),(2,'p2-s2-cello'),(16,'p16-s5-viola')]:
 d=p/'source-observer'/f'p{n}';pg=json.load(open(d/'page.json'));plan=json.load(open(d/'plan.json'));baseline=old['pages'][n-1]
 assert {k:v for k,v in pg.items() if k!='inkComponents'}=={k:v for k,v in baseline.items() if k!='inkComponents'}
 assert np.array_equal(read(d/'original.pgm'),read(root/'cause-242312/baseline'/f'p{n}'/'original.pgm'))
 before={b['id']:b for p in old['plan']['pages'] for b in p['assignments'] if b['pageIndex']==n-1};after={b['id']:b for p in plan['pages'] for b in p['assignments']};assert before.keys()==after.keys()
 def foreign(b):
  return [s['id'] for s in pg['staves'] if s['id'] not in b['candidateIDs'] and b['topFraction']<=s['staffLineFractions'][0] and b['bottomFraction']>=s['staffLineFractions'][-1]]
 changes=[];newNeighbors=[]
 for key,a in before.items():
  b=after[key]
  assert {k:v for k,v in a.items() if k not in ['topFraction','bottomFraction','warnings']}=={k:v for k,v in b.items() if k not in ['topFraction','bottomFraction','warnings']}
  if a!=b:changes.append({'bandID':key,'oldY':[a['topFraction']*pg['pageHeight'],a['bottomFraction']*pg['pageHeight']],'newY':[b['topFraction']*pg['pageHeight'],b['bottomFraction']*pg['pageHeight']],'oldForeign':foreign(a),'newForeign':foreign(b)})
  if set(foreign(b))-set(foreign(a)):newNeighbors.append(key)
 checks=[]
 for f in sorted(d.glob('*-subset.json')):
  stats=json.load(open(f));assert stats['restoredPixels']==0;checks.append({'stage':f.stem,**stats})
 row={'page':n,'targetBand':target,'beforeY':[before[target]['topFraction']*pg['pageHeight'],before[target]['bottomFraction']*pg['pageHeight']],'monotoneY':[after[target]['topFraction']*pg['pageHeight'],after[target]['bottomFraction']*pg['pageHeight']],'targetBaselineForeign':foreign(before[target]),'targetMonotoneForeign':foreign(after[target]),'changedCrops':changes,'newWholeNeighborBands':newNeighbors,'maskSubsetChecks':checks,'pageSHA256':sha(d/'page.json'),'planSHA256':sha(d/'plan.json')}
 rows.append(row)
 print(n,'target',row['beforeY'],'->',row['monotoneY'],'newForeign',newNeighbors,'changes',len(changes),'subsetcalls',len(checks))
(p/'source-comparison.json').write_text(json.dumps({'rows':rows,'noNewWholeNeighborRelationsOnThreePages':all(not r['newWholeNeighborBands'] for r in rows)},indent=2)+'\n')
