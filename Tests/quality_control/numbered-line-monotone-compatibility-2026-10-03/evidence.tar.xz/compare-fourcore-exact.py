from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
p=Path('.build/numbered-line-monotone-compatibility-2026-10-03');d=p/'candidate';b=json.load(open('.build/brahms-numbered-lines-2026-10-03/baseline/fourcore.json'));c=json.load(open(d/'fourcore.json'));records=[];bindings={}
for old,new in zip(b,c):
 assert (old['id'],old['scale'])==(new['id'],new['scale'])
 for ot,nt in zip(old['targets'],new['targets']):
  assert (ot['owner'],ot['sourceEnvelope'],ot['sourcePixels'])==(nt['owner'],nt['sourceEnvelope'],nt['sourcePixels'])
  f=d/'fourcore-sources'/f"{old['id']}-owner{ot['owner']}.png";raw=f.read_bytes();bindings[str(f)]=hashlib.sha256(raw).hexdigest();mask=np.asarray(Image.open(f))<190;ys,xs=np.where(mask)
  a=ot['crop'];z=nt['crop'];oldInside=(ys>=a[0]-1e-9)&(ys+1<=a[1]+1e-9);newInside=(ys>=z[0]-1e-9)&(ys+1<=z[1]+1e-9)
  assert int((~oldInside).sum())==ot['lostPixels'];assert int((~newInside).sum())==nt['lostPixels']
  lost=[[int(x),int(y)] for x,y in zip(xs[oldInside&~newInside],ys[oldInside&~newInside])];gained=[[int(x),int(y)] for x,y in zip(xs[~oldInside&newInside],ys[~oldInside&newInside])]
  records.append({'id':old['id'],'scale':old['scale'],'owner':ot['owner'],'sourceEnvelope':ot['sourceEnvelope'],'sourcePixelCount':len(xs),'baselineLost':ot['lostPixels'],'candidateLost':nt['lostPixels'],'newlyLostPixels':lost,'recoveredPixels':gained,'baselineCrop':a,'candidateCrop':z})
summary={'cases':len(c),'owners':len(records),'baselineIncomplete':sum(r['baselineLost']>0 for r in records),'candidateIncomplete':sum(r['candidateLost']>0 for r in records),'newlyLostPixels':sum(len(r['newlyLostPixels']) for r in records),'recoveredPixels':sum(len(r['recoveredPixels']) for r in records),'changedOwnerCrops':sum(r['baselineCrop']!=r['candidateCrop'] for r in records),'changedOwnerLosses':sum(r['baselineLost']!=r['candidateLost'] for r in records),'scope':'Exact original source-owner pixels, full unit pixel containment. Existing masks/envelopes unchanged. Source mask hashes bound.','records':records,'sourceMaskSHA256':bindings}
(d/'fourcore-exact-pixel-comparison.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items() if k not in ['records','sourceMaskSHA256']})
