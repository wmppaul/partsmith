#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
root=.build/system-batch-independent-2026-10-03
snapshot="${1:-final}"
if [[ "$snapshot" == "before" ]]; then path="$root"; else path="$root/final"; fi
xcrun swiftc -O -module-cache-path .build/ModuleCache "$path"/Core/{DocumentModel,Detection,Layout,Export}/*.swift "$path/audit.swift" -o "$path/audit"
"$path/audit" "$path/results.json"
