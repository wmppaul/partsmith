from pathlib import Path
import json,sys
p=Path('.build/brahms-seven-trims-independent-2026-10-04/layout-violin-findings.json');d=json.loads(p.read_text())if p.exists()else{}
for k,v in json.load(sys.stdin).items():assert k not in d;d[k]=v
p.write_text(json.dumps(d,indent=2)+'\n');print(len(d),'recorded')
