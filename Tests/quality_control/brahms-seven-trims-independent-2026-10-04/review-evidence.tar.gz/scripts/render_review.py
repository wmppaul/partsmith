from pathlib import Path
import hashlib,json,shutil
import pymupdf
W=Path('.build/brahms93521-reviewed-overlap-trim-2026-10-03');O=Path('.build/brahms-seven-trims-independent-2026-10-04');O.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();m=json.loads((W/'parts/manifest.json').read_text());ed=json.loads((W/'proposed-edits-before-output.json').read_text());print('manifest source:',m['source']);original=next((W/'parts').glob('*.partsmithproject'))/'source.pdf';corrected=W/'parts/rectified-review-source.pdf';assert sha(original)==ed['sourceSHA256'];assert sha(corrected)==ed['correctedSourceSHA256'];rows=[];sr=[];pdfs=[]
for name,path in [('original',original),('corrected',corrected)]:
 d=pymupdf.open(path)
 for pn,rect in [(24,[0,180,427,335]),(28,[0,0,427,185]),(31,[0,0,427,180]),(38,[0,0,427,185])]:
  out=O/f'{name}-p{pn}-context.png';d[pn-1].get_pixmap(matrix=pymupdf.Matrix(4,4),clip=pymupdf.Rect(*rect),alpha=False).save(out);sr.append({'kind':name,'page':pn,'rect':rect,'path':str(out),'sha256':sha(out)})
for part in m['parts']:
 p=W/'parts'/part['file'];h=sha(p);assert h==part['sha256'];d=pymupdf.open(p);pdfs.append({'file':part['file'],'sha256':h,'pages':len(d)})
 for e in ed['changes']:
  r=next((r for r in part['placements']if r['id']==e['id']),None)
  if not r:continue
  assert max(abs(a-b)for a,b in zip(e['newRect'],r['sourceRect']))<1e-8
  out=O/f"{e['id']}-final-crop.png";d[r['outputPage']-1].get_pixmap(matrix=pymupdf.Matrix(4,4),clip=pymupdf.Rect(*r['destinationRect']),alpha=False).save(out)
  page=O/f"{part['id']}-page-{r['outputPage']:02}.png";d[r['outputPage']-1].get_pixmap(matrix=pymupdf.Matrix(1.8,1.8),alpha=False).save(page)
  rows.append({**e,'outputPage':r['outputPage'],'destinationRect':r['destinationRect'],'pdf':str(p),'pdfSHA256':h,'finalCrop':str(out),'finalCropSHA256':sha(out),'finalPage':str(page),'finalPageSHA256':sha(page),'outputPageContentSHA256':hashlib.sha256(b''.join(d.xref_stream(x)for x in d[r['outputPage']-1].get_contents())).hexdigest(),'reviewStatus':'pending'})
 assert sha(p)==h
assert len(rows)==7
receipt={'originalSourceSHA256':sha(original),'correctedSourceSHA256':sha(corrected),'finalManifestSHA256':sha(W/'parts/manifest.json'),'proposedEditsSHA256':sha(W/'proposed-edits-before-output.json'),'pdfs':pdfs,'sourceContexts':sr,'rows':rows}
(O/'receipt-in-progress.json').write_text(json.dumps(receipt,indent=2)+'\n');shutil.copy(__file__,O/'render_review.py');print(json.dumps({'pdfs':pdfs,'rows':[(r['id'],r['outputPage'])for r in rows]},indent=2))
