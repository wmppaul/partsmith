from pathlib import Path
import json,hashlib,shutil,tarfile
W=Path('.build/brahms93521-reviewed-overlap-trim-2026-10-03');O=Path('.build/brahms-seven-trims-independent-2026-10-04');F=Path('Tests/quality_control/brahms-seven-trims-independent-2026-10-04');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not F.exists();assert (O/'native-contract-independent.json').exists();F.mkdir()
r=json.loads((O/'receipt-in-progress.json').read_text());seven=json.loads((O/'seven-findings.json').read_text());m=json.loads((W/'parts/manifest.json').read_text());comp=json.loads((W/'output-comparison.json').read_text());ours=json.loads((O/'layout-violin-findings.json').read_text());child=json.loads((O/'layout-viola-cello.json').read_text());assert len(ours)==17 and len(child['pages'])==18
for row in r['rows']:
 assert sha(row['finalCrop'])==row['finalCropSHA256'];assert sha(row['pdf'])==row['pdfSHA256'];row.update(seven[row['id']]);row['reviewStatus']='original-corrected-source-and-final-crop-visually-compared';row['finalCrop']='renders/'+Path(row['finalCrop']).name;row.pop('finalPage');row.pop('finalPageSHA256')
for s in r['sourceContexts']:assert sha(s['path'])==s['sha256'];s['path']='renders/'+Path(s['path']).name
for pn in [24,31]:assert sha(O/f'original-p{pn}-context.png')==sha(O/f'corrected-p{pn}-context.png')
r['reviewer']='/root/app_audit';r['scope']='Seven manual one-edge edits only, independently checked against the original and corrected source; no new algorithm claim. Output layouts for all35 changed pages reviewed by two independent reviewers. This is not a fresh all604-band musical completeness review.';r['sourceObligationsFile']='source-obligations-before-future-trials.json';r['sourceObligationsSHA256']=sha(Path('Tests/quality_control/brahms-residual-source-separation-2026-10-03/source-obligations-before-future-trials.json'));r['verdict']='All seven edited rows preserve intended notation. No new blocking composed-page-layout defect found. Residual neighboring source fragments and page-turn limitations remain.'
(F/'seven-row-receipt.json').write_text(json.dumps(r,indent=2)+'\n');pages=[]
for p in comp['changedPages']:
 assert sha(p['path'])==p['sha256'];part=next(x for x in m['parts']if x['id']==p['part']);assert p['PDFSHA256']==part['sha256'];key=f"{p['part']}-{p['page']}"
 if key in ours:note=ours[key];reviewer='/root/app_audit'
 else:
  q=next(x for x in child['pages']if x['part']==p['part']and x['page']==p['page']);assert q['directlyViewedFinalPNG']and q['hashesMatchComparisonAndManifest'];assert not q['blockingLayoutFindings'];note={k:q[k]for k in ['visualDisposition','headerTitleFooterMargins','consecutiveStripSeparation','finalRowCompletenessVisual','retainedNeighboringClutter','systemPageSplitAndTurnReadability']};reviewer=child['reviewerTask']
 pages.append({'part':p['part'],'page':p['page'],'pdfSHA256':p['PDFSHA256'],'png':'renders/'+Path(p['path']).name,'pngSHA256':p['sha256'],'directlyViewed':True,'reviewer':reviewer,'findings':note,'sourceBandIDs':[x['id']for x in part['placements']if x['outputPage']==p['page']]})
assert len(pages)==35 and len({(x['part'],x['page'])for x in pages})==35
(F/'changed-page-receipt.json').write_text(json.dumps({'scope':'All35 changed final output page layouts; remaining29 are pixel-identical according to separately hash-bound parent comparison. No new full-score musical source review.', 'manifestSHA256':sha(W/'parts/manifest.json'),'comparisonSHA256':sha(W/'output-comparison.json'),'pages':pages},indent=2)+'\n')
for src in [O/'native-contract-independent.json',O/'layout-viola-cello.json',W/'proposed-edits-before-output.json',W/'native-proof.json',W/'parts/manifest.json',W/'output-comparison.json',W/'root-review.json',Path('Tests/quality_control/brahms-residual-source-separation-2026-10-03/source-obligations-before-future-trials.json')]:
 dest=F/('output-manifest.json'if src.name=='manifest.json'else src.name);shutil.copy2(src,dest)
report='''# Independent review of seven manual Brahms93521 trims

All seven new crop edges preserve the intended notation in direct original-source, corrected-source and final-native-output comparisons. No crop correction is required for these seven edits. All 35 changed output-page layouts were also viewed; no new composed-strip collision, split system or footer/title boundary loss was found.

This is explicit manual assistance. It does not establish a new automatic crop result, clean engraving, performance-ready page turns or a fresh all-604-band source review.

## Source and final binding

Original source SHA256: `662aabfdecb2d125151c984fe1dc866ea068668ee9bb74f23f286f552603c14a`.

Saved corrected review source SHA256: `be1074d1436da4737bab07e360d1f6b4fda8b011db7b3a598e60cd62891cf8b4`. Pages 28/38 use this corrected coordinate space; pages 24/31 are unrectified and independently rendered identical in both sources. I also viewed all four uncorrected source contexts directly.

Final manifest SHA256: `18c4fdcc0db49db1350af235c184668dbb4392fafa0e676d53f558f6af499282`. PDF hashes, final placement rectangles, output detail PNG hashes and source page evidence are bound in `seven-row-receipt.json`. Every changed page is bound in `changed-page-receipt.json`.

## Seven source comparisons

| Source band | New edge, corrected top-down points | Independent preservation result |
|---|---:|---|
| p28s1 Violin I | bottom 65.5 | High ledger notes/phrase arcs, lower clef dot, crescendo and complete forte retained. |
| p28s1 Violin II | top 64.5 | Clef crown, upper staccato dots, lower flagged note, slurs, hairpin and forte retained. |
| p31s1 Violin II | top 67.5 | Rest, sharp accidentals, all flags/dots, p, low slurs and closing crescendo retained; damaged source staff segments are unchanged. |
| p24s2 Viola | bottom 283 | All articulation dots, slurs, lower cresc., f, closing half notes and hairpins retained. |
| p38s1 Viola | bottom 134.5 | Both voices/chords, triplet, upper/lower ties, lower tenutos, final high note/double arc and f retained. |
| p24s2 Cello | top 271 | Initial low ledger note/slur, all notes/accidentals, upper closing slur, lower cresc./f and hairpins retained. |
| p38s1 Cello | top 131 | Initial low accidental/ledger note, nested and long lower slurs, all tenutos, closing half note and f retained. |

Each shortened edge retains the frozen target envelope plus 1.5 source points. The opposite edge is unchanged. Visual review went beyond envelope containment: every named vulnerable mark was compared with source context and the actual final PDF detail. All seven edits remove the neighboring whole staff body in question. Partial neighboring ink still occupies the same vertical range as intended notation and remains.

## Independent saved-project audit

The separate `seven_trim_contract` reviewer found only the seven declared crop-edge fields plus `modifiedAt` changed. All 604 band identities and their order remain, 151 per instrument. Nine rectifications, the original source, corrected source, detection plan and source guard remain identical to the parent. All 42 copied markings retain their source rectangles; 25 destination rectangles move with layout. The previously reviewed Viola p8s2 in-tempo repair remains [0, 227.6901081916538, 427, 284]. See `native-contract-independent.json` for the exact check record.

Final page counts remain Violin I 17, Violin II 16, Viola 16, Cello 15 (64 total). Four Violin II bands and 20 Viola bands move between pages through reflow. All 35 changed pages were directly viewed: app_audit reviewed Violin I page 12 and all 16 Violin II pages; changed_page_layouts independently reviewed all 16 Viola pages and Cello pages 9/15. The parent comparison records the other 29 pages as pixel-identical; these were not re-reviewed as changed pages.

## Remaining presentation limits

Neighboring notes, dynamics, slurs, text and staff fragments remain conspicuous across many unchanged crop rows. The seven edits improve their local passages without cleaning the rest of the quartet. Specific residuals include preceding dolce text on p31s1 Violin II, following Viola high-note fragments under p28s1 Violin II, and overlapping Viola/Cello dynamic and note fragments at p24s2. Source publisher/page numbers remain in places.

Page turns are not optimized for performance. Violin II starts Andante near the bottom of page 6, and other movements/sections begin midpage. Viola first/second endings span pages 2–3. Continuous phrases often cross turns. Headings, ending brackets and intended last rows remain visibly inside the pages, but this should not be described as a performance-ready pagination pass.

The compact evidence archive contains source-context clips, seven final crop details, 35 changed-page PNGs and the review scripts. It does not duplicate the full original/corrected source PDFs or the four large part PDFs. No production code or delivered PDF was modified by this review.
'''
(F/'review.md').write_text(report)
files=[]
files += [(p,'renders/'+p.name)for p in O.glob('*-context.png')]
files += [(p,'renders/'+p.name)for p in O.glob('*-final-crop.png')]
files += [(Path(p['path']),'renders/'+Path(p['path']).name)for p in comp['changedPages']]
files += [(p,'scripts/'+p.name)for p in [O/'render_review.py',O/'record_layout.py',O/'freeze.py']]
assert len({name for _,name in files})==len(files)
with tarfile.open(F/'review-evidence.tar.gz','w:gz')as t:
 for path,name in files:t.add(path,arcname=name)
(F/'evidence-members.json').write_text(json.dumps([{'path':name,'sha256':sha(path),'bytes':path.stat().st_size}for path,name in files],indent=2)+'\n')
manifest={'review':'Seven manually assisted Brahms93521 trims; independent source/final review','files':[{'path':p.name,'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(F.iterdir())if p.is_file()],'sourceRowsReviewed':7,'changedPagesReviewed':35,'nativeContractReviewer':'/root/app_audit/seven_trim_contract','noProductionOrPDFEdits':True}
(F/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'path':str(F),'manifestSHA256':sha(F/'manifest.json'),'archiveBytes':(F/'review-evidence.tar.gz').stat().st_size,'archiveMembers':len(files)},indent=2))
