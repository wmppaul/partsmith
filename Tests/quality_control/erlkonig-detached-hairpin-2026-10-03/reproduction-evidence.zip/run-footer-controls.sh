#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
r=.build/erlkonig-hairpin-2026-10-03
c="$r/candidate/Core/Detection"
xcrun swiftc -O -module-cache-path .build/ModuleCache "$c/StaffBandDetector.swift" "$c/ScoreExtractionPlanner.swift" "$c/ScoreSharedEnding.swift" "$c/ScoreSharedEndingDetector.swift" "$c/ScoreLocalEndingPreservation.swift" "$c/NativeScorePageAnalyzer.swift" "$r/BaselineAnalyzer.swift" "$r/footer-controls.swift" -o "$r/footer-controls"
"$r/footer-controls" "$r/footer-controls.json" > "$r/footer-controls.log"
