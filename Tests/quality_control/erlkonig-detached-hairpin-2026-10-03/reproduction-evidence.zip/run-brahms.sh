#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
r=.build/erlkonig-hairpin-2026-10-03
core=("$r"/candidate/Core/{DocumentModel,Detection,Layout,Export}/*.swift)
xcrun swiftc -O -module-cache-path .build/ModuleCache "${core[@]}" "$r/BaselineAnalyzer.swift" "$r/probe-brahms.swift" -o "$r/probe-brahms"
"$r/probe-brahms" "$r/brahms" > "$r/brahms/native.log" 2>&1
