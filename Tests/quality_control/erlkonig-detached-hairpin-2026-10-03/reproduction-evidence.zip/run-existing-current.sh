#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
r=.build/erlkonig-hairpin-2026-10-03
c="$r/candidate/Core/Detection"
xcrun swiftc -O -module-cache-path .build/ModuleCache "$c/StaffBandDetector.swift" "$c/ScoreExtractionPlanner.swift" "$c/ScoreSharedEnding.swift" "$c/ScoreSharedEndingDetector.swift" "$c/ScoreLocalEndingPreservation.swift" "$c/NativeScorePageAnalyzer.swift" "$r/test_crop_quality-current.swift" -o "$r/test_crop_quality-current"
"$r/test_crop_quality-current" > "$r/existing-current-controls.log" 2>&1
