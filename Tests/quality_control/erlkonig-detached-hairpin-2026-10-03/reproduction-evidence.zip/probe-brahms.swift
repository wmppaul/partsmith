import Foundation
import CoreGraphics
import PDFKit
import ImageIO
import CryptoKit
@main enum Probe {
 struct Inventory:Codable {var source:String;var sourceSHA256:String;var pages:[ScorePageAnalysis]}
 static func main()throws {
  let a=CommandLine.arguments,r=URL(fileURLWithPath:a[1]),e=JSONEncoder();e.outputFormatting=[.prettyPrinted,.sortedKeys]
  let inv=try JSONDecoder().decode(Inventory.self,from:Data(contentsOf:r.appendingPathComponent("inventory.json")))
  let profile=try JSONDecoder().decode(ScoreExtractionProfile.self,from:Data(contentsOf:r.appendingPathComponent("profile.json")))
  let overrides=try JSONDecoder().decode([ScorePageOverride].self,from:Data(contentsOf:r.appendingPathComponent("overrides.json")))
  let source=try Data(contentsOf:URL(fileURLWithPath:inv.source));precondition(SHA256.hash(data:source).map{String(format:"%02x",$0)}.joined()==inv.sourceSHA256)
  let pdf=PDFDocument(data:source)!,start=Date();var baseline=inv,candidate=inv,summary:[[String:Any]]=[]
  func sig(_ cs:[ScoreInkComponent])->[String] {cs.map{"\($0.staffIDs)|\($0.bounds)|\($0.isOwnershipAlternative==true)"}.sorted()}
  for index in inv.pages.indices {
   autoreleasepool {
    let page=inv.pages[index],image=CGImageSourceCreateImageAtIndex(CGImageSourceCreateWithURL(r.appendingPathComponent("page-\(page.pageIndex+1).png") as CFURL,nil)!,0,nil)!
    let staves=page.staves.map{StaffBandCandidate(id:$0.id,staffLineFractions:$0.staffLineFractions,topFraction:$0.topFraction,bottomFraction:$0.bottomFraction,confidence:$0.confidence,warnings:$0.warnings)}
    let before=BaselineAnalyzer.notationComponents(image:image,candidates:staves,skewDegrees:page.analysisSkewDegrees)!
    let after=NativeScorePageAnalyzer.notationComponents(image:image,candidates:staves,skewDegrees:page.analysisSkewDegrees)!
    precondition(sig(before)==sig(page.inkComponents!),"Frozen inventory differs on page\(page.pageIndex+1)")
    precondition(sig(before.filter{$0.isOwnershipAlternative != true})==sig(after.filter{$0.isOwnershipAlternative != true}))
    let extras=after.filter{!sig(before).contains("\($0.staffIDs)|\($0.bounds)|\($0.isOwnershipAlternative==true)")}
    baseline.pages[index].inkComponents=before;candidate.pages[index].inkComponents=after
    summary.append(["page":page.pageIndex+1,"baselineComponents":before.count,"addedComponents":extras.map{["bounds":$0.bounds,"staffIDs":$0.staffIDs] as [String:Any]}])
    print("page \(page.pageIndex+1): +\(extras.count) hairpins");fflush(stdout)
   }
  }
  try e.encode(ScoreExtractionPlanner.plan(pages:baseline.pages,profile:profile,overrides:overrides)).write(to:r.appendingPathComponent("baseline-plan.json"))
  try e.encode(ScoreExtractionPlanner.plan(pages:candidate.pages,profile:profile,overrides:overrides)).write(to:r.appendingPathComponent("candidate-plan.json"))
  try e.encode(candidate).write(to:r.appendingPathComponent("candidate-inventory.json"))
  try JSONSerialization.data(withJSONObject:["pages":summary,"seconds":Date().timeIntervalSince(start)],options:[.prettyPrinted,.sortedKeys]).write(to:r.appendingPathComponent("native-summary.json"))
 }
}
