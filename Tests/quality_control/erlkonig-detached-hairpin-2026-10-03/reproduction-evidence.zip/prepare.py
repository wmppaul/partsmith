from pathlib import Path
import json,shutil,hashlib
r=Path('.build/erlkonig-hairpin-2026-10-03');shutil.copytree('Partsmith/Core',r/'baseline/Core',dirs_exist_ok=True);shutil.copytree('Partsmith/Core',r/'candidate/Core',dirs_exist_ok=True)
paths=sorted(Path('Partsmith/Core').rglob('*.swift'))+[Path('.build/erlkonig-complete-2026-10-03')/x for x in ['inventory.json','profile.json','overrides.json','source-reviewed-map.json']]+[Path('sample_scores/normal/03_piano_vocal/schubert_erlkonig_d328_score.pdf')]
(r/'input-hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
