import Foundation
import PDFKit
import ImageIO
@main enum RenderReview {
 struct Inventory:Decodable {var source:String;var sourceSHA256:String;var rectifications:[PageRectification];var pages:[ScorePageAnalysis]}
 static func main() throws {
  let root=URL(fileURLWithPath:CommandLine.arguments[1])
  let inv=try JSONDecoder().decode(Inventory.self,from:Data(contentsOf:URL(fileURLWithPath:".build/ownership-alternatives-output-2026-10-03/brahms-inventory.json")))
  let pdf=PDFDocument(url:URL(fileURLWithPath:inv.source))!
  let profile=try JSONDecoder().decode(ScoreExtractionProfile.self,from:Data(contentsOf:URL(fileURLWithPath:"Tests/quality_control/profiles/medium-skewed-06-brahms-string-quartet-no3-op67-imslp-93521.json")))
  var records:[[String:Any]]=[]
  for pageNumber in [7,17,19,23,28,34,38,39] {
   let index=pageNumber-1,analysis=inv.pages.first{$0.pageIndex==index}!,rectification=inv.rectifications.first{$0.pageIndex==index}!
   let old=SourcePageRenderCache(pdfDocument:pdf).rectifiedDisplayImage(for:index,rectification:rectification)!
   let fixed=SourcePageRenderCache(pdfDocument:pdf,rasterScale:2.5).rectifiedDisplayImage(for:index,rectification:rectification)!
   let groups=analysis.staves.count/4
   guard groups>0 else{continue}
   let seedIDs=Array(analysis.staves.sorted{$0.staffLineFractions[0]<$1.staffLineFractions[0]}.prefix(4).map(\.id))
   let seed=try ScoreSystemAssignment.assign(page:analysis,profile:profile,pagePlan:nil,existingOverride:nil,systemIndex:0,candidateIDs:seedIDs,presentPartIDs:Set(profile.parts.map(\.id)),startBarNumber:nil,barCount:nil)
   let before=ScoreSystemTemplateMatcher.suggest(pages:[analysis],profile:profile,reviewedOverrides:[seed],imageForPage:{_ in old})
   let after=ScoreSystemTemplateMatcher.suggest(pages:[analysis],profile:profile,reviewedOverrides:[seed],imageForPage:{_ in fixed})
   records.append(["page":pageNumber,"analysisSize":[analysis.imageWidth,analysis.imageHeight],"beforeSize":[old.width,old.height],"afterSize":[fixed.width,fixed.height],"staves":analysis.staves.count,"beforeSuggestions":before.suggestions.count,"afterSuggestions":after.suggestions.map{["pageIndex":$0.pageIndex,"systemIndex":$0.systemIndex,"candidateIDs":$0.candidateIDs,"templateSystemIndex":$0.templateSystemIndex,"bounds":$0.sourceBounds,"confidence":$0.confidence.rawValue] as [String:Any]},"beforeDiagnostics":before.diagnostics.map(\.message),"afterDiagnostics":after.diagnostics.map(\.message)])
   print("p\(pageNumber) old\(old.width)x\(old.height) fixed\(fixed.width)x\(fixed.height) expected\(analysis.imageWidth)x\(analysis.imageHeight); suggestions \(before.suggestions.count)→\(after.suggestions.count)");fflush(stdout)
  }
  try JSONSerialization.data(withJSONObject:records,options:[.prettyPrinted,.sortedKeys]).write(to:root.appendingPathComponent("render-results.json"))
 }
}
