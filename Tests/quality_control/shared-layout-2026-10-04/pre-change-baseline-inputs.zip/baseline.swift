import AppKit
import Foundation
import PDFKit

@main struct LegacyBaseline {
    struct Envelope: Codable { var project: ProjectData }
    static func pixels(_ page: PDFPage) -> Data {
        let bounds = page.bounds(for: .mediaBox)
        let c = CGContext(data: nil, width: Int(bounds.width), height: Int(bounds.height), bitsPerComponent: 8,
            bytesPerRow: Int(bounds.width) * 4, space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)!
        c.setFillColor(gray: 1, alpha: 1); c.fill(bounds); c.drawPDFPage(page.pageRef!)
        return Data(bytes: c.data!, count: Int(bounds.width * bounds.height) * 4)
    }
    static func main() throws {
        let fixture = URL(fileURLWithPath: "output/pdf/brahms-preservation/String Quartet No. 3- Op. 67 - excerpt- PDF pages 1-3.partsmithproject")
        let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
        let encoder = JSONEncoder(); encoder.dateEncodingStrategy = .iso8601; encoder.outputFormatting = [.sortedKeys, .prettyPrinted]
        let original = try decoder.decode(Envelope.self, from: Data(contentsOf: fixture.appendingPathComponent("project.json"))).project
        let source = try Data(contentsOf: fixture.appendingPathComponent("source.pdf"))
        let output = URL(fileURLWithPath: ".build/shared-layout-review-before/fixtures")
        try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
        try source.write(to: output.appendingPathComponent("source.pdf"))
        for variant in ["original", "uniform-custom", "mixed-custom", "asymmetric"] {
            var p = original
            if variant != "original" {
                for i in 0..<2 {
                    var part = p.parts[0]; part.id = UUID(); part.name = "Companion \(i+1)"
                    p.parts.append(part)
                    let bands = original.bands.map { value -> BandModel in var b = value; b.id = UUID(); b.partID = part.id; return b }
                    p.bands.append(contentsOf: bands)
                }
            }
            for i in p.parts.indices where variant == "uniform-custom" || variant == "mixed-custom" {
                p.parts[i].layoutSettings.scale = variant == "mixed-custom" ? 0.8 + 0.2 * Double(i) : 1.2
                p.parts[i].layoutSettings.interSystemGap = variant == "mixed-custom" ? 20 + 30 * Double(i) : 60
                p.parts[i].layoutSettings.sideMarginPoints = variant == "mixed-custom" ? 9 + 15 * Double(i) : 24
            }
            if variant == "asymmetric" { p.projectSettings.margins.leading = 12; p.projectSettings.margins.trailing = 42 }
            let folder = output.appendingPathComponent(variant)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try encoder.encode(Envelope(project: p)).write(to: folder.appendingPathComponent("project.json"))
            for (i, part) in p.parts.enumerated() {
                let result = try PartPDFExporter.renderResult(for: part.id, project: p, sourcePDFData: source)
                let pdf = PDFDocument(data: result.data)!
                try result.data.write(to: folder.appendingPathComponent("part-\(i).pdf"))
                for page in 0..<pdf.pageCount { try pixels(pdf.page(at: page)!).write(to: folder.appendingPathComponent("part-\(i)-page-\(page).rgba")) }
                print("\(variant) part \(i): \(pdf.pageCount) pages")
            }
        }
    }
}
