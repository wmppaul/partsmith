from pathlib import Path
import json,hashlib
r=Path('.build/brahms-remaining-2026-10-03/thin-independent');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((r/'diagonal-baseline.json').read_text());c=json.loads((r/'diagonal-candidate.json').read_text());assert len(b)==len(c)==9
protocol=json.loads((r/'diagonal-frozen-protocol.json').read_text());assert sha(r/'diagonal-controls.swift')==protocol['fixtureSHA256']
for p in (r/'diagonal-baseline-sources').glob('*.png'):assert sha(p)==sha(r/'diagonal-candidate-sources'/p.name)
rows=[]
for x,y in zip(b,c):
 assert (x['kind'],x['scale'])==(y['kind'],y['scale'])
 targets=[]
 for a,z in zip(x['targets'],y['targets']):
  for field in ['sourceEnvelope','sourcePixels','owner']:assert a[field]==z[field]
  targets.append({'owner':a['owner'],'sourceEnvelope':a['sourceEnvelope'],'sourcePixels':a['sourcePixels'],'baselineLost':a['lostPixels'],'candidateLost':z['lostPixels'],'baselineCrop':a['crop'],'candidateCrop':z['crop']})
 rows.append({'kind':x['kind'],'scale':x['scale'],'baselinePreserves':all(t['baselineLost']==0 for t in targets),'candidatePreserves':all(t['candidateLost']==0 for t in targets),'targets':targets,'baselineComponents':x['components'],'candidateComponents':y['components']})
result={'fixtureSHA256':protocol['fixtureSHA256'],'sourceMaskBytesUnchanged':True,'cases':9,'baselinePassing':sum(x['baselinePreserves'] for x in rows),'candidatePassing':sum(x['candidatePreserves'] for x in rows),'newFailingCases':[x['kind']+'-'+str(x['scale']) for x in rows if x['baselinePreserves'] and not x['candidatePreserves']],'worsenedOwnerEnvelopes':sum(t['candidateLost']>t['baselineLost'] for x in rows for t in x['targets']),'rows':rows}
(r/'diagonal-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
