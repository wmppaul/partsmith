import Foundation
import CoreGraphics
import ImageIO
@main enum DiagonalMusicControls {
 static let w=720,h=600,space=14,tops=[170,340]
 static func image(_ a:[UInt8])->CGImage{CGImage(width:w,height:h,bitsPerComponent:8,bitsPerPixel:8,bytesPerRow:w,space:CGColorSpaceCreateDeviceGray(),bitmapInfo:CGBitmapInfo(rawValue:0),provider:CGDataProvider(data:Data(a) as CFData)!,decode:nil,shouldInterpolate:false,intent:.defaultIntent)!}
 static func save(_ a:[UInt8],_ path:URL){let sink=CGImageDestinationCreateWithURL(path as CFURL,"public.png" as CFString,1,nil)!;CGImageDestinationAddImage(sink,image(a),nil);precondition(CGImageDestinationFinalize(sink))}
 static func main() throws {
  let out=URL(fileURLWithPath:CommandLine.arguments[1]),dir=URL(fileURLWithPath:CommandLine.arguments[2]);try FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
  var records:[[String:Any]]=[]
  let profile=ScoreExtractionProfile(parts:[.init(id:"upper",name:"Upper staff view",staffCount:1),.init(id:"lower",name:"Lower staff view",staffCount:1)],cropMode:"compact")
  for kind in ["diagonal-glissando","curved-cross-staff-slur","returning-cross-staff-curve"] {
   var pixels=[UInt8](repeating:255,count:w*h),owners=[UInt8](repeating:0,count:w*h)
   func rect(_ x0:Int,_ y0:Int,_ x1:Int,_ y1:Int,_ owner:UInt8=0){for y in y0..<y1{for x in x0..<x1{pixels[y*w+x]=0;owners[y*w+x] |= owner}}}
   for (i,top) in tops.enumerated(){for line in 0..<5{rect(40,top+line*space,650,top+line*space+1)};rect(150+i*60,top-20,153+i*60,top+31,UInt8(1<<i));rect(142+i*60,top+24,154+i*60,top+30,UInt8(1<<i))}
   rect(40,tops[0],43,tops[1]+4*space+1)
   // This isolated phrase/glissando stroke is MUSICAL ink authored before
   // analysis. It bridges two physical staff views of the same cross-staff
   // phrase; both must retain it. A slur need not touch either notehead.
   // Every raster row is thin, but total horizontal reach is intentional.
   for y in 190...376 {
    let t=Double(y-190)/186
    let dx=kind=="diagonal-glissando" ? 70*t : kind=="curved-cross-staff-slur" ? 70*t+20*sin(Double.pi*t) : 65*sin(Double.pi*t)
    let x=360+Int(dx.rounded());rect(x,y,x+3,y+1,3)
   }
   save(pixels,dir.appendingPathComponent(kind+".png"))
   var envelopes:[[Int]]=[]
   for owner in 0..<2{
    var mask=[UInt8](repeating:255,count:w*h),x0=w,y0=h,x1=0,y1=0
    for y in 0..<h{for x in 0..<w where owners[y*w+x] & UInt8(1<<owner) != 0 {mask[y*w+x]=0;x0=min(x0,x);y0=min(y0,y);x1=max(x1,x+1);y1=max(y1,y+1)}}
    save(mask,dir.appendingPathComponent(kind+"-owner\(owner).png"));envelopes.append([x0,y0,x1,y1])
   }
   for scale in [0.5,1.0,1.5] {
    let width=Int(Double(w)*scale),height=Int(Double(h)*scale)
    let context=CGContext(data:nil,width:width,height:height,bitsPerComponent:8,bytesPerRow:width,space:CGColorSpaceCreateDeviceGray(),bitmapInfo:CGImageAlphaInfo.none.rawValue)!
    context.setFillColor(gray:1,alpha:1);context.fill(CGRect(x:0,y:0,width:width,height:height));context.interpolationQuality = .high;context.draw(image(pixels),in:CGRect(x:0,y:0,width:width,height:height))
    let candidates=tops.enumerated().map{i,t in StaffBandCandidate(id:i,staffLineFractions:(0..<5).map{Double(t+$0*space)/Double(h)},topFraction:Double(t-3*space)/Double(h),bottomFraction:Double(t+7*space)/Double(h),confidence:1,warnings:[])}
    let components=NativeScorePageAnalyzer.notationComponents(image:context.makeImage()!,candidates:candidates,skewDegrees:0)!
    let page=ScorePageAnalysis(pageIndex:0,pageWidth:Double(w),pageHeight:Double(h),imageWidth:width,imageHeight:height,staves:candidates.map(ScoreObservedStaff.init),warnings:[],inkComponents:components)
    let plan=ScoreExtractionPlanner.plan(pages:[page],profile:profile)
    var targets:[[String:Any]]=[]
    for owner in 0..<2 {
     let band=plan.bands.first{$0.partID==(owner==0 ? "upper":"lower")}!;let crop=[band.topFraction*Double(h),band.bottomFraction*Double(h)]
     var total=0,lost=0
     for y in 0..<h{for x in 0..<w where owners[y*w+x] & UInt8(1<<owner) != 0 {total+=1;if Double(y)<crop[0]-1e-9 || Double(y+1)>crop[1]+1e-9{lost+=1}}}
     targets.append(["owner":owner,"sourceEnvelope":envelopes[owner],"sourcePixels":total,"lostPixels":lost,"crop":crop])
    }
    records.append(["kind":kind,"scale":scale,"targets":targets,"components":try JSONSerialization.jsonObject(with:JSONEncoder().encode(components)),"bands":try JSONSerialization.jsonObject(with:JSONEncoder().encode(plan.bands))])
   }
  }
  try JSONSerialization.data(withJSONObject:records,options:[.prettyPrinted,.sortedKeys]).write(to:out)
 }
}
