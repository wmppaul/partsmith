import Foundation
import PDFKit
import CoreGraphics
import CryptoKit
import ImageIO
import UniformTypeIdentifiers

@main enum MeasureResolution {
    struct Inventory: Codable {
        var source: String
        var sourceSHA256: String
        var pages: [ScorePageAnalysis]
        var plan: ScoreExtractionPlan
        var rectifications: [PageRectification]
    }
    static func main() throws {
        let a = CommandLine.arguments
        var input = try JSONDecoder().decode(Inventory.self, from: Data(contentsOf: URL(fileURLWithPath: a[1])))
        let data = try Data(contentsOf: URL(fileURLWithPath: input.source))
        precondition(SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() == input.sourceSHA256)
        let profile = try JSONDecoder().decode(ScoreExtractionProfile.self, from: Data(contentsOf: URL(fileURLWithPath: a[2])))
        let pdf = PDFDocument(data: data)!
        let destination = URL(fileURLWithPath: a[3])
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        for correction in input.rectifications {
            try autoreleasepool {
                let index = correction.pageIndex
                let page = pdf.page(at: index)!
                let bounds = page.bounds(for: .mediaBox)
                let scale = min(1800 / bounds.width, 2600 / bounds.height)
                let cache = SourcePageRenderCache(pdfDocument: pdf, rasterScale: scale)
                guard let image = cache.rectifiedDisplayImage(for: index, rectification: correction) else {
                    throw NSError(domain: "ResolutionMeasurement", code: index)
                }
                let before = input.pages[index]
                let after = NativeScorePageAnalyzer.analyze(pageIndex: index, image: image,
                    pageWidth: bounds.width, pageHeight: bounds.height)
                input.pages[index] = after
                let png = destination.appendingPathComponent("page-\(index + 1).png")
                let output = CGImageDestinationCreateWithURL(png as CFURL, UTType.png.identifier as CFString, 1, nil)!
                CGImageDestinationAddImage(output, image, nil)
                precondition(CGImageDestinationFinalize(output))
                print("page", index + 1, "image", image.width, image.height,
                      "staves", before.staves.count, after.staves.count)
                fflush(stdout)
            }
        }
        input.plan = ScoreExtractionPlanner.plan(pages: input.pages, profile: profile)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(input).write(to: destination.appendingPathComponent("candidate.json"))
    }
}
