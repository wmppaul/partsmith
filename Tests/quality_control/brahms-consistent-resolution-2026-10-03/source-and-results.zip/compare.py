import json
from pathlib import Path

work = Path('.build/brahms-consistent-resolution-2026-10-03')
old = json.loads(Path('.build/ownership-alternatives-2026-10-03/actual.json').read_text())
new = json.loads((work / 'results/candidate.json').read_text())
pages = [x['pageIndex'] for x in old['rectifications']]

def assignments(inv):
    return {b['id']: b for p in inv['plan']['pages'] for b in p['assignments']}

def neighbors(inv, b):
    return [s['id'] for s in inv['pages'][b['pageIndex']]['staves']
            if s['id'] not in b['candidateIDs']
            and b['topFraction'] <= s['staffLineFractions'][0]
            and b['bottomFraction'] >= s['staffLineFractions'][4]]

oa, na = assignments(old), assignments(new)
changes = []
for key in sorted(oa.keys() & na.keys()):
    a, b = oa[key], na[key]
    if a != b:
        height = old['pages'][a['pageIndex']]['pageHeight']
        changes.append(dict(band=key, page=a['pageIndex'] + 1,
            oldCandidates=a['candidateIDs'], newCandidates=b['candidateIDs'],
            oldY=[a['topFraction'] * height, a['bottomFraction'] * height],
            newY=[b['topFraction'] * height, b['bottomFraction'] * height],
            oldWholeNeighbors=neighbors(old, a), newWholeNeighbors=neighbors(new, b)))

report = dict(freshPages=[p + 1 for p in pages],
    scope='Nine corrected pages freshly analyzed; other thirty pages reused unchanged. No PDF export.',
    oldBands=len(oa), newBands=len(na),
    removedBands=sorted(oa.keys() - na.keys()), addedBands=sorted(na.keys() - oa.keys()),
    staffCounts=[dict(page=p + 1, old=len(old['pages'][p]['staves']), new=len(new['pages'][p]['staves']),
        oldImage=[old['pages'][p]['imageWidth'],old['pages'][p]['imageHeight']],
        newImage=[new['pages'][p]['imageWidth'],new['pages'][p]['imageHeight']]) for p in pages],
    oldWholeNeighborIncidences=sum(len(neighbors(old,b)) for b in oa.values()),
    newWholeNeighborIncidences=sum(len(neighbors(new,b)) for b in na.values()),
    changedBands=changes)
(work / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:v for k,v in report.items() if k != 'changedBands'},indent=2))
print('changed bands',len(changes))
