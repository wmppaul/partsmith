from pathlib import Path
import shutil,json,hashlib
p=Path('.build/source-musical-spans-2026-10-03');dst=p/'candidate-v2/Core';shutil.copytree(p/'candidate-v1-final/Core',dst)
f=dst/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text();a=s.index('    struct SourceBodyWitness: Codable {');b=s.index('    struct SourceSpanWitness:',a)
s=s[:a]+'''    struct SourceBodyWitness: Codable {
        var bounds: [Int]
        var center: [Double]
        var hollow: Bool
        var attachmentRows: [Int]
        var footprintRuns: [[Int]]
        var filledDisk: [Int]
        var explainedThinRuns: [[Int]]
    }
'''+s[b:]
a=s.index('            var compactRows:');b=s.index('        }\n        return witnesses',a)
s=s[:a]+(p/'v2-body.swift.fragment').read_text()+s[b:];f.write_text(s)
files={str(x.relative_to(dst)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(dst.rglob('*.swift'))}
(dst.parent/'source-hashes.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n')
print('Native',files['Detection/NativeScorePageAnalyzer.swift'])
print('Protocol',hashlib.sha256((p/'v2-protocol-before-results.json').read_bytes()).hexdigest())
