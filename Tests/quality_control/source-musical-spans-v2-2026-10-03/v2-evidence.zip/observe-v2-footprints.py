from pathlib import Path
import shutil
p=Path('.build/source-musical-spans-2026-10-03');d=p/'candidate-v2-footprint-observed/Core';shutil.copytree(p/'candidate-v2/Core',d)
f=d/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text();needle='                guard attachments.count >= 2,\n'
insert='''                FootprintProbe.capture([
                    "shaft": [left, right], "sourceRows": [top, bottom], "space": space,
                    "context": [xLo, yLo, xHi, yHi], "bounds": [minX, minY, maxX, maxY],
                    "radius": radius, "attachmentRows": attachments,
                    "pixels": pixels.sorted().map { [$0 % localWidth + xLo, $0 / localWidth + yLo] },
                    "originalShaftPixels": (minY..<maxY).flatMap { y in (left..<right).filter { black($0,y) }.map { [$0,y] } },
                    "explainedThinRuns": explainedRuns.filter { $0[1] < maxY + reach && $0[2] > minY - reach }
                ])
'''
assert s.count(needle)==1;s=s.replace(needle,insert+needle);f.write_text(s)
helper='''\nenum FootprintProbe {
 static var index=0
 static func capture(_ object:[String:Any]) {
  let dir=URL(fileURLWithPath:CommandLine.arguments[1]).deletingLastPathComponent().appendingPathComponent("footprint-records")
  try!FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
  try!JSONSerialization.data(withJSONObject:object,options:[.prettyPrinted,.sortedKeys]).write(to:dir.appendingPathComponent(String(format:"%04d.json",index)))
  index += 1
 }
}\n'''
(p/'case176-footprint-observed.swift').write_text((p/'case176.swift').read_text()+helper)
