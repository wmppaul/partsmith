from pathlib import Path
from PIL import Image,ImageDraw
import json
p=Path('.build/source-musical-spans-2026-10-03');d=p/'candidate-v2-footprint-observed';source=Image.open(p/'candidate-v1-final/case176-source.pgm').convert('RGB');groups=[json.load(open(f)) for f in sorted((d/'footprint-records').glob('*.json'))];stats=json.load(open(d/'disk-diagnosis.json'))
canvas=Image.new('RGB',(1110,640),'white');dr=ImageDraw.Draw(canvas);dr.text((10,10),'Exact case176: removing original shaft pixels splits each genuine filled head. No source pixels changed.',fill='black')
for i,(g,st) in enumerate(zip(groups,stats)):
 x0,y0,x1,y1=g['bounds'];box=(x0-3,y0-4,x1+3,y1+4);scale=14;w=(box[2]-box[0])*scale;h=(box[3]-box[1])*scale;top=65+i*280
 original=source.crop(box).resize((w,h),Image.Resampling.NEAREST)
 footprint=Image.new('RGB',(box[2]-box[0],box[3]-box[1]),'white');full=footprint.copy()
 for x,y in g['pixels']:
  footprint.putpixel((x-box[0],y-box[1]),(0,0,0));full.putpixel((x-box[0],y-box[1]),(0,0,0))
 for x,y in g['originalShaftPixels']:full.putpixel((x-box[0],y-box[1]),(0,0,0))
 for k,(label,img) in enumerate([('Original source',original),('V2: off-shaft footprint; disk fails',footprint.resize((w,h),Image.Resampling.NEAREST)),('Only original shaft rows restored',full.resize((w,h),Image.Resampling.NEAREST))]):
  xx=10+k*365;canvas.paste(img,(xx,top));dr.text((xx,top-22),label,fill='black')
  if k==2:
   cx,cy=st['sourceReconstructedDiskCenters'][0];r=st['radius'];dr.ellipse((xx+(cx-r-box[0])*scale,top+(cy-r-box[1])*scale,xx+(cx+r+1-box[0])*scale,top+(cy+r+1-box[1])*scale),outline='green',width=2)
 dr.text((10,top+h+8),f"{len(g['pixels'])} off-shaft source pixels; {len(g['originalShaftPixels'])} actual shaft pixels; radius {g['radius']}; zero V2 disks, {len(st['sourceReconstructedDiskCenters'])} disks with source shaft.",fill='black')
canvas.save(d/'source-disk-diagnosis.png')
