from pathlib import Path
import json
p=Path('.build/source-musical-spans-2026-10-03');d=p/'candidate-v2-footprint-observed';out=[]
assert json.load(open(d/'case176-footprint-observed.json'))==json.load(open(p/'candidate-v2/case176.json'))
for f in sorted((d/'footprint-records').glob('*.json')):
 g=json.load(open(f));pixels={tuple(v) for v in g['pixels']};at=g['attachmentRows'];shaft={tuple(v) for v in g['originalShaftPixels'] if min(at)<=v[1]<=max(at)};r=g['radius']
 offsets=[(dx,dy) for dy in range(-r,r+1) for dx in range(-r,r+1) if dx*dx+dy*dy<=r*r]
 a=[];b=[]
 for x,y in sorted(pixels,key=lambda v:(v[1],v[0])):
  if all((x+dx,y+dy) in pixels for dx,dy in offsets):a.append([x,y])
  if all((x+dx,y+dy) in pixels|shaft for dx,dy in offsets):b.append([x,y])
 record={k:g[k] for k in ['shaft','sourceRows','space','bounds','radius','attachmentRows']};record.update({'offshaftPixels':len(pixels),'actualShaftPixelsBetweenAttachmentRows':len(shaft),'v2DiskCenters':a,'sourceReconstructedDiskCenters':b,'existingOffshaftCentersOnly':True,'noInventedPixels':True});out.append(record)
 print(record)
(d/'disk-diagnosis.json').write_text(json.dumps(out,indent=2)+'\n')
