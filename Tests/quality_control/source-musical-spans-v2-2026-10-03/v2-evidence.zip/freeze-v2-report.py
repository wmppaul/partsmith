from pathlib import Path
import json,hashlib,shutil,zipfile
p=Path('.build/source-musical-spans-2026-10-03');r=Path('Tests/quality_control/source-musical-spans-v2-2026-10-03');r.mkdir(exist_ok=True)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
for name,src in {'protocol-before-results.json':p/'v2-protocol-before-results.json','fourcore-comparison.json':p/'candidate-v2/fourcore-comparison.json','real-five-comparison.json':p/'candidate-v2/real-five-comparison.json','disk-diagnosis.json':p/'candidate-v2-footprint-observed/disk-diagnosis.json','source-disk-diagnosis.png':p/'candidate-v2-footprint-observed/source-disk-diagnosis.png'}.items():shutil.copy2(src,r/name)
inputs=[p/'candidate-v2/source-hashes.json',p/'candidate-v2/Core/Detection/NativeScorePageAnalyzer.swift',p/'candidate-v2-footprint-observed/Core/Detection/NativeScorePageAnalyzer.swift',Path('Tests/quality_control/source-musical-spans-2026-10-03/manifest.json'),Path('Tests/quality_control/musical-span-independent-2026-10-03/candidate-v2/manifest.json'),Path('Tests/quality_control/musical-span-attached-addendum-2026-10-03/candidate-v2/manifest.json')]
(r/'bindings.json').write_text(json.dumps({str(f):sha(f) for f in inputs},indent=2,sort_keys=True)+'\n')
files={}
for name in ['v2-protocol-before-results.json','v2-body.swift.fragment','make-v2.py','compare-v2.py','observe-v2-footprints.py','diagnose-v2-disks.py','view-v2-disk-diagnosis.py','freeze-v2-report.py','case176.swift','fourcore.swift','real-five.swift','case176-footprint-observed.swift','build-run.sh']:
 files[name]=p/name
for name in ['StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift','NativeScorePageAnalyzer.swift']:files['candidate-v2/Core/Detection/'+name]=p/'candidate-v2/Core/Detection'/name
for variant in ['candidate-v2','candidate-v2-footprint-observed']:
 for f in (p/variant).rglob('*'):
  if f.is_file() and f.suffix in ['.json','.log'] and 'Core' not in f.parts:files[str(f.relative_to(p))]=f
files['candidate-v2-footprint-observed/Core/Detection/NativeScorePageAnalyzer.swift']=p/'candidate-v2-footprint-observed/Core/Detection/NativeScorePageAnalyzer.swift'
archive=r/'v2-evidence.zip';manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,f in sorted(files.items()):z.write(f,n);manifest[n]={'sha256':sha(f),'bytes':f.stat().st_size}
(r/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':sha(archive),'members':manifest},indent=2,sort_keys=True)+'\n')
with zipfile.ZipFile(archive) as z:
 for n,v in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==v['sha256']
print(len(manifest),archive.stat().st_size)
