from pathlib import Path
import shutil,json,hashlib
p=Path('.build/source-musical-spans-2026-10-03');c=p/'candidate-v1/Core';shutil.copytree(p/'baseline/Core',c,dirs_exist_ok=True)
f=c/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text();helper=(p/'SourceMusicalSpans.swift.fragment').read_text();pos=s.index('    static func analyze(');s=s[:pos]+helper+'\n'+s[pos:]
s=s.replace('        var preservedMusicalConnection = false','        var sourceSpanSeeds: [SourceSpanSeed] = []\n        var preservedMusicalConnection = false')
needle='                    let mergedPair = physicalStrokes.count == 2'
insert='''                    if retainMusicalEvidence {
                        for stroke in physicalStrokes {
                            sourceSpanSeeds.append(SourceSpanSeed(left: stroke.left, right: stroke.right,
                                y: (start + end) / 2, space: space))
                        }
                    }
'''
s=s.replace(needle,insert+needle)
needle='        result.sort {'
insert='''        if retainMusicalEvidence {
            let sourceSpans = sourceMusicalSpans(original: original, width: width, height: height,
                seeds: sourceSpanSeeds, lines: lines, staffIDs: ordered.map(\\.id), isCancelled: isCancelled)
            for span in sourceSpans {
                let bounds = [Double(span.bounds[0]) / Double(width), Double(span.bounds[1]) / Double(height),
                              Double(span.bounds[2]) / Double(width), Double(span.bounds[3]) / Double(height)]
                var alternative = ScoreInkComponent(bounds: bounds, staffIDs: span.staffIDs)
                alternative.isOwnershipAlternative = true
                if !result.contains(alternative) { result.append(alternative) }
            }
        }
'''
s=s.replace(needle,insert+needle);f.write_text(s)
(p/'candidate-v1/source-hashes.json').write_text(json.dumps({str(q.relative_to(c)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(c.rglob('*.swift'))},indent=2)+'\n');print(hashlib.sha256(f.read_bytes()).hexdigest())
# Reuse exact existing source-authored fixture adapter, changing no source pixel.
shutil.copy2('.build/brahms-numbered-lines-2026-10-03/failure176.swift',p/'case176.swift')
shutil.copy2('Tests/quality_control/four-core-independent-2026-10-03/controls.swift',p/'fourcore.swift')
script=Path('.build/brahms-numbered-lines-2026-10-03/build-run.sh').read_text().replace('p=.build/brahms-numbered-lines-2026-10-03','p=.build/source-musical-spans-2026-10-03');(p/'build-run.sh').write_text(script)
