from pathlib import Path
import json,hashlib,shutil,zipfile
from PIL import Image
p=Path('.build/source-musical-spans-2026-10-03');r=Path('Tests/quality_control/source-musical-spans-2026-10-03');r.mkdir(parents=True,exist_ok=True)
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def js(f,v):Path(f).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
for name in ['hypothesis-before-results.json','implementation-before-results.json','input-bindings-before-results.json','observer-invariance.json']:
 shutil.copy2(p/name,r/name)
shutil.copy2(p/'candidate-v1-final/fourcore-comparison.json',r/'fourcore-comparison.json')
shutil.copy2(p/'candidate-v1-observed-real/invariance.json',r/'real-observer-invariance.json')
shutil.copy2(p/'case176-source-witnesses.png',r/'case176-source-witnesses.png')
shutil.copytree(p/'real-witness-panels',r/'real-witness-panels',dirs_exist_ok=True)
source_patches=p/'source-patches';source_patches.mkdir(exist_ok=True)
bodyindex=json.load(open(p/'real-witness-panels/body-index.json'))
for row in bodyindex:
 im=Image.open(row['sourceRaster']);name=f"p{row['page']}-s{row['span']}-b{row['body']}.png";im.crop(tuple(row['sourcePanelBounds'])).save(source_patches/name)
 row['exactSourcePatch']=name;row['patchSHA256']=sha(source_patches/name)
js(r/'real-witness-panels/body-index.json',bodyindex)
verdicts=[
 {'page':23,'spanIndices':[0,1],'sourceIdentity':'One ordinary barline, proposed twice through adjacent seed columns. Upper fit is a slur crest at the line; lower fit is a staff/barline cross. No shared musical shaft.','classifiedBodies':['filled','filled','filled','filled']},
 {'page':28,'spanIndices':[0],'sourceIdentity':'Two separate tie/slur arcs crossing an ordinary barline in the Coda. Neither fitted window is a notehead.','classifiedBodies':['filled','filled']},
 {'page':29,'spanIndices':[0],'sourceIdentity':'Staff lines intersecting the terminal double line. Thick intersections impersonate filled heads.','classifiedBodies':['filled','filled']},
 {'page':38,'spanIndices':[0,1],'sourceIdentity':'First interval has two bare staff/barline crosses; second has a staff-line endpoint and a broken staff-end corner at the terminal line. The hollow fit is an open source corner, not a notehead.','classifiedBodies':['filled','filled','filled','hollow']},
 {'page':39,'spanIndices':[0,1],'sourceIdentity':'Two ordinary barlines intersect separate slur arcs. Three fits classify tiny thick arc/shaft overlaps as filled heads; one open corner is classified hollow.','classifiedBodies':['hollow','filled','filled','filled']}
]
js(r/'real-source-verdicts.json',{'verdict':'reject candidate v1','viewed':'All five original system context images, all five paired body/ellipse panels, all sixteen proposed bodies. Candidate boxes were not accepted as musical identity.','intervals':8,'bodies':16,'falseFilledBodies':14,'falseHollowBodies':2,'rows':verdicts})
corefiles=['StaffBandDetector.swift','ScoreExtractionPlanner.swift','ScoreSharedEnding.swift','ScoreSharedEndingDetector.swift','ScoreLocalEndingPreservation.swift','NativeScorePageAnalyzer.swift']
bind={'status':'Rejected scratch candidate; production unmodified','candidateNativeSHA256':sha(p/'candidate-v1-final/Core/Detection/NativeScorePageAnalyzer.swift'),'productionNativeSHA256AtFreeze':sha('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'),'baselineNativeSHA256':sha(p/'baseline/Core/Detection/NativeScorePageAnalyzer.swift'),'preCancellationNativeSHA256':sha(p/'candidate-v1/Core/Detection/NativeScorePageAnalyzer.swift'),'loggingNativeSHA256':sha(p/'candidate-v1-observed-real/Core/Detection/NativeScorePageAnalyzer.swift'),'compiledDependencies':{},'externalEvidence':{},'sourceRasters':{}}
for name in corefiles:
 bind['compiledDependencies'][name]={'baseline':sha(p/'baseline/Core/Detection'/name),'candidate':sha(p/'candidate-v1-final/Core/Detection'/name)}
for f in ['.build/brahms-source-span-full-replay-2026-10-03/candidate-v1.json','.build/brahms-source-span-full-replay-2026-10-03/candidate-comparison.json','Tests/quality_control/musical-span-independent-2026-10-03/manifest.json','Tests/quality_control/brahms-case176-ownership-2026-10-03/manifest.json','Tests/quality_control/musical-span-independent-2026-10-03/candidate-v1/manifest.json','Tests/quality_control/musical-span-attached-addendum-2026-10-03/manifest.json']:
 bind['externalEvidence'][f]=sha(f)
for pn in [23,28,29,38,39]:
 f=f'.build/brahms-source-span-full-replay-2026-10-03/rasters/page-{pn}.png';bind['sourceRasters'][f]=sha(f)
js(r/'bindings.json',bind)
summary={'status':'rejected','case176':{'completeOwners':3,'totalOwners':3,'fullSourceRecovery':True,'sourceSpanBounds':[592,187,611,541],'sourceShaft':[600,603,190,539],'sourceMissingRows':[227,228,229,230,231,232,233,234]},'originalFourCore':{'cases':36,'owners':144,'baselineIncomplete':68,'candidateIncomplete':60,'repaired':8,'newlyWorsened':0,'ordinaryExact':True,'oldComponentsRetained':True,'allCropsNoncontracting':True,'repairScope':'Only hollowOuter and hollowTiedOuter at scale0.5, intact and fiveMissingRows, owners0/1. Other omissions persist.'},'real39RootReplay':{'pages':39,'bands':604,'newSpans':8,'changedCrops':13,'addedWholeNeighborOccurrences':14,'falseIntervalsOnSourceReview':8,'ordinaryAndOldAlternativesExact':True,'croppingNoncontracting':True,'releaseSeconds':5.14,'timingOwnedBy':'root'},'smallFixtureTiming':{'case176ReleaseSeconds':0.01,'case176DebugSeconds':0.44,'compilationExcluded':True,'debugReleaseResultsExact':True,'scope':'One single synthetic fixture including its file output; not UI or big-score responsiveness.'},'notRun':['Full1477-page corpus','Full permanent796 controls on this candidate','Full297/336 replay on this candidate','Combined numbered-line plus source-span candidate'],'limitations':['Parametric source support confuses filled structural crosses and slur/barline intersections with bodies.','Hollow open corners and attached p-shaped glyphs are ambiguous.','Original four-core musical recall remains incomplete.','Only adjacent accepted bodies are paired; full three-plus-head ownership remains incomplete.','Fixed vertical columns can abstain on strongly curved shafts.']}
js(r/'summary.json',summary)
files={}
for name in ['hypothesis-before-results.json','implementation-before-results.json','input-bindings-before-results.json','SourceMusicalSpans.swift.fragment','make-candidate.py','freeze-cancellable-v1.py','prepare-observer.py','build-run.sh','build-run-debug.sh','case176.swift','fourcore.swift','case176-observed.swift','fourcore-observed.swift','real-five-observed.swift','real-witness-panels.py','view-witnesses.py','freeze-report.py','observer-invariance.json']:
 files[name]=p/name
for variant in ['baseline','candidate-v1-final']:
 for name in corefiles:files[f'{variant}/Core/Detection/{name}']=p/variant/'Core/Detection'/name
files['candidate-v1-observed/Core/Detection/NativeScorePageAnalyzer.swift']=p/'candidate-v1-observed/Core/Detection/NativeScorePageAnalyzer.swift'
files['candidate-v1-before-cancellation/NativeScorePageAnalyzer.swift']=p/'candidate-v1/Core/Detection/NativeScorePageAnalyzer.swift'
for variant in ['candidate-v1-final','candidate-v1-debug','candidate-v1-observed','candidate-v1-observed-fourcore','candidate-v1-observed-real']:
 for f in (p/variant).rglob('*'):
  if f.is_file() and 'Core' not in f.parts and ('span-records' in f.parts or f.parent==p/variant) and f.suffix in ['.json','.log','.pgm']:
   files[str(f.relative_to(p))]=f
for f in source_patches.glob('*.png'):files['exact-source-patches/'+f.name]=f
# Original four-core source images and owner masks are small, immutable source obligations.
for f in (p/'candidate-v1-final/fourcore-sources').glob('*.png'):files['fourcore-sources/'+f.name]=f
files['root-full39-comparison.json']=Path('.build/brahms-source-span-full-replay-2026-10-03/candidate-comparison.json')
archive=r/'implementation-and-evidence.zip';members={}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,f in sorted(files.items()):
  raw=f.read_bytes();z.writestr(name,raw);members[name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
js(r/'archive-manifest.json',{'archive':archive.name,'sha256':sha(archive),'members':members,'omitted':'Binaries, full duplicated real-score rasters, and root full39 result. Source rasters/root results are independently hash-bound; exact body source patches and complete changed-page analyses are retained.'})
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members)
 for name,v in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==v['sha256']
print('archive',len(members),'members',archive.stat().st_size,'bytes verified')
