from pathlib import Path
import json,hashlib,shutil
p=Path('.build/source-musical-spans-2026-10-03');c=p/'candidate-v1-final/Core';shutil.copytree(p/'candidate-v1/Core',c,dirs_exist_ok=True)
f=c/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text()
s=s.replace('                while y >= 0 && y < height {\n                    if occupied(y)', '                while y >= 0 && y < height {\n                    if y % 64 == 0 && isCancelled() { return [] }\n                    if occupied(y)',1)
s=s.replace('            for y in top..<bottom where black(center, y) {','            for y in top..<bottom where black(center, y) {\n                if y % 64 == 0 && isCancelled() { return [] }',1)
s=s.replace('            for group in groups {\n                guard', '            for group in groups {\n                if isCancelled() { return [] }\n                guard',1)
s=s.replace('                        for rxFactor in [0.6, 0.75] { for ryFactor in [0.28, 0.38] { for degrees in [-30.0, 0, 30] {','                        for rxFactor in [0.6, 0.75] { for ryFactor in [0.28, 0.38] { for degrees in [-30.0, 0, 30] {\n                            if isCancelled() { return [] }',1)
f.write_text(s);(p/'candidate-v1-final/source-hashes.json').write_text(json.dumps({str(q.relative_to(c)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(c.rglob('*.swift'))},indent=2)+'\n');print(hashlib.sha256(f.read_bytes()).hexdigest())
