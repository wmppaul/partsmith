from pathlib import Path
import shutil
p=Path('.build/source-musical-spans-2026-10-03');d=p/'candidate-v1-observed/Core';shutil.copytree(p/'candidate-v1-final/Core',d,dirs_exist_ok=True)
f=d/'Detection/NativeScorePageAnalyzer.swift';s=f.read_text().replace('            for span in sourceSpans {','            SpanProbe.capture(sourceSpans, seeds: sourceSpanSeeds, width: width, height: height)\n            for span in sourceSpans {',1);f.write_text(s)
helper='''\nenum SpanProbe {
 static var index = 0
 static func capture(_ spans:[NativeScorePageAnalyzer.SourceSpanWitness], seeds:[NativeScorePageAnalyzer.SourceSpanSeed], width:Int,height:Int) {
  let dir=URL(fileURLWithPath:CommandLine.arguments[1]).deletingLastPathComponent().appendingPathComponent("span-records")
  try! FileManager.default.createDirectory(at:dir,withIntermediateDirectories:true)
  let seedData=seeds.map {["left":Double($0.left),"right":Double($0.right),"y":Double($0.y),"space":$0.space]}
  let data:[String:Any] = ["index":index,"width":width,"height":height,"seeds":seedData,"spans":try!JSONSerialization.jsonObject(with:JSONEncoder().encode(spans))]
  try!JSONSerialization.data(withJSONObject:data,options:[.prettyPrinted,.sortedKeys]).write(to:dir.appendingPathComponent(String(format:"%03d.json",index)))
  index += 1
 }
}\n'''
for h in ['case176','fourcore']:(p/(h+'-observed.swift')).write_text((p/(h+'.swift')).read_text()+helper)
