import json,math
from pathlib import Path
from PIL import Image,ImageDraw
p=Path('.build/source-musical-spans-2026-10-03');r=json.load(open(p/'candidate-v1-observed/span-records/000.json'));im=Image.open(p/'candidate-v1-final/case176-source.pgm').convert('RGB')
canvas=Image.new('RGB',(840,540),'white');d=ImageDraw.Draw(canvas);d.text((8,5),'Case176: original source, actual accepted bodies and same-spine interruption',fill='black')
for k,(label,box) in enumerate([('Upper genuine head',(578,175,625,235)),('Lower genuine head',(578,505,625,555))]):
 scale=6;patch=im.crop(box).resize(((box[2]-box[0])*scale,(box[3]-box[1])*scale));dr=ImageDraw.Draw(patch)
 for span in r['spans']:
  for b in span['bodies']:
   cx,cy=b['center'];rx,ry=b['radii'];a=math.radians(b['angle']);co,si=math.cos(a),math.sin(a)
   pts=[]
   for n in range(101):
    t=n/100*2*math.pi;x=cx+rx*math.cos(t)*co-ry*math.sin(t)*si;y=cy+rx*math.cos(t)*si+ry*math.sin(t)*co
    pts.append(((x-box[0])*scale,(y-box[1])*scale))
   dr.line(pts,fill='red',width=2)
   x0,y0,x1,y1=b['bounds'];dr.rectangle(((x0-box[0])*scale,(y0-box[1])*scale,(x1-box[0])*scale,(y1-box[1])*scale),outline='blue',width=1)
 canvas.paste(patch,(15+k*360,50));d.text((15+k*360,30),label,fill='black')
d.text((15,425),'Accepted source shaft x600..<603, source rows190..<539; gap227..<235.',fill='black')
d.text((15,450),'Alternative envelope[592,187,611,541], owners0/1/2. All original music remains required.',fill='black')
canvas.save(p/'case176-source-witnesses.png')
