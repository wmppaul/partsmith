from pathlib import Path
import json,math,hashlib
from PIL import Image,ImageDraw
p=Path('.build/source-musical-spans-2026-10-03');out=p/'real-witness-panels';out.mkdir(exist_ok=True)
index=[]
for i,pn in enumerate([23,28,29,38,39]):
 r=json.load(open(p/f'candidate-v1-observed-real/span-records/{i:03d}.json'));fp=Path(f'.build/brahms-source-span-full-replay-2026-10-03/rasters/page-{pn}.png');im=Image.open(fp).convert('RGB');assert im.size==(r['width'],r['height'])
 canv=Image.new('RGB',(1140, len(r['spans'])*510+40),'white');d=ImageDraw.Draw(canv);d.text((12,10),f'Physical page {pn}: original source; fitted shapes do not establish musical identity.',fill='black')
 for j,s in enumerate(r['spans']):
  top=40+j*510;d.text((12,top),f"Span {j}: x{s['stroke']} y{s['sourceRows']} owners{s['staffIDs']}",fill='black')
  for k,b in enumerate(s['bodies']):
   cx,cy=b['center'];box=(int(cx)-25,int(cy)-16,int(cx)+26,int(cy)+17);scale=8;plain=im.crop(box).resize((408,264),Image.Resampling.NEAREST);ov=plain.copy();dr=ImageDraw.Draw(ov);a=math.radians(b['angle']);co,si=math.cos(a),math.sin(a);rx,ry=b['radii'];pts=[]
   for n in range(101):
    t=n/100*2*math.pi;x=cx+rx*math.cos(t)*co-ry*math.sin(t)*si;y=cy+rx*math.cos(t)*si+ry*math.sin(t)*co;pts.append(((x-box[0])*scale,(y-box[1])*scale))
   dr.line(pts,fill='red',width=2)
   lx,rr=s['stroke'];dr.line(((lx-box[0])*scale,0,(lx-box[0])*scale,264),fill='blue');dr.line(((rr-box[0])*scale,0,(rr-box[0])*scale,264),fill='blue')
   for yy in b['attachmentRows']:dr.line(((lx-box[0])*scale,(yy-box[1])*scale,(rr-box[0])*scale,(yy-box[1])*scale),fill='lime',width=2)
   x=12+k*550;canv.paste(plain,(x,top+24));canv.paste(ov.resize((306,198),Image.Resampling.NEAREST),(x,top+292));d.text((x+310,top+300),f"{'HOLLOW' if b['hollow'] else 'FILLED'}\ncenter{cx:.2f},{cy:.2f}\nradii{rx:.2f},{ry:.2f}\nangle{b['angle']}\nboundary{b['boundarySupport']:.3f}\ninterior{b['interiorDark']:.3f}\nwhite{b['exteriorWhite']:.3f}",fill='black')
   index.append({'page':pn,'span':j,'body':k,'bodyBounds':b['bounds'],'sourcePanelBounds':list(box),'sourceRaster':str(fp),'sourceSHA256':hashlib.sha256(fp.read_bytes()).hexdigest(),'witness':b})
 canv.save(out/f'p{pn}-bodies.png')
(out/'body-index.json').write_text(json.dumps(index,indent=2)+'\n')
