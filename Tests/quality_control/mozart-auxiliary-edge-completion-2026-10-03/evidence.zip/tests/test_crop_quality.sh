#!/bin/bash
set -euo pipefail
cd /Users/will/Documents/git/partsmith
mkdir -p .build/ModuleCache
export DEVELOPER_DIR="${DEVELOPER_DIR:-/Applications/Xcode.app/Contents/Developer}"
xcrun swiftc -O -module-cache-path .build/ModuleCache \
  .build/mozart-auxiliary-review-2026-10-03/edge-completion/candidate/Core/Detection/StaffBandDetector.swift \
  .build/mozart-auxiliary-review-2026-10-03/edge-completion/candidate/Core/Detection/ScoreExtractionPlanner.swift \
  .build/mozart-auxiliary-review-2026-10-03/edge-completion/candidate/Core/Detection/ScoreSharedEnding.swift \
  .build/mozart-auxiliary-review-2026-10-03/edge-completion/candidate/Core/Detection/ScoreSharedEndingDetector.swift \
  .build/mozart-auxiliary-review-2026-10-03/edge-completion/candidate/Core/Detection/ScoreLocalEndingPreservation.swift \
  .build/mozart-auxiliary-review-2026-10-03/edge-completion/candidate/Core/Detection/NativeScorePageAnalyzer.swift \
  .build/mozart-auxiliary-review-2026-10-03/edge-completion/tests/test_crop_quality.swift -o .build/mozart-auxiliary-review-2026-10-03/edge-completion/candidate/test_crop_quality
.build/mozart-auxiliary-review-2026-10-03/edge-completion/candidate/test_crop_quality "$@"
