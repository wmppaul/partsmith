import collections
import hashlib
import json
from pathlib import Path

root = Path('.build/brahms-envelope-compatibility-full-2026-10-03')
base_path = Path('.build/ownership-alternatives-2026-10-03/actual.json')
new_path = root / 'candidate.json'
old, new = (json.loads(p.read_text()) for p in (base_path, new_path))
op = {p['pageIndex']: p for p in old['pages']}
np = {p['pageIndex']: p for p in new['pages']}
assert op.keys() == np.keys() == set(range(39))
errors = []

def components(page):
    return collections.Counter(json.dumps(c, sort_keys=True) for c in page.get('inkComponents') or [])

page_changes = []
for i in op:
    a, b = op[i], np[i]
    if {k:v for k,v in a.items() if k != 'inkComponents'} != {k:v for k,v in b.items() if k != 'inkComponents'}:
        errors.append(dict(page=i+1, problem='Non-component source analysis changed'))
    ac, bc = components(a), components(b)
    if ac != bc:
        page_changes.append(dict(page=i+1, removed=sum((ac-bc).values()), added=sum((bc-ac).values())))

assert old['plan']['parts'] == new['plan']['parts']
assert len(old['plan']['pages']) == len(new['plan']['pages']) == 39
for a, b in zip(old['plan']['pages'], new['plan']['pages']):
    exclude = {'assignments','warnings'}
    if {k:v for k,v in a.items() if k not in exclude} != {k:v for k,v in b.items() if k not in exclude}:
        errors.append(dict(page=a['pageIndex']+1, problem='Page plan coverage or assignment state changed'))
    if [x['id'] for x in a['assignments']] != [x['id'] for x in b['assignments']]:
        errors.append(dict(page=a['pageIndex']+1, problem='Assignment count or order changed'))

def bands(inv):
    return {b['id']:b for p in inv['plan']['pages'] for b in p['assignments']}

ob, nb = bands(old), bands(new)
assert ob.keys() == nb.keys() and len(ob) == 604

def neighbors(b, page):
    return [s['id'] for s in page['staves'] if s['id'] not in b['candidateIDs']
            and b['topFraction'] <= s['staffLineFractions'][0]
            and b['bottomFraction'] >= s['staffLineFractions'][4]]

changes = []
for key, a in ob.items():
    b = nb[key]
    allowed = {'topFraction','bottomFraction','warnings'}
    if {k:v for k,v in a.items() if k not in allowed} != {k:v for k,v in b.items() if k not in allowed}:
        errors.append(dict(band=key, problem='Band identity, horizontal crop or assignment changed'))
    if any(a[k] != b[k] for k in ['topFraction','bottomFraction']):
        ph = op[a['pageIndex']]['pageHeight']
        changes.append(dict(band=key, page=a['pageIndex']+1,
            oldY=[a['topFraction']*ph,a['bottomFraction']*ph],
            newY=[b['topFraction']*ph,b['bottomFraction']*ph],
            oldWholeNeighbors=neighbors(a,op[a['pageIndex']]),
            newWholeNeighbors=neighbors(b,np[b['pageIndex']])))

out = dict(pages=39,bands=len(ob),errors=errors,changedComponentPages=page_changes,
    changedBands=changes,
    oldWholeNeighborIncidences=sum(len(neighbors(b,op[b['pageIndex']])) for b in ob.values()),
    newWholeNeighborIncidences=sum(len(neighbors(b,np[b['pageIndex']])) for b in nb.values()),
    hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (base_path,new_path)},
    scope='Source identity and geometry comparison only; crop contraction needs independent original-source evidence. No candidate PDF export or musical certification.')
(root/'comparison.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in {'changedBands','hashes'}},indent=2))
print('Changed crops:',len(changes))
if errors:
    raise SystemExit(1)
