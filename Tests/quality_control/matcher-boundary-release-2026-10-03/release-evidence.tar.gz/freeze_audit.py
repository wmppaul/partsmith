from pathlib import Path
import hashlib,json,tarfile
R=Path('.build/matcher-boundary-release-2026-10-03');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
roster=json.loads((R/'source-hashes.json').read_text());audit=json.loads((R/'private-package-audit.json').read_text());assert audit['status']=='pass'
assert all(sha(R/p)==h==sha(p)for p,h in roster.items())
files=[R/p for p in sorted(roster)]+[R/n for n in ['source-hashes.json','snapshot-receipt.json','freeze_sources.py','build.sh','build.log','package_and_audit.py','private-package-audit.json','load-commands.txt','freeze_audit.py']]
files += [R/x['path']for x in audit['compileLists']]
members=[]
with tarfile.open(R/'release-evidence.tar.gz','w:gz')as tar:
 for p in files:
  name=str(p.relative_to(R));tar.add(p,arcname=name);members.append({'path':name,'sha256':sha(p),'bytes':p.stat().st_size})
with tarfile.open(R/'release-evidence.tar.gz','r:gz')as tar:
 for row in members:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
(R/'archive-members.json').write_text(json.dumps(members,indent=2)+'\n')
manifest={'status':'private_package_verified_awaiting_root_publication_review','inputs':45,'swiftSources':35,'verifiedArchiveMembers':len(members),'files':{n:{'sha256':sha(R/n),'bytes':(R/n).stat().st_size}for n in ['release-evidence.tar.gz','archive-members.json','source-hashes.json','snapshot-receipt.json','private-package-audit.json','Partsmith-extraction-preview-macos.zip']},'publicZIPUnchangedSHA256':audit['priorPublicZIPSHA256'],'noAppLaunch':True}
(R/'private-release-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Private manifest SHA256:',sha(R/'private-release-manifest.json'));print('Evidence archive bytes:',(R/'release-evidence.tar.gz').stat().st_size);print('Verified archive members:',len(members))
