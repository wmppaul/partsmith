from pathlib import Path
import hashlib,json,shutil,subprocess
R=Path('.build/matcher-boundary-release-2026-10-03');P=Path('.build/divisi-assignment-release-v2-2026-10-03')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((P/'source-hashes.json').read_text());files=sorted(p for name in ('Partsmith','Partsmith.xcodeproj') for p in Path(name).rglob('*') if p.is_file())
assert set(map(str,files))==set(old),(len(files),len(old))
assert len(files)==45 and sum(p.suffix=='.swift'for p in files)==35
now={str(p):sha(p)for p in files};changed=[p for p in now if now[p]!=old[p]]
assert changed==['Partsmith/Core/Detection/ScoreSystemTemplateMatcher.swift'],changed
assert now[changed[0]]=='5e398baddf25d02d69daf269d533c745e39d1f1ad878627a65aa1966dad15cdb'
for p in files:
 target=R/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);assert sha(target)==now[str(p)]
assert all(sha(Path(p))==h for p,h in now.items())
public=Path('artifacts/macos/Partsmith-extraction-preview-macos.zip')
assert sha(public)==sha(P/'Partsmith-extraction-preview-macos.zip'),'Prior released ZIP no longer matches baseline snapshot'
(R/'source-hashes.json').write_text(json.dumps(now,indent=2)+'\n')
receipt={'sourcePaths':45,'swiftSources':35,'onlyChangedInputFromReleasedSnapshot':changed,'priorSnapshot':str(P),'priorSourceRosterSHA256':sha(P/'source-hashes.json'),'previousPublicZIPSHA256':sha(public),'snapshotAndCurrentSourceEqual':True,'gitHEAD':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'publishedZIPModified':False,'runningAppActions':'none'}
(R/'snapshot-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
