#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
r=.build/brahms-remaining-2026-10-03/ending-review
core=("$r"/Core/{DocumentModel,Detection,Layout,Export}/*.swift)
xcrun swiftc -O -module-cache-path .build/ModuleCache "${core[@]}" "$r/probe.swift" -o "$r/probe-raster"
"$r/probe-raster" .build/ownership-alternatives-output-2026-10-03/brahms-inventory.json Tests/quality_control/profiles/medium-skewed-06-brahms-string-quartet-no3-op67-imslp-93521.json > "$r/probe-raster.jsonl"
