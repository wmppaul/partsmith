#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
r=.build/brahms-remaining-2026-10-03/ending-review
c="$r/Core/Detection"
xcrun swiftc -O -module-cache-path .build/ModuleCache "$c/StaffBandDetector.swift" "$c/ScoreExtractionPlanner.swift" "$c/ScoreSharedEnding.swift" "$c/ScoreSharedEndingDetector.swift" "$c/ScoreLocalEndingPreservation.swift" "$r/ShapeDiagnosticNative.swift" "$r/controls297-diagnostic.swift" -o "$r/controls297-diagnostic"
"$r/controls297-diagnostic" "$r/control297-results.json" > "$r/control297-body-shapes.jsonl"
