from pathlib import Path
r=Path('.build/brahms-remaining-2026-10-03/ending-review')
s=Path('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift').read_text();old='if sawBody && completeBodies { return true }';assert s.count(old)==1
s=s.replace(old,'''if sawBody && completeBodies {
                                                Diagnostic.body(visited, width:width, space:staffSpace, side:side, row:row, thickness:headThickness, stroke:[stroke.left,stroke.right])
                                                return true
                                            }''')
(r/'ShapeDiagnosticNative.swift').write_text(s)
s=Path('Tests/quality_control/stem-ownership-2026-10-03/controls297.swift').read_text();s=s.replace('var pixels=[UInt8]', 'Diagnostic.label="\\(kind.rawValue):s\\(scale):t\\(tilt):b\\(bow)"\n            var pixels=[UInt8]')
s+='''
enum Diagnostic {
 static var label="unknown"
 static func body(_ visited:Set<Int>,width:Int,space:Double,side:Int,row:Int,thickness:Int,stroke:[Int]) {
  let xs=visited.map{$0%width},ys=visited.map{$0/width}
  guard let x0=xs.min(),let x1=xs.max(),let y0=ys.min(),let y1=ys.max() else {return}
  let rows=(y0...y1).map {y in [y,ys.filter{$0==y}.count]}
  let v:[String:Any]=["fixture":label,"area":visited.count,"bounds":[x0,y0,x1+1,y1+1],"rows":rows,"space":space,"side":side,"row":row,"thickness":thickness,"stroke":stroke]
  let d=try! JSONSerialization.data(withJSONObject:v,options:[.sortedKeys]);print(String(data:d,encoding:.utf8)!)
 }
}
'''
(r/'controls297-diagnostic.swift').write_text(s)
