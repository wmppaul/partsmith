#!/bin/bash
set -euo pipefail
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
r=.build/brahms-remaining-2026-10-03/ending-review
c="$r/Core/Detection"
xcrun swiftc -O -module-cache-path .build/ModuleCache "$c/StaffBandDetector.swift" "$c/ScoreExtractionPlanner.swift" "$c/ScoreSharedEnding.swift" "$c/ScoreSharedEndingDetector.swift" "$c/ScoreLocalEndingPreservation.swift" "$r/ShapeDiagnosticNative.swift" "$r/expanded336-diagnostic.swift" -o "$r/expanded336-diagnostic"
"$r/expanded336-diagnostic" "$r/control336-results.json" > "$r/control336-body-shapes.jsonl"
