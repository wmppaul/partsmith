import Foundation
import PDFKit
import ImageIO
import UniformTypeIdentifiers
import CryptoKit
struct Inventory: Decodable { var source:String;var sourceSHA256:String;var pages:[ScorePageAnalysis];var rectifications:[PageRectification] }
enum Diagnostic {
 static let root=URL(fileURLWithPath:".build/brahms-remaining-2026-10-03/ending-review")
 static func emit(_ value:[String:Any]) {let d=try! JSONSerialization.data(withJSONObject:value,options:[.sortedKeys]); print(String(data:d,encoding:.utf8)!);fflush(stdout)}
 static func save(_ mask:[Bool],width:Int,height:Int,name:String) {var d=Data("P5\n\(width) \(height)\n255\n".utf8);d.append(contentsOf:mask.map{$0 ? UInt8(0):UInt8(255)});try! d.write(to:root.appendingPathComponent(name+".pgm"))}
 static func witness(ink:[Bool],original:[Bool],width:Int,height:Int,stroke:[Int],row:Int,count:Int,side:Int,seedX:[Int],staffIndex:Int,space:Double) {
  func branches(_ mask:[Bool],side:Int)->[[String:Any]] {
   var seen=Set<Int>(),result:[[String:Any]]=[]
   let x=side<0 ? stroke[0]-1:stroke[1]
   for y in row..<(row+count) {
    let seed=y*width+x;guard mask[seed],!seen.contains(seed) else {continue}
    var q=[seed],next=0,minX=x,maxX=x,minY=y,maxY=y;seen.insert(seed)
    while next<q.count {
     let p=q[next];next+=1;let px=p%width,py=p/width
     minX=min(minX,px);maxX=max(maxX,px);minY=min(minY,py);maxY=max(maxY,py)
     for dy in -1...1 {for dx in -1...1 {
      let nx=px+dx,ny=py+dy
      guard nx>=0,nx<width,ny>=0,ny<height,nx<stroke[0] || nx>=stroke[1] else {continue}
      let j=ny*width+nx;if mask[j] && seen.insert(j).inserted {q.append(j)}
     }}
    }
    result.append(["bbox":[minX,minY,maxX+1,maxY+1],"area":q.count])
   }
   return result
  }
  emit(["event":"witness","stroke":stroke,"row":row,"count":count,"side":side,"seedX":seedX,"staffIndex":staffIndex,"space":space,
   "analysisLeft":branches(ink,side:-1),"analysisRight":branches(ink,side:1),"originalLeft":branches(original,side:-1),"originalRight":branches(original,side:1)])
  save(ink,width:width,height:height,name:"p38-witness-analysis");save(original,width:width,height:height,name:"p38-witness-original")
 }
}
@main enum Probe {
 static func main()throws {
  let args=CommandLine.arguments,enc=JSONEncoder();enc.outputFormatting=[.prettyPrinted,.sortedKeys]
  let inv=try JSONDecoder().decode(Inventory.self,from:Data(contentsOf:URL(fileURLWithPath:args[1])))
  let profile=try JSONDecoder().decode(ScoreExtractionProfile.self,from:Data(contentsOf:URL(fileURLWithPath:args[2])))
  let source=try Data(contentsOf:URL(fileURLWithPath:inv.source));precondition(SHA256.hash(data:source).map{String(format:"%02x",$0)}.joined()==inv.sourceSHA256)
  let page=inv.pages[37]
  let raster=URL(fileURLWithPath:".build/combined-preservation-2026-10-03/p38-diagnostic/rasters/page-38.png")
  let imageSource=CGImageSourceCreateWithURL(raster as CFURL,nil)!,image=CGImageSourceCreateImageAtIndex(imageSource,0,nil)!
  Diagnostic.emit(["event":"bound-raster","width":image.width,"height":image.height,"sha256":SHA256.hash(data:try Data(contentsOf:raster)).map{String(format:"%02x",$0)}.joined()])
  let dest=CGImageDestinationCreateWithURL(Diagnostic.root.appendingPathComponent("p38-native.png") as CFURL,UTType.png.identifier as CFString,1,nil)!;CGImageDestinationAddImage(dest,image,nil);precondition(CGImageDestinationFinalize(dest))
  let staffs=page.staves.map {StaffBandCandidate(id:$0.id,staffLineFractions:$0.staffLineFractions,topFraction:$0.topFraction,bottomFraction:$0.bottomFraction,confidence:$0.confidence,warnings:$0.warnings)}
  let start=Date();let cs=NativeScorePageAnalyzer.notationComponents(image:image,candidates:staffs,skewDegrees:page.analysisSkewDegrees)!
  func signatures(_ cs:[ScoreInkComponent])->[String] {cs.map{"\($0.staffIDs)|\($0.bounds)|\($0.isOwnershipAlternative == true)"}.sorted()}
  precondition(signatures(cs)==signatures(page.inkComponents!))
  Diagnostic.emit(["event":"native-result","componentCount":cs.count,"exactCurrentInventory":true,"seconds":Date().timeIntervalSince(start)])
  let selected=inv.pages.filter{[23,27,30,37].contains($0.pageIndex)}
  let baseline=ScoreExtractionPlanner.plan(pages:selected,profile:profile)
  try enc.encode(baseline).write(to:Diagnostic.root.appendingPathComponent("baseline-plan.json"))
  var edited=selected
  for n in edited.indices {
   let owners=edited[n].pageIndex==23 ? [6,7]:(edited[n].pageIndex==37 ? [2,3]:[0,1])
   edited[n].inkComponents!.removeAll{$0.staffIDs==owners}
  }
  let ablation=ScoreExtractionPlanner.plan(pages:edited,profile:profile)
  try enc.encode(ablation).write(to:Diagnostic.root.appendingPathComponent("diagnostic-remove-shared-component-plan.json"))
  Diagnostic.emit(["event":"ablation-only","pages":4,"bands":ablation.bands.count,"changedBands":zip(baseline.bands,ablation.bands).filter{$0 != $1}.map{$0.0.id}])
 }
}
