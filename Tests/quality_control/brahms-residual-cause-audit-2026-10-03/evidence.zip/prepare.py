from pathlib import Path
import json,hashlib,shutil
r=Path('.build/brahms-remaining-2026-10-03/ending-review'); core=Path('Partsmith/Core');shutil.copytree(core,r/'Core',dirs_exist_ok=True)
paths=[Path('.build/ownership-alternatives-output-2026-10-03/brahms-inventory.json'),Path('Tests/quality_control/brahms-reviewed-cleanup-2026-10-03/manual-proposals-v1.json'),Path('Tests/quality_control/brahms-reviewed-cleanup-2026-10-03/frozen-source-obligations.json'),Path('Tests/quality_control/residual7-source-2026-10-03/source-guards.json'),Path('sample_scores/medium_skewed/06_brahms_string_quartet_no3_op67_imslp_93521.pdf')]+sorted(core.rglob('*.swift'))
(r/'input-hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
p=r/'Core/Detection/NativeScorePageAnalyzer.swift';s=p.read_text();old='if sawBody && completeBodies { return true }';assert s.count(old)==1
s=s.replace(old,'''if sawBody && completeBodies {
                                                Diagnostic.witness(ink:ink, original:original, width:width, height:height,
                                                    stroke:[stroke.left,stroke.right], row:row, count:headThickness,
                                                    side:side, seedX:xs, staffIndex:staffIndex, space:staffSpace)
                                                return true
                                            }''')
p.write_text(s)
