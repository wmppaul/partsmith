from pathlib import Path
import json,hashlib,math
import numpy as np
from PIL import Image
r=Path('.build/p31-structural-gap-certificate-2026-10-03');legacy=Path('.build/system-boundary-evidence-2026-10-03/measure.py').read_text().split('\ncases=[]')[0];legacy=legacy.replace("ROOT=Path('.build/system-boundary-evidence-2026-10-03')",f"ROOT=Path('{r}')")
# Reuse immutable endpoint measurement; supply automatically observed candidate bounds.
legacy=legacy.replace('radius=round(space*.5);left=max(0,sx-radius);right=min(w,sx+radius+1)','radius=max(round(space*.5),case["gapProjectionRadius"]);left=max(0,sx-radius);right=min(w,sx+radius+1)')
ns={};exec(compile(legacy,'existing_endpoint_measurement','exec'),ns);measure=ns['measure'];groups=ns['groups'];runs=ns['runs'];results=[];discoveries=[];cases=json.load(open(r/'cases-before-results.json'))
for c in cases:
 assert hashlib.sha256(Path(c['image']).read_bytes()).hexdigest()==c['sourceSHA256']
 img=Image.open(c['image']).convert('L');a=np.asarray(img)<190;h,w=a.shape
 local=[]
 for k,(up,lo)in enumerate(zip(c['lines'],c['lines'][1:])):
  space=min((up[-1]-up[0])/4,(lo[-1]-lo[0])/4);y0=max(0,math.ceil(up[-1]+space*.5));y1=min(h,math.floor(lo[0]-space*.5))
  if y1<=y0:continue
  for component in groups(a[y0:y1,:]):
   if not any(y==0 for x,y in component)or not any(y==y1-y0-1 for x,y in component):continue
   xs=[x for x,y in component];center=(min(xs)+max(xs))//2;radius=max(center-min(xs),max(xs)-center)
   cid=f'{c["id"]}-pair{k}-{len(local)}';record={'id':cid,'image':c['image'],'lines':[up,lo],'spineX':center,'gapProjectionRadius':radius,'ownerMasks':c.get('ownerMasks',[]),'note':'Automatic source8-connected gap candidate; coordinate seed derived solely from original pixels, not page or edge location.'}
   sourceRows=[{'y':y+y0,'runs':runs(x for x,yy in component if yy==y)}for y in sorted({yy for x,yy in component})]
   discovered={'id':cid,'originalCaseID':c['id'],'owners':[k,k+1],'gapRows':[y0,y1],'gapSourceBounds':[min(xs),y0,max(xs)+1,y1],'originalPixelCount':len(component),'rowRuns':sourceRows,'originalSourceSHA256':c['sourceSHA256']};local.append(discovered);q=measure(record)
   families=q['staffFamilies'];endpoints=all(f['uniqueNumberedPhase']and f['commonEndpointCorridorComponentIDs']and f['exteriorPaperAtAllFiveLines']for f in families)
   attached=[u for u in q['unresolvedSourceInk']if u['sourceConnectedToCorridor']]
   missing=[{'staffID':k+t['staffID'],'lineNumber':t['lineNumber'],'hypothesisRow':t['measuredHypothesisRow'],'actualRidgeRuns':t['inwardRidgeRuns'],'connectedRidgeRuns':t['inwardRidgeRunsConnectedToSpine'],'connectedSupport':t['connectedRidgeSupport'],'exteriorPaperFraction':t['exteriorPaperFraction']}for t in q['numberedEndpointMeasurements']if t['connectedRidgeSupport']<.8 or not t['exteriorFullyImaged']or t['exteriorPaperFraction']!=1]
   obligation={'id':cid,'case':c['id'],'staffPair':[k,k+1],'sourceGapDiscovered':True,'bothContactedNumberedFamiliesAndEndpointsProven':bool(endpoints),'missingOrAmbiguousEndpointRoles':missing,'phaseAlternatives':[f['candidateShiftPhases']for f in families],'unresolvedAttachedGroups':attached,'unresolvedNearbyGroups':[u for u in q['unresolvedSourceInk']if not u['sourceConnectedToCorridor']],'pathCandidatePixelCount':sum(z['pixels']for z in q['observedSourceComponentsInCorridor']),'pathRole':'Candidate source transport only; these pixels are NOT automatically typed structural.','completeExclusiveBranchRoleAccount':False,'plannerContractionAllowed':False,'gateOutcome':'STOP: actual numbered endpoint paths are incomplete/ambiguous'if not endpoints else 'Endpoint identity only: source-path pixels still require complete exclusive role proof; no blanket corridor classification','evaluationOnlyAuthoredMusicalPixelsInCandidateCorridor':q.get('evaluationOnlyMusicalSourcePixelsInCorridor'),'oracleUsedToChooseRoles':False,'sourceOrGuardMutation':False}
   results.append(obligation)
 discoveries+=local
 print(c['id'],len(local),'automatic gap candidates',flush=True)
(r/'candidate-discovery.json').write_text(json.dumps(discoveries,indent=2)+'\n');(r/'certificates.json').write_text(json.dumps(results,indent=2)+'\n');(r/'summary.json').write_text(json.dumps({'originalCases':len(cases),'automaticGapCandidates':len(results),'bothContactedEndpointIdentityPasses':sum(z['bothContactedNumberedFamiliesAndEndpointsProven']for z in results),'completeStructuralCertificates':0,'plannerContractions':0,'negativeSourceFilesAndMasksUnchanged':all(hashlib.sha256(Path(c['image']).read_bytes()).hexdigest()==c['sourceSHA256']and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in c['ownerMaskHashes'].items())for c in cases),'notClaimed':'No end-to-end native ownership/crop regression run because no complete separation certificate was obtained. Original-scale source negative role checks only; not all transformed297/336controls.','decision':'Stop bounded trial; do not promote an incomplete path certificate or change planner crop.'},indent=2)+'\n')
