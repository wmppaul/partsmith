from pathlib import Path
from collections import deque,Counter
import numpy as np,json,hashlib,tarfile,shutil
from PIL import Image
r=Path('.build/p31-structural-gap-certificate-2026-10-03');out=Path('Tests/quality_control/p31-structural-gap-certificate-2026-10-03');out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
cases=json.load(open(r/'cases-before-results.json'));caseMap={c['id']:c for c in cases};certs=json.load(open(r/'certificates.json'));corrections=json.load(open(r/'metadata-correction.json'))['cases'] if (r/'metadata-correction.json').exists() else []
for q in certs:
 if not caseMap[q['case']].get('ownerMasks'):
  old=q.pop('evaluationOnlyAuthoredMusicalPixelsInCandidateCorridor',None);q['evaluationOnlyAuthoredMusicalPixelsInCandidateCorridor']=None
  p=r/'results'/f'{q["id"]}.json';m=json.load(open(p));removed={k:m.pop(k)for k in ['evaluationOnlyMusicalSourcePixelsInCorridor','evaluationOnlyMusicalSourcePixelsOutsideCorridor','ownerMasksUsedByEvidenceAlgorithm']if k in m};m['authoredMusicalMaskEvaluation']='Unavailable: no authored masks supplied for this source; zero must not be inferred.';write(p,m);
  if removed:corrections.append({'id':q['id'],'removedZeroValuedUnavailableOracleFields':removed})
write(r/'certificates.json',certs);write(r/'metadata-correction.json',{'reason':'Initial observer received empty ownerMasks lists and emitted0. Those counts were unavailable, not a measured absence of music. Corrected only evaluation metadata to null/absent; source measurements/decisions unchanged, no rerun.','cases':corrections})
# Bind exact known component from frozen source review, then recover its original-source closure.
j=json.load(open('Tests/quality_control/brahms-residual-source-separation-2026-10-03/shared-components.json'));p=next(p for p in j if p['page']==31);c=p['components'][0];x0,y0,x1,y1=c['nativeRect'];orig=np.asarray(Image.open(caseMap['p31-current-original']['image']).convert('L'))<190;separated=np.asarray(Image.open('.build/p31-spine-provenance-2026-10-03/p31-separated.pgm').convert('L'))<190
pool={(int(x+x0),int(y+y0))for y,x in zip(*np.where(separated[y0:y1,x0:x1]))};components=[]
while pool:
 seed=pool.pop();g={seed};q=deque([seed])
 while q:
  x,y=q.popleft()
  for dx in[-1,0,1]:
   for dy in[-1,0,1]:
    v=(x+dx,y+dy)
    if v in pool:pool.remove(v);g.add(v);q.append(v)
 components.append(g)
matching=[g for g in components if [min(x for x,y in g),min(y for x,y in g),max(x for x,y in g)+1,max(y for x,y in g)+1]==c['nativeRect']]
assert len(matching)==1;pts=matching[0];assert len(pts)==448 and all(orig[y,x]for x,y in pts)
seed=min(pts);seen={seed};q=deque([seed]);H,W=orig.shape
while q:
 x,y=q.popleft()
 for dx in[-1,0,1]:
  for dy in[-1,0,1]:
   nx,ny=x+dx,y+dy
   if 0<=nx<W and 0<=ny<H and orig[ny,nx]and(nx,ny)not in seen:seen.add((nx,ny));q.append((nx,ny))
assert pts<=seen
# Do not grant any numbered role without complete source path evidence.
def rowruns(points):
 out=[]
 for y in sorted({y for x,y in points}):
  rr=[]
  for x in sorted(x for x,yy in points if yy==y):
   if rr and x==rr[-1][1]:rr[-1][1]+=1
   else:rr.append([x,x+1])
  out.append({'y':y,'runs':rr})
 return out
closure={'reference':'Frozen causal component used to select the diagnostic record only; no page coordinates feed candidate discovery.','component':c,'processedPixels':len(pts),'processedSourceRows':rowruns(pts),'originalConnectedClosurePixels':len(seen),'additionalSourcePixelsPreviouslyRemovedByAnalysis':len(seen-pts),'originalConnectedClosureBounds':[min(x for x,y in seen),min(y for x,y in seen),max(x for x,y in seen)+1,max(y for x,y in seen)+1],'originalSourceRows':rowruns(seen),'sourceRole':'All remaining corridor/source-stub roles are unresolved; these rows authorize no erasure or ownership cut.'}
write(out/'p31-source-pixel-certificate-incomplete.json',closure)
focus=next(q for q in certs if q['id']=='p31-current-original-pair0-5');detail=json.load(open(r/'results'/f'{focus["id"]}.json'));write(out/'p31-endpoint-certificate-incomplete.json',{'certificate':focus,'numberedEndpointMeasurements':detail['numberedEndpointMeasurements'],'staffFamilies':detail['staffFamilies'],'sourceGapDiscovery':next(q for q in json.load(open(r/'candidate-discovery.json'))if q['id']==focus['id']),'decision':'No structural separation certificate; retain existing ownership/crop.'})
summary=json.load(open(r/'summary.json'));summary['status']='Bounded feasibility rejected; not a crop improvement or a validated classifier.';summary['p31OriginalConnectedClosurePixels']=len(seen);summary['negativeMaskLimitation']='11 existing boundary fixtures andp31 have no authored mask supplied here; their evaluation counts are null. All supplied masks preserved exactly. No pixel-loss pass is inferred from zero cuts.';summary['sourceObservationLimit']='Legacy horizontal ridge observer uses its unchanged<0.45space source-run registration filter. It is not a thinness-based spine classifier; no structural decision is made from width. A general complete branch classifier was not implemented because p31 fails the preceding physical source-role prerequisite.';write(out/'summary.json',summary)
write(out/'inputs.json',{'cases':cases,'productionNativeSHA256':sha('Partsmith/Core/Detection/NativeScorePageAnalyzer.swift'),'currentSourceReportManifestSHA256':sha('Tests/quality_control/brahms-residual-source-separation-2026-10-03/manifest.json'),'oldGuards':{p:sha('Tests/quality_control/brahms-residual-source-separation-2026-10-03/'+p)for p in ['immutable-ten-source-guards.json','immutable-thirteen-local-obligations.json','source-obligations-before-future-trials.json']},'legacyEndpointObserverSHA256':sha('.build/system-boundary-evidence-2026-10-03/measure.py')})
(out/'README.md').write_text('''# P31 structural-gap certificate: bounded feasibility rejection

No safe separation certificate was obtained. The production detector, planner, source PDF, target envelopes and delivered crops are unchanged. This is source evidence, **not a crop improvement or a passed preservation suite**.

The private measurement discovers crossing inter-staff components from actual original pixels. It does not use page coordinates, page-edge rank, component thinness or votes from other staves. The p31 target path was discovered at x1644–1648 over rows252–309. A certificate then requires both contacted staves’ ordered horizontal endpoints to reach that same original path, with every remaining branch explicitly accounted for.

P31 fails that prerequisite. At measured upper-line hypotheses201/215/229/243/256, connected inward support is1/42,0,0,0,0. Lower hypotheses325/339 provide0/42 and23/42; the remaining three lower lines do reach the path. Paper gaps separate the upper fragments from sustained numbered ridges. The source also has unresolved short attachments. Filling those gaps or borrowing other staves’ endpoints would assume the role that the certificate needs to prove. The exact448processed pixels and their complete original connected closure are recorded as runs, without assigning them a false structural role.

The bounded run measured38 unchanged original source files and264 automatically found gap paths. Fourteen paths have complete two-staff endpoint identity, including the clean-boundary control. This is not exclusive structural ownership: headAtJunction and an edgeMusicBroken interval also have such identity while retaining unaccounted musical attachments. True filled/hollow/tied shared heads, originalcase176, nearby heads, attached text/accidentals, and steep glissando/slur originals remain unchanged. Their supplied authored masks are evaluation-only. Cases without masks report unavailable, not zero musical pixels.

No planner contraction was attempted. No transformed297/336test suite, native ownership comparison, full39/36score replay or output regeneration was run. The complete exclusive branch classifier was not implemented after the source-role gate failed, and the provisional certificate explicitly remains incomplete. This avoids treating universal abstention as a successful algorithm test.

The source observer retains its existing horizontal-ridge registration method (including its original short vertical-run filter), but it makes no thinness-based structural decision. The p31 failure is actual missing source connectivity, not a relaxed88%core threshold. Original threshold190 means missing below that threshold; faint grayscale marks are not declared absent. The next step, if revisited, needs independently justified fragment/line identity and mixed-role source branches, rather than another numeric relaxation.

The archive preserves the exact38source/mask roster, protocol, discovery and endpoint/attachment records, source overlays, original run log, observer code and hashes. A metadata correction records that empty mask lists initially produced unavailable zero counts; those fields are now null/absent without changing any measurement or decision. The six displayed source/negative overlays were directly inspected after the run. All source files and guards were re-hashed unchanged.
''')
# Store all actual evidence, exact unchanged inputs once each, and the observer dependency.
files=[(p,'work/'+p.relative_to(r).as_posix())for p in sorted(r.rglob('*'))if p.is_file()];extra=[Path('.build/system-boundary-evidence-2026-10-03/measure.py'),Path('.build/p31-spine-provenance-2026-10-03/p31-separated.pgm')]
for c in cases:extra.append(Path(c['image']));extra.extend(Path(p)for p in c.get('ownerMasks',[]))
for p in sorted(set(extra)):files.append((p,'source-inputs/'+p.as_posix()))
archive=out/'source-role-evidence.tar.gz';members=[]
with tarfile.open(archive,'w:gz')as tar:
 for p,name in files:tar.add(p,arcname=name);members.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p)})
with tarfile.open(archive,'r:gz')as tar:
 for m in members:
  data=tar.extractfile(m['path']).read();assert len(data)==m['bytes']and hashlib.sha256(data).hexdigest()==m['sha256']
write(out/'archive-members.json',members);write(out/'manifest.json',{'status':'No complete separation certificate; no production/planner change.','verifiedArchiveMembers':len(members),'files':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in out.iterdir()if p.is_file()and p.name!='manifest.json'}})
print('originalclosure',len(seen),'additional',len(seen-pts));print(out,sha(out/'manifest.json'),len(members),archive.stat().st_size)
