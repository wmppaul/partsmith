from pathlib import Path
from collections import deque
import json, hashlib, math
import numpy as np
from PIL import Image, ImageDraw

ROOT=Path('.build/system-boundary-evidence-2026-10-03')
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def runs(values):
 values=sorted(int(v) for v in values); out=[]
 for x in values:
  if out and x==out[-1][-1]+1:out[-1].append(x)
  else:out.append([x])
 return [[r[0],r[-1]+1]for r in out]
def groups(mask):
 seen=np.zeros(mask.shape,bool); h,w=mask.shape; result=[]
 for y,x in zip(*np.where(mask)):
  if seen[y,x]:continue
  q=deque([(int(x),int(y))]);seen[y,x]=True;pts=[]
  while q:
   xx,yy=q.popleft();pts.append((xx,yy))
   for dy in [-1,0,1]:
    for dx in [-1,0,1]:
     nx,ny=xx+dx,yy+dy
     if 0<=nx<w and 0<=ny<h and mask[ny,nx] and not seen[ny,nx]:seen[ny,nx]=True;q.append((nx,ny))
  result.append(pts)
 return result

def measure(case):
 img=Image.open(case['image']).convert('L');a=np.array(img)<190;h,w=a.shape
 lines=case['lines']; space=float(np.median([(v[-1]-v[0])/4 for v in lines]));sx=case['spineX']
 radius=round(space*.5);left=max(0,sx-radius);right=min(w,sx+radius+1)
 y0=max(0,math.floor(lines[0][0]-2*space));y1=min(h,math.ceil(lines[-1][-1]+2*space))
 neighborhood=max(1,round(space*3));inner=(max(0,left-neighborhood),left);outer=(right,min(w,right+neighborhood))
 spine=np.zeros_like(a);spine[y0:y1,left:right]=a[y0:y1,left:right]
 connected=[];spineLabels=np.zeros(a.shape,np.int32)
 for g in groups(spine[y0:y1,left:right]):
  pts=[(x+left,y+y0)for x,y in g];xs,ys=zip(*pts)
  for xx,yy in pts:spineLabels[yy,xx]=len(connected)+1
  connected.append({'id':len(connected),'bounds':[min(xs),min(ys),max(xs)+1,max(ys)+1],'pixels':len(g),
   'staffCoreContacts':[i for i,ls in enumerate(lines)if any(ls[0]<=y<=ls[-1]for y in ys)]})
 missing=runs([y for y in range(y0,y1)if not a[y,left:right].any()]);multiple=[]
 for y in range(y0,y1):
  rr=runs(np.where(a[y,left:right])[0]+left)
  if len(rr)>1:multiple.append({'row':y,'runs':rr})
 # Thin source vertical runs. This is evidence only; pixels are never changed.
 thin=np.zeros_like(a)
 for x in range(inner[0],outer[1]):
  for lo,hi in runs(np.where(a[y0:y1,x])[0]+y0):
   if hi-lo < space*.45:thin[lo:hi,x]=True
 families=[];lineMask=np.zeros_like(a);lineRecords=[]
 for staff,ls in enumerate(lines):
  shifts=[];detailed={}
  for shift in range(-round(space*1.5),round(space*1.5)+1):
   fractions=[];rows=[]
   for line in ls:
    yy=round(line+shift);b=max(0,yy-1);e=min(h,yy+2)
    support=thin[b:e,inner[0]:inner[1]].any(axis=0)
    fractions.append(float(support.mean()) if len(support)else 0);rows.append(yy)
   detailed[shift]=fractions
   if min(fractions)>=.8:shifts.append(shift)
  phases=runs(shifts)
  best=max(detailed,key=lambda s:(min(detailed[s]),sum(detailed[s]),-abs(s)))
  chosen=min(shifts,key=lambda s:(-sum(detailed[s]),abs(s)))if shifts else best
  for number,line in enumerate(ls):
   yy=round(line+chosen);b=max(0,yy-1);e=min(h,yy+2)
   inwardXs=np.where(thin[b:e,inner[0]:inner[1]].any(axis=0))[0]+inner[0]
   # Record endpoint fragments as source runs, without bridging missing pixels.
   tipXs=np.where(a[b:e,inner[1]:right].any(axis=0))[0]+inner[1]
   exteriorXs=np.where(a[b:e,outer[0]:outer[1]].any(axis=0))[0]+outer[0]
   linked=np.zeros((e-b,right-inner[0]),bool);linkedByID={}
   for pts in groups(a[b:e,inner[0]:right]):
    ids={int(spineLabels[ry+b,rx+inner[0]])-1 for rx,ry in pts if spineLabels[ry+b,rx+inner[0]]>0}
    if ids:
     for rx,ry in pts:linked[ry,rx]=True
     for identity in ids:
      mask=linkedByID.setdefault(identity,np.zeros(linked.shape,bool))
      for rx,ry in pts:mask[ry,rx]=True
   linkedThin=(linked[:,:inner[1]-inner[0]] & thin[b:e,inner[0]:inner[1]]).any(axis=0)
   linkedXs=np.where(linkedThin)[0]+inner[0]
   endpointIDs=[{'corridorComponentID':identity,'connectedRidgeSupport':float((mask[:,:inner[1]-inner[0]]&thin[b:e,inner[0]:inner[1]]).any(axis=0).mean())}for identity,mask in sorted(linkedByID.items())]
   rec={'staffID':staff,'lineNumber':number,'nominalRow':line,'measuredHypothesisRow':yy,
    'endpointConnections':endpointIDs,'inwardSupport':detailed[chosen][number],'inwardRidgeRuns':runs(inwardXs),'inwardRidgeRunsConnectedToSpine':runs(linkedXs),'connectedRidgeSupport':float(linkedThin.mean()),'sourceTipRuns':runs(tipXs),
    'exteriorInkRuns':runs(exteriorXs),'exteriorPaperFraction':1-len(exteriorXs)/max(1,outer[1]-outer[0]),
    'exteriorFullyImaged':outer[1]-outer[0]==neighborhood}
   lineRecords.append(rec)
   if len(phases)==1:
    # Mask only actually witnessed thin ridge rows, not all proposed coordinates.
    lineMask[b:e,max(0,left-round(space*1.2)):min(w,right+round(space*1.2))] |= thin[b:e,max(0,left-round(space*1.2)):min(w,right+round(space*1.2))]
  sameEndpointIDs=set.intersection(*[{item['corridorComponentID']for item in rr['endpointConnections']if item['connectedRidgeSupport']>=.8}for rr in lineRecords[-5:]])
  family={'staffID':staff,'commonEndpointCorridorComponentIDs':sorted(sameEndpointIDs),'validTranslationHypotheses':[{'shift':s,'perLineSourceSupport':detailed[s]}for s in shifts],'candidateShiftPhases':phases,'allFiveObserved':bool(shifts),'uniqueNumberedPhase':len(phases)==1,
   'chosenShiftForMeasurement':chosen,'lineSupportFractions':detailed[chosen],
   'allFiveEndpointsConnected':all(r['connectedRidgeSupport']>=.8 for r in lineRecords[-5:]),
   'exteriorPaperAtAllFiveLines':all(r['exteriorPaperFraction']==1 and r['exteriorFullyImaged']for r in lineRecords[-5:])}
  families.append(family)
 # Every unaccounted side source pixel remains an unresolved attachment/context.
 reach=round(space*1.2);nx0=max(0,left-reach);nx1=min(w,right+reach)
 unknown=np.zeros_like(a);unknown[y0:y1,nx0:nx1]=a[y0:y1,nx0:nx1]
 unknown[spine|lineMask]=False
 unresolved=[]
 for pts0 in groups(unknown[y0:y1,nx0:nx1]):
  pts=[(x+nx0,y+y0)for x,y in pts0];xs,ys=zip(*pts)
  # Distinguish observed adjacency from merely nearby unknown source marks.
  attached=False
  for x,y in pts:
   if spine[max(0,y-1):min(h,y+2),max(0,x-1):min(w,x+2)].any():attached=True;break
  unresolved.append({'bounds':[min(xs),min(ys),max(xs)+1,max(ys)+1],'pixels':len(pts),'sourceConnectedToCorridor':attached,
    'classification':'unresolved attachment'if attached else 'unresolved nearby source ink'})
 donors=[f['staffID']for f in families if f['uniqueNumberedPhase'] and f['commonEndpointCorridorComponentIDs'] and f['exteriorPaperAtAllFiveLines']]
 targetComponents=[g['id']for g in connected if g['bounds'][1] <= lines[0][0]+space and g['bounds'][3] >= lines[0][0]-space]
 pathWitness=[g['id']for g in connected if g['id'] in targetComponents and sum(g['id'] in f['commonEndpointCorridorComponentIDs'] for f in families if f['staffID'] in donors)>=2]
 R={'id':case['id'],'sourcePath':str(case['image']),'sourceSHA256':sha(case['image']),'rasterSize':[w,h],
  'sourceNote':case.get('note','unchanged source fixture'),'sourceInkThreshold':190,'absenceLimit':'Absence here means no source pixel below190; faint grayscale source marks may remain. No exclusive structural ownership is inferred.','staffLines':lines,'staffSpace':space,'spineSeedX':sx,
  'sourceCorridor':[left,y0,right,y1],'inwardWindow':list(inner),'exteriorWindow':list(outer),
  'observedSourceComponentsInCorridor':connected,'missingSourceRows':missing,'multipleSourceRuns':multiple,
  'staffFamilies':families,'numberedEndpointMeasurements':lineRecords,'unresolvedSourceInk':unresolved,
  'healthyCommonEndpointStaffIDs':donors,'continuousPathComponentIDs':pathWitness,
  'upperCandidateSourceComponentIDs':targetComponents,'commonEndpointPatternSupported':len(donors)>=2,
  'endpointNumberingCaution':'Family labels follow supplied staff order; separate valid translation phases remain unresolved. No nearest-phase tie break grants evidence.',
  'boundaryIdentity':'supported by measured common endpoints and source path'if len(donors)>=2 and pathWitness else 'unresolved',
  'exclusiveStructure':'not asserted; boundary identity does not establish exclusive ink ownership',
  'cropOrSourceMutation':False}
 if 'derivativeAudit' in case:R['derivativeAudit']=case['derivativeAudit']
 if 'ownerMasks'in case:
  musical=np.zeros_like(a)
  for m in case['ownerMasks']:musical|=np.array(Image.open(m).convert('L'))<128
  R['evaluationOnlyMusicalSourcePixelsInCorridor']=int((musical&spine).sum())
  R['evaluationOnlyMusicalSourcePixelsOutsideCorridor']=int((musical&a&~spine).sum())
  R['ownerMasksUsedByEvidenceAlgorithm']=False
 base=np.array(img.convert('RGB'));base[spine]=[0,150,220];base[lineMask&~spine]=[0,150,60];base[unknown]=[210,0,140]
 ov=Image.fromarray(base);draw=ImageDraw.Draw(ov)
 for f in families:
  for y in lines[f['staffID']]:draw.line((inner[0],round(y+f['chosenShiftForMeasurement']),outer[1],round(y+f['chosenShiftForMeasurement'])),fill=(240,140,0),width=1)
 crop=(max(0,inner[0]-round(space*2)),y0,min(w,outer[1]+round(space)),y1)
 ov=ov.crop(crop);ov=ov.resize((ov.width*2,ov.height*2),Image.Resampling.NEAREST)
 ov.save(OUT/(case['id']+'-overlay.png'))
 R['overlayLegend']={'blue':'observed original source pixels in candidate corridor','green':'thin source ridge pixels in a unique measured five-line family','magenta':'unresolved attachment or nearby source ink','orange':'measured numbered-line hypotheses; no interpolated source pixels'}
 R['overlayOriginalPixelClip']=list(crop)
 (OUT/(case['id']+'.json')).write_text(json.dumps(R,indent=2)+'\n')
 return R

cases=[]
p=json.load(open('.build/ownership-alternatives-2026-10-03/actual.json'));page=next(x for x in p['pages']if x['pageIndex']==30)
cases.append({'id':'p31','image':'.build/p31-spine-provenance-2026-10-03/p31-original.pgm','spineX':1646,
 'lines':[[v*page['imageHeight']for v in s['staffLineFractions']]for s in page['staves'][:4]]})
for name in ['cleanBoundary','edgeMusicBroken']:
 cases.append({'id':name,'image':f'.build/stem-ownership-2026-10-03/fixtures/{name}.png','spineX':601,'lines':[[t+12*i for i in range(5)]for t in [180,330,480]]})
cases.append({'id':'case176-exact','image':'.build/brahms-numbered-lines-2026-10-03/candidate-v2/case176-source.pgm','spineX':601,'lines':[[t+12*i for i in range(5)]for t in [180,330,480]],'ownerMasks':['.build/brahms-numbered-lines-2026-10-03/candidate-v2/case176-middle-owner.pgm'],'note':'Exact frozen case176: scale1, tilt0, bow10. Source and middle-owner mask are unchanged from rejected numbered-line source evidence.'})
fixtureDir=Path('.build/brahms-numbered-lines-2026-10-03/candidate-v1/fourcore-sources')
lines=[[103,112,120,128,136],[178,186,194,202,210],[270,278,287,295,303],[344,352,361,369,377]]
for f in sorted(fixtureDir.glob('*.png')):
 if '-owner'in f.name:continue
 owners=[str(f.with_name(f.stem+f'-owner{i}.png'))for i in range(4)]
 cases.append({'id':'fourcore-'+f.stem,'image':str(f),'spineX':501,'lines':lines,'ownerMasks':owners})
 if f.stem in ['filledOuter-intact','hollowTiedOuter-intact']:
  # Clearly named NEW fixture; preserve every original authored musical pixel.
  a=np.array(Image.open(f).convert('L'));m=np.zeros(a.shape,bool)
  for op in owners:m|=np.array(Image.open(op).convert('L'))<128
  before=a.copy()
  for staff in lines:
   for y in staff:
    xs=np.arange(503,650);a[y,xs[~m[y,xs]]]=255
  assert np.array_equal(a[m],before[m])
  preserved=int(m.sum());removed=int(((a>=190)&(before<190)).sum())
  target=ROOT/(f.stem+'-common-endpoint-derived.png');Image.fromarray(a).save(target)
  cases.append({'id':'common-endpoint-'+f.stem,'image':str(target),'spineX':501,'lines':lines,'ownerMasks':owners,
   'derivativeAudit':{'allOriginalOwnedPixelsUnchanged':True,'originalOwnedPixelCount':preserved,'structuralPixelsRemoved':removed,'originalSourceSHA256':sha(f)},
   'note':'Separately named derivative removes only non-owned structural horizontal pixels beyond spine. Original fixture and every musical owner pixel unchanged.'})
(ROOT/'cases-before-measurement.json').write_text(json.dumps([{**c,'sourceSHA256':sha(c['image'])}for c in cases],indent=2)+'\n')
results=[measure(c)for c in cases]
summary=[{'id':r['id'],'boundaryIdentity':r['boundaryIdentity'],'donors':r['healthyCommonEndpointStaffIDs'],
 'sourcePath':r['continuousPathComponentIDs'],'unresolvedAttachmentCount':sum(g['sourceConnectedToCorridor']for g in r['unresolvedSourceInk']),
 'unresolvedNearbyGroups':sum(not g['sourceConnectedToCorridor']for g in r['unresolvedSourceInk']),
 'musicalCorridorPixels':r.get('evaluationOnlyMusicalSourcePixelsInCorridor'),'exclusiveStructure':r['exclusiveStructure']}for r in results]
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for r in summary:print(json.dumps(r))
