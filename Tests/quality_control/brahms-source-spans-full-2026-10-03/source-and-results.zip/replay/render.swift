import Foundation
import CoreGraphics
import PDFKit
import CryptoKit
import ImageIO
import UniformTypeIdentifiers
@main enum RenderFrozen {
    struct Inventory: Decodable { var source: String; var sourceSHA256: String; var pages: [ScorePageAnalysis]; var rectifications: [PageRectification] }
    static func main() throws {
        let a = CommandLine.arguments
        let input = try JSONDecoder().decode(Inventory.self, from: Data(contentsOf: URL(fileURLWithPath: a[1])))
        let data = try Data(contentsOf: URL(fileURLWithPath: input.source))
        precondition(SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() == input.sourceSHA256)
        let pdf = PDFDocument(data: data)!
        let cache = SourcePageRenderCache(pdfDocument: pdf, rasterScale: 2.5)
        let destination = URL(fileURLWithPath: a[2])
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        precondition(pdf.pageCount == 39 && input.pages.count == 39)
        for index in 0..<pdf.pageCount {
            try autoreleasepool {
                let page = pdf.page(at: index)!
                let correction = input.rectifications.first { $0.pageIndex == index }
                let image: CGImage
                if let correction {
                    guard let corrected = cache.rectifiedDisplayImage(for: index, rectification: correction) else { throw NSError(domain: "RenderFrozen", code: index, userInfo: [NSLocalizedDescriptionKey: "Corrected raster unavailable on page \(index + 1)"]) }
                    image = corrected
                } else { image = NativeScorePageAnalyzer.render(page)! }
                precondition(image.width == input.pages[index].imageWidth && image.height == input.pages[index].imageHeight)
                let url = destination.appendingPathComponent("page-\(index + 1).png")
                let out = CGImageDestinationCreateWithURL(url as CFURL, UTType.png.identifier as CFString, 1, nil)!
                CGImageDestinationAddImage(out, image, nil)
                precondition(CGImageDestinationFinalize(out))
                print("rendered \(index + 1)/39"); fflush(stdout)
            }
        }
    }
}
