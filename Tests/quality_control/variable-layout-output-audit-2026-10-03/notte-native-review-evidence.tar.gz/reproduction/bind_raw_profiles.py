from pathlib import Path
import json,hashlib,pymupdf as fitz
r=Path.cwd();out=r/'.build/variable-layout-output-audit-2026-10-03';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((r/'.build/monotone-line-corpus-2026-10-03/inputs.json').read_text())
ids=['normal-mozart-notte-e-giorno-don-giovanni-score','normal-schubert-erlkonig-d328-score','rest-detection-mozart-piano-concerto-no23-kv488-mvt1-mutopia2229','excerpt-mozart-k488-page-17'];results=[]
for n in ids:
 x=next(x for x in inputs if x['id']==n);source=Path(x['source']);profile=Path(x['profile']);assert h(source)==x['sourceSHA256'] and h(profile)==x['profileSHA256']
 # Same current-planner replan of immutable production 9f8 inventories.
 baseline=r/'.build/envelope-compatibility-corpus-2026-10-03/baseline'/f'{n}.json';d=json.loads(baseline.read_text());assert sum(len(p['assignments']) for p in d['plan']['pages'])==0
 results.append({'id':n,'source':str(source.relative_to(r)),'sourceSHA256':h(source),'profile':str(profile.relative_to(r)),'profileSHA256':h(profile),'sourcePages':len(d['pages']),'requiresSystemAssignment':json.loads(profile.read_text()).get('requiresSystemAssignment'),'productionInventoryCurrentPlannerBaseline':str(baseline.relative_to(r)),'baselineSHA256':h(baseline),'rawBands':0})
full=fitz.open(next(x['source'] for x in inputs if x['id']==ids[2]));excerpt=fitz.open(next(x['source'] for x in inputs if x['id']==ids[3]));a=full[16].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False);b=excerpt[0].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False);same=a.width==b.width and a.height==b.height and a.samples==b.samples
result={'focusProfiles':results,'k488ExcerptRelation':{'fullSourcePage':17,'excerptPage':1,'pixelIdentical144dpi':same,'fullPixelSHA256':hashlib.sha256(a.samples).hexdigest(),'excerptPixelSHA256':hashlib.sha256(b.samples).hexdigest(),'dimensions':[a.width,a.height]},'rawZeroTotal':19,'focusedProfiles':4,'independentCompleteScoresRepresented':3,'remainingProfilesNotAudited':15}
(out/'raw-profile-binding.json').write_text(json.dumps(result,indent=2)+'\n');print('K488 p17 excerpt pixel-identical',same)
