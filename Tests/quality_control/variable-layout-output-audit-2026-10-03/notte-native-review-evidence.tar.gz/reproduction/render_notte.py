import fitz,json,hashlib
from pathlib import Path
r=Path.cwd();out=r/'.build/variable-layout-output-audit-2026-10-03/notte'
files={'source':r/'sample_scores/normal/03_piano_vocal/mozart_notte_e_giorno_don_giovanni_score.pdf','voice':r/'output/pdf/full-score-sets/notte/Voice (Leporello).pdf','piano':r/'output/pdf/full-score-sets/notte/Piano.pdf'}
records=[]
for name,p in files.items():
 doc=fitz.open(p);ph=hashlib.sha256(p.read_bytes()).hexdigest()
 for i,pg in enumerate(doc):
  target=out/f'{name}-{i+1:03}.png';pg.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(target)
  records.append({'file':str(p.relative_to(r)),'fileSHA256':ph,'page':i+1,'pageBounds':list(pg.rect),'png':str(target.relative_to(r)),'pngSHA256':hashlib.sha256(target.read_bytes()).hexdigest()})
(out/'render-bindings.json').write_text(json.dumps(records,indent=2)+'\n')
print('Rendered',len(records),'pages from hash-bound current PDFs.')
