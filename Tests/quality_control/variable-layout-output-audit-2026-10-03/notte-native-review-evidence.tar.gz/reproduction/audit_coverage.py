from pathlib import Path
import json,hashlib,collections,zipfile
import pymupdf as fitz
root=Path.cwd();out=root/'.build/variable-layout-output-audit-2026-10-03'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def bind(p):return {'path':str(p.relative_to(root)),'sha256':h(p),'bytes':p.stat().st_size}
def load(p):return json.loads(p.read_text())
cases=[]
for name,folder,projectName,mapFile,sourcePath in [
('Notte e giorno','output/pdf/full-score-sets/notte','Notte e giorno.partsmithproject','output/pdf/full-score-sets/evidence/notte-map.json','sample_scores/normal/03_piano_vocal/mozart_notte_e_giorno_don_giovanni_score.pdf'),
('Erlkönig','output/pdf/auto-qc-2026-10-03/erlkonig-joined-rest-draft','Erlkonig-rest-layout.partsmithproject','output/pdf/auto-qc-2026-10-03/erlkonig-joined-rest-draft/source-reviewed-map.json','sample_scores/normal/03_piano_vocal/schubert_erlkonig_d328_score.pdf'),
('Mozart K488 first movement','output/pdf/auto-qc-2026-10-03/mozart-k488-variable-layout-draft','Mozart K488 — I. Allegro.partsmithproject','output/pdf/auto-qc-2026-10-03/mozart-k488-variable-layout-draft/source-reviewed-map.json','sample_scores/rest_detection/01_full_scores/mozart_piano_concerto_no23_kv488_mvt1_mutopia2229.pdf')]:
 b=root/folder;src=root/sourcePath;project=b/projectName;model=load(project/'project.json')['project'];m=load(root/mapFile);manifest=load(b/'manifest.json')
 assert h(src)==h(project/'source.pdf')==m['sourceSHA256']
 parts=[]
 for p in model['parts']:
  bands=[x for x in model['bands'] if x['partID']==p['id']];pdf=b/(p['name']+'.pdf')
  assert pdf.exists();doc=fitz.open(pdf)
  parts.append({'name':p['name'],'bands':len(bands),'generatedRestRecords':sum('generatedRest' in x for x in bands),'sourceMarkingCount':sum(len(x.get('sourceMarkings',[])) for x in bands),'pages':len(doc),'pdf':bind(pdf)})
 sourcePages=len(fitz.open(src));projectCheck=model['pageCount']==sourcePages;assert projectCheck
 deliveryResults={}
 if (b/'delivery-hashes.json').exists():
  dh=load(b/'delivery-hashes.json');fail=[k for k,v in dh.items() if not (b/k).is_file() or h(b/k)!=v];assert not fail
  deliveryResults={'file':bind(b/'delivery-hashes.json'),'verifiedEntries':len(dh),'mismatches':fail}
 else:
  rec=load(b/'review-record.json');assert rec['sourceSHA256']==h(src) and rec['manifestSHA256']==h(b/'manifest.json')
  for p in rec['parts']:assert p['sha256']==h(b/p['file'])
  deliveryResults={'file':bind(b/'review-record.json'),'sourceManifestAndBothPDFsVerified':True}
 systemCount=len(m.get('systems',[])) or sum(len(p['systems']) for p in m['pages'])
 case={'name':name,'deliveryDirectory':folder,'source':bind(src),'sourcePages':sourcePages,'reviewedSystemCount':systemCount,'modelSourcePageCountMatches':projectCheck,'sourceEmbeddedExact':True,'projectJSON':bind(project/'project.json'),'sourceMap':bind(root/mapFile),'manifest':bind(b/'manifest.json'),'parts':parts,'totalOutputPages':sum(x['pages'] for x in parts),'totalProjectBands':len(model['bands']),'deliveryVerification':deliveryResults}
 if name=='Notte e giorno':
  plan=load(b/'plan.json');assigned={x['id']:x for p in plan['pages'] for x in p['assignments']};guards=[]
  for p in m['pages']:
   height=841.89
   for s in p['systems']:
    for band in s['bands']:
     key=f"p{p['pageIndex']+1}-s{s['systemIndex']+1}-{band['partID']}";a=assigned[key]
     assert a['candidateIDs']==band['candidateIDs'] and a['kind']==band.get('kind','music')
     bounds=[0,a['topFraction']*height,595.28,a['bottomFraction']*height]
     for g in band.get('protectedRegions',[]):
      x0,y0,x1,y1=g['rect'];guards.append({'bandID':key,'protectedRect':g['rect'],'contained':x0>=bounds[0] and y0>=bounds[1] and x1<=bounds[2] and y1<=bounds[3]})
  assert len(assigned)==40 and len(guards)==40
  case.update({'nativeAssignmentRows':40,'printedMusicRows':38,'editorialCueRows':2,'generatedSilentRows':0,'reviewedPhysicalStaves':58,'coverage':'All 20 systems of provided four-page score; bars 1–73. First nine Voice bars are represented by labeled Piano source cues for 1–4 and 5–9, not generated rest notation.','sourceMapAssignmentCheck':'all 40 exact','unchangedProtectedRegions':guards,'currentAppCompatibility':bind(out/'notte/current-comparison.json'),'currentTemplateAid':'Two reviewed seeds plus eight suggestions cover 10/20; 10 abstain. Separate from this complete earlier reviewed assignment/export.'})
 elif name=='Erlkönig':
  sys=m['systems'];assert len(sys)==48
  assert sys[0]['firstBar']==1 and all(a['firstBar']+a['barCount']==b['firstBar'] for a,b in zip(sys,sys[1:])) and sys[-1]['firstBar']+sys[-1]['barCount']-1==148
  placements=load(b/'placements.json');refs=[v for p in placements for r in p['rows'] for v in r['sourceBandIDs']];assert collections.Counter(refs)==collections.Counter(x['id'] for x in model['bands'])
  assert sorted(len([x for x in model['bands'] if x['partID']==p['id']]) for p in model['parts'])==[48,48]
  case.update({'measureSpan':[1,148],'sourceMapTimelineContiguous':True,'sourceReferencesPreservedExactlyOnce':96,'printedMusicRows':92,'generatedRestRecords':4,'renderedRestRows':1,'openingSilentMeasures':12,'coverage':'All 48 systems of provided 11-page source; joined 12-bar opening Voice rest and editorial [4/4]. Manual identity, measure counts, crop corrections and directions retained.','currentTemplateAid':'Two source-reviewed seeds plus 46 suggestions cover all 48 systems, but absent-part durations were separately supplied. Template-only exports retain known hairpin/direction defects; this delivery includes manual corrections.'})
 else:
  sys=m['systems'];assert len(sys)==78 and sys[0]['firstBar']==1 and all(a['firstBar']+a['barCount']==b['firstBar'] for a,b in zip(sys,sys[1:])) and sys[-1]['firstBar']+sys[-1]['barCount']-1==314
  plan=load(b/'plan.json');assigned=[x for p in plan['pages'] for x in p['assignments']];lookup={(x['pageIndex']+1,x['systemIndex']+1,x['partID']):x for x in assigned}
  partids=[p['id'] for p in plan['parts']];checks=0
  for s in sys:
   roster={p['partID']:p['candidateIDs'] for p in s['instrumentAssignments']}
   for pid in partids:
    a=lookup[(s['page'],s['system'],pid)];assert a['startBarNumber']==s['firstBar'] and a['barCount']==s['barCount']
    assert a['candidateIDs']==roster.get(pid,[])
    assert a['kind']==('music' if pid in roster else 'generated-rest')
    checks+=1
  case.update({'measureSpan':[1,314],'sourceMapTimelineContiguous':True,'reviewedSourceAssignmentAndCountChecks':checks,'printedMusicRows':603,'generatedRestRecords':99,'sourceDirectionCopies':180,'coverage':'All 78 systems for all nine printed parts in provided 36-page first movement. Shared wind staves and Cello/Bass remain combined as printed.','currentTemplateAid':'Full assignment supplied by reviewed map/overrides, not a demonstrated template matching completion. The raw corpus also has a separate one-page K488 excerpt; do not double-count it as another complete score.'})
 cases.append(case)
(out/'coverage-ledger.json').write_text(json.dumps({'scope':'Three complete score workflows corresponding to four of nineteen zero-band raw profiles; other fifteen profiles not newly audited.','cases':cases},indent=2)+'\n')
print([(x['name'],x['sourcePages'],x['reviewedSystemCount'],x['totalProjectBands'],x['totalOutputPages']) for x in cases])
print('Notte guards',sum(x['contained'] for x in cases[0]['unchangedProtectedRegions']),'/40')
