import AppKit
import Foundation
import PDFKit

private struct Envelope: Codable { var project: ProjectData }
@main enum ReexportNotte {
  static func main() throws {
    let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
    let bundle = root.appendingPathComponent("output/pdf/full-score-sets/notte/Notte e giorno.partsmithproject")
    let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
    let project = try decoder.decode(Envelope.self, from: Data(contentsOf: bundle.appendingPathComponent("project.json"))).project
    let source = try Data(contentsOf: bundle.appendingPathComponent("source.pdf"))
    let document = PartsmithDocument(project: project, sourcePDFData: source)
    precondition(document.project == project && document.pdfDocument?.pageCount == 4)
    let out = root.appendingPathComponent(".build/variable-layout-output-audit-2026-10-03/notte/current-export")
    try FileManager.default.createDirectory(at: out, withIntermediateDirectories: true)
    var parts: [[String: Any]] = []
    for part in project.parts {
      let result = try PartPDFExporter.renderResult(for: part.id, project: document.project, sourcePDFData: source)
      try result.data.write(to: out.appendingPathComponent(part.name+".pdf"))
      var placements: [[String: Any]] = []
      for (pageIndex,page) in result.renderPlan.pages.enumerated() {
        for p in page.placements {
          func rect(_ r: CGRect) -> [Double] {[r.minX,r.minY,r.maxX,r.maxY]}
          placements.append(["bandID":p.bandID.uuidString,"sourcePage":p.sourcePageIndex+1,"outputPage":pageIndex+1,"sourceRectBottomUp":rect(p.sourceRect),"destinationRectBottomUp":rect(p.destinationRect),"sourceBandIDs":p.sourceBandIDs.map(\.uuidString)])
        }
      }
      parts.append(["name":part.name,"partID":part.id.uuidString,"file":part.name+".pdf","outputPages":result.renderPlan.pages.count,"placements":placements])
    }
    let summary: [String:Any] = ["method":"Actual current model codec, PartsmithDocument initialization and PartPDFExporter; no staff analysis, reassignment or delivered-file changes.","sourcePages":document.pdfDocument!.pageCount,"projectBands":project.bands.count,"projectUnchangedAfterExport":document.project==project,"parts":parts]
    try JSONSerialization.data(withJSONObject:summary, options:[.prettyPrinted,.sortedKeys]).write(to:out.appendingPathComponent("summary.json"))
    print("Current Notte decode/document/export complete: \(project.bands.count) bands, \(parts.count) parts")
  }
}
