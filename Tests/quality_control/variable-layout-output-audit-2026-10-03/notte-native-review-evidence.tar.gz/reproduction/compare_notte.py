import pymupdf as fitz,json,hashlib,numpy as np
from pathlib import Path
root=Path.cwd();base=root/'.build/variable-layout-output-audit-2026-10-03/notte';current=base/'current-export';old=root/'output/pdf/full-score-sets/notte'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((current/'summary.json').read_text());oldm=json.loads((old/'manifest.json').read_text());project=json.loads((old/'Notte e giorno.partsmithproject/project.json').read_text())['project'];source=fitz.open(old/'Notte e giorno.partsmithproject/source.pdf')
rows=[];pages=[]
for part in s['parts']:
 prev=next(x for x in oldm['parts'] if x['name']==part['name']); assert len(part['placements'])==len(prev['placements'])==20
 a=fitz.open(old/prev['file']);b=fitz.open(current/part['file']);assert len(a)==len(b)
 for i,(ap,bp) in enumerate(zip(a,b)):
  x=ap.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False);y=bp.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
  same=x.width==y.width and x.height==y.height and x.samples==y.samples
  p=current/(('voice' if part['name'].startswith('Voice') else 'piano')+f'-{i+1:03}.png');y.save(p)
  diff=int(np.count_nonzero(np.any(np.frombuffer(x.samples,np.uint8).reshape(-1,3)!=np.frombuffer(y.samples,np.uint8).reshape(-1,3),axis=1))) if (x.width,x.height)==(y.width,y.height) else None
  pages.append({'part':part['name'],'page':i+1,'pixelIdentical144dpi':same,'changedPixels':diff,'previousPDFSHA256':h(old/prev['file']),'currentPDFSHA256':h(current/part['file']),'currentRender':str(p.relative_to(root)),'currentRenderSHA256':h(p)})
 for oldrow,newrow in zip(prev['placements'],part['placements']):
  assert oldrow['sourcePage']==newrow['sourcePage']
  page=source[newrow['sourcePage']-1]; rawBox=source.xref_get_key(page.xref, 'MediaBox')[1]; boxValues=[float(x) for x in rawBox.strip('[]').split()]; sh=boxValues[3]-boxValues[1]
  x0,y0,x1,y1=newrow['sourceRectBottomUp']; sr=[x0,sh-y1,x1,sh-y0]
  dh=b[newrow['outputPage']-1].rect.height;x0,y0,x1,y1=newrow['destinationRectBottomUp'];dr=[x0,dh-y1,x1,dh-y0]
  rows.append({'bandID':oldrow['id'],'sourcePage':oldrow['sourcePage'],'oldSourceRect':oldrow['sourceRect'],'currentSourceRect':sr,'sourceDeltaMax':max(abs(x-y) for x,y in zip(oldrow['sourceRect'],sr)),'oldDestinationRect':oldrow['destinationRect'],'currentDestinationRect':dr,'destinationDeltaMax':max(abs(x-y) for x,y in zip(oldrow['destinationRect'],dr)),'oldOutputPage':oldrow['outputPage'],'currentOutputPage':newrow['outputPage']})
result={'scope':'Current codec/document/layout/export compatibility, no staff reanalysis. Pixel comparison refers to actual whole PDF pages at 144 dpi.','rows':rows,'pages':pages,'allSourceRectsEquivalentWithin1e-6':all(r['sourceDeltaMax']<1e-6 for r in rows),'allPagePixelsIdentical':all(p['pixelIdentical144dpi'] for p in pages),'projectUnchanged':s['projectUnchangedAfterExport']}
(base/'current-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('rows','pages')},indent=2));print([(p['part'],p['page'],p['changedPixels']) for p in pages]);print('max destination delta',max(r['destinationDeltaMax'] for r in rows))
