import pathlib,json,hashlib,pymupdf as f
from PIL import Image,ImageDraw
w=pathlib.Path('.build/parzen-template-probe-2026-10-03');out=w/'candidate-v3/source-review';out.mkdir(exist_ok=True)
e=json.load(open(w/'candidate-v3/results.json.events.json'));eb=json.load(open(w/'observer/results.json.events.json'));s={(x['pageIndex']+1,x['id']):x for x in e if x['kind']=='staff'};a={(x['pageIndex']+1,x['id']):x for x in e if x['kind']in ['anchoredStaff','anchorAbstention']};d=f.open(json.load(open(w/'input.json'))[0]['sourcePath']);res=json.load(open(w/'candidate-v3/results.json'))[0];base=json.load(open(w/'baseline-results.json'))[0];newpages={z['pageIndex']+1 for z in res['suggestions']}-{z['pageIndex']+1 for z in base['suggestions']};cases=[(2,9),(3,9),(4,9),(8,9),(4,7),(16,7),(4,10),(7,10)]
for z in eb:
 if z['kind']=='comparison'and z['pageIndex']+1 in newpages:
  for i,v in zip(z['candidateIDs'],z['scores']):
   if v<.48:
    for pair in [(z['templatePageIndex']+1,i),(z['pageIndex']+1,i)]:
     if pair not in cases:cases.append(pair)
index=[];images=[]
for p,i in cases:
 q=s[p,i];ar=a[p,i];sp=q['space'];top=q['lines'][0];rx=d[p-1].rect.width/q['imageWidth'];ry=d[p-1].rect.height/q['imageHeight'];starts=[q['start'],ar.get('patchStart',q['start'])];phases=[0,ar.get('localPhase',0)];colors=['red','green'];names=['production','v3'];shift=q['slope']*(min(starts)-q['imageWidth']/2);rect=[(min(starts)-2*sp)*rx,(top-2.8*sp+shift)*ry,(max(starts)+7*sp)*rx,(top+7*sp+shift)*ry];pix=d[p-1].get_pixmap(matrix=f.Matrix(6,6),clip=f.Rect(rect));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);draw=ImageDraw.Draw(im)
 for name,x,phase,col in zip(names,starts,phases,colors):
  corners=[]
  for nx,ny in [(x+.35*sp,top-2*sp+phase),(x+3.725*sp,top-2*sp+phase),(x+3.725*sp,top+5.875*sp+phase),(x+.35*sp,top+5.875*sp+phase)]:corners.append((nx*rx*6-pix.x,(ny+q['slope']*(nx-q['imageWidth']/2))*ry*6-pix.y))
  draw.line(corners+[corners[0]],fill=col,width=2)
 can=Image.new('RGB',(im.width+232,max(im.height,270)+80),'white');can.paste(im,(0,80));dr=ImageDraw.Draw(can);dr.text((5,5),f'p{p}, staff {i}: production {q["start"]}; v3 {ar.get("patchStart","abstain")}; phase {ar.get("localPhase","-")}',fill='black');dr.text((5,23),f'Candidate bands {ar["candidateBands"]}; selected {ar.get("sourceBand","none")}',fill='black');dr.text((5,41),'Red production; green v3. Original source at 432 dpi.',fill='black')
 for n,(name,bits) in enumerate(zip(names,[q['patch'],ar.get('patch',q['patch'])])):
  patch=Image.new('L',(28,64));patch.putdata([0 if z else 255 for z in bits]);patch=patch.resize((112,256));can.paste(patch,(im.width+3+115*n,100));dr.text((im.width+3+115*n,83),name,fill=colors[n])
 path=out/f'p{p}-staff{i}.png';can.save(path);images.append(can);index.append({'page':p,'staffID':i,'sourceClipPDFPoints':rect,'image':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sourceNativeDimensions':[q['imageWidth'],q['imageHeight']],'productionStart':q['start'],'v3Evidence':{k:v for k,v in ar.items()if k!='patch'}})
for j in range(0,len(images),4):
 ims=images[j:j+4];ww=max(im.width for im in ims);hh=max(im.height for im in ims);can=Image.new('RGB',(ww*2,hh*2),'#ccc')
 for k,im in enumerate(ims):can.paste(im,((k%2)*ww,(k//2)*hh))
 can.save(out/f'contact-{j//4+1:02}.png')
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n');print(len(cases),'source cases;',len(range(0,len(images),4)),'sheets')
