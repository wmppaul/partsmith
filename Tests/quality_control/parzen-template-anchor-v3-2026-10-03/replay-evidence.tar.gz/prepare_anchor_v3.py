from pathlib import Path
import json,hashlib,shutil,difflib
w=Path('.build/parzen-template-probe-2026-10-03');v2=w/'candidate-v2';v3=w/'candidate-v3';v3.mkdir(exist_ok=True);shutil.copytree(v2/'Core',v3/'Core',dirs_exist_ok=True);shutil.copy2(v2/'run.swift',v3/'run.swift');p=v3/'Core/Detection/ScoreSystemTemplateMatcher.swift';s=p.read_text()
s=s.replace('        var patch: [Bool]\n','        var patch: [Bool]\n        var boundaryPatchProven = false\n')
s=s.replace('                    let scores = zip(template.group.staves, group.staves).map { similarity($0.patch, $1.patch) }','''                    let pairs = Array(zip(template.group.staves, group.staves))
                    guard pairs.allSatisfy({ $0.boundaryPatchProven == $1.boundaryPatchProven }) else {
                        MatcherProbe.record(["kind":"incomparableOrigins","pageIndex":page.pageIndex,"systemIndex":group.systemIndex,"templatePageIndex":template.pageIndex,"pairs":pairs.map { ["templateID":$0.id,"targetID":$1.id,"templateBoundaryProven":$0.boundaryPatchProven,"targetBoundaryProven":$1.boundaryPatchProven] as [String:Any] }])
                        continue
                    }
                    let scores = pairs.map { similarity($0.patch, $1.patch) }''')
s=s.replace('    // Private v2: a vertical connection is only a clef origin when all five\n    // actual horizontal staff ridges begin there. Distinct source paths are not averaged.','''    // Private v3: retain the entire observed vertical boundary band. Its left
    // side establishes horizontal line endpoints/exterior, its right side locates
    // the clef patch. Separate non-overlapping structures are never averaged.''')
s=s.replace('        var anchors = [[Int]](repeating: [], count: members.count)','        var anchors = [[ClosedRange<Int>]](repeating: [], count: members.count)')
s=s.replace('            let edges=clusters.compactMap(\\.last);anchors[i-1]+=edges;anchors[i]+=edges','            let bands=clusters.compactMap { q -> ClosedRange<Int>? in guard let a=q.first,let b=q.last else{return nil};return a...b };anchors[i-1]+=bands;anchors[i]+=bands')
s=s.replace('            var choices=[(x:Int,phase:Int,support:Double,start:Int)]()\n            for anchor in Set(anchors[i]).sorted() {','''            var merged=[ClosedRange<Int>]()
            for band in anchors[i].sorted(by: { ($0.lowerBound,$0.upperBound)<($1.lowerBound,$1.upperBound) }) {
                if let last=merged.last,band.lowerBound<=last.upperBound {
                    merged[merged.count-1]=last.lowerBound...max(last.upperBound,band.upperBound)
                } else {merged.append(band)}
            }
            var choices=[(band:ClosedRange<Int>,phase:Int,support:Double,start:Int)]()
            for band in merged {
                let anchor=band.upperBound''')
s=s.replace('guard anchor-runLength>=0,anchor+runLength<raster.width','guard band.lowerBound-runLength>=0,anchor+runLength<raster.width')
s=s.replace('guard let begin,abs(begin-anchor)<=reach else {continue}','guard let begin,(band.lowerBound-reach...band.upperBound+reach).contains(begin) else {continue}')
s=s.replace('let leftRange=(anchor-runLength)...(anchor-reach-1)','let leftRange=(band.lowerBound-runLength)...(band.lowerBound-reach-1)')
s=s.replace('choices.append((anchor,best.phase,best.support,best.start))','choices.append((band,best.phase,best.support,best.start))')
s=s.replace('            // Pick one observed source path. A rightmost valid edge lies inside\n            // the bounded horizontal-line start corridor, never a late barline.\n            guard let choice=choices.max(by: {$0.x < $1.x}) else {\n                MatcherProbe.record(["kind":"anchorAbstention","pageIndex":pageIndex,"id":original.id,"candidateColumns":Set(anchors[i]).sorted()])','''            // Require one source boundary identity. Multiple independently
            // supported, disjoint paths are ambiguous and must abstain.
            guard choices.count == 1,let choice=choices.first else {
                MatcherProbe.record(["kind":"anchorAbstention","pageIndex":pageIndex,"id":original.id,"candidateBands":merged.map {[$0.lowerBound,$0.upperBound]},"supportedBandCount":choices.count])''')
s=s.replace('source.start=choice.x','source.start=choice.band.upperBound')
s=s.replace('var result=original;result.patch=clefPatch(staff:source,raster:raster,slope:slope)','var result=original;result.patch=clefPatch(staff:source,raster:raster,slope:slope);result.boundaryPatchProven=true')
s=s.replace('"patchStart":choice.x','"patchStart":choice.band.upperBound,"sourceBand":[choice.band.lowerBound,choice.band.upperBound]')
s=s.replace('"candidateColumns":Set(anchors[i]).sorted()','"candidateBands":merged.map {[$0.lowerBound,$0.upperBound]}')
p.write_text(s);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(v3/'protocol-before-results.json').write_text(json.dumps({'scope':'Private v3 full-source boundary-band clef anchoring. Same original24Parzen + historical32 once. No production modifications.','functionalChanges':['Retain complete contiguous qualifying vertical column intervals rather than isolated right edge. Unite only overlapping observations from adjacent pairs, not separated structures.','All v2 criteria/parameters unchanged. Horizontal start must intersect observed band plus existing reach; exterior interval lies left of entire band, right ridge samples and clef patch remain beyond right edge.','Require exactly one supported band per staff. Multiple disjoint supported structures abstain.','Explicit boundaryPatchProven provenance; compare only matching per-staff provenance (both source-proven or both original), otherwise abstain. No score maxima across alternative origins.'],'unchangedParameters':{'verticalWholeSupport':.94,'verticalGapSupport':.96,'maxMissingVerticalSpaces':.4,'lineToleranceSpaces':.15,'endpointReachSpaces':.65,'phaseSearchSpaces':2,'fiveRightSupport':.94,'rightRunSpaces':4,'exteriorMaximum':.25,'clefProposalThreshold':.48,'sourceSupportedThreshold':.72},'prospectiveRequirements':['Every proposal must match frozen source IDs/presentParts/actualstaffCounts.','No new proposals on old conservative negative expectations; compare all32 previous results, preserving known profile-count conflict.','Inspect actual p2 wrong-origin, p8 bracket, p16 thick-boundary patches and any newly suggested sources before proposing promotion.'],'matcherSHA256':sha(p),'v2MatcherSHA256':sha(v2/'Core/Detection/ScoreSystemTemplateMatcher.swift'),'inputSHA256':sha(w/'input.json'),'old32InputSHA256':sha(Path('Tests/quality_control/system-template-independent-2026-10-03/challenge-inputs.json'))},indent=2)+'\n')
(v3/'versus-v2.diff').write_text(''.join(difflib.unified_diff((v2/'Core/Detection/ScoreSystemTemplateMatcher.swift').read_text().splitlines(True),s.splitlines(True),fromfile='v2',tofile='v3')))
