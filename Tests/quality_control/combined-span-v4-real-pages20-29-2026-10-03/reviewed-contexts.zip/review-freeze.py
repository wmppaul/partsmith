from pathlib import Path
import hashlib,json,collections,shutil,zipfile
R=Path('.build/brahms-numbered-spans-v4-full-2026-10-03');W=R/'ending-review';D=Path('Tests/quality_control/combined-span-v4-real-pages20-29-2026-10-03');D.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((R/'comparison.json').read_text());idx={x['band']:x for x in json.loads((R/'context-index.json').read_text())};changes=[x for x in a['changedBands']if 20<=x['page']<=29]
notes=dict(line.split('\t',1)for line in (W/'notes.tsv').read_text().splitlines());assert len(notes)==65 and set(notes)=={x['band']for x in changes}
old=json.loads(Path('.build/ownership-alternatives-2026-10-03/actual.json').read_text());assert old['sourceSHA256']=='662aabfdecb2d125151c984fe1dc866ea068668ee9bb74f23f286f552603c14a'
assert sha(Path(old['source']))==old['sourceSHA256']
for p,h in a['hashes'].items():assert sha(Path(p))==h
rows=[];sourceHashes={}
for x in changes:
 band=x['band'];c=idx[band];raw=Path(f'.build/brahms-source-span-full-replay-2026-10-03/rasters/page-{x["page"]}.png');sourceHashes[str(raw)]=sha(raw)
 dt=x['newY'][0]-x['oldY'][0];db=x['newY'][1]-x['oldY'][1];shr=dt>1e-9 or db< -1e-9;exp=dt< -1e-9 or db>1e-9
 rows.append(dict(x,contextSHA256=sha(Path(c['path'])),sourceRasterSHA256=sha(raw),context=c,edgeChange='mixed'if shr and exp else'contracted'if shr else'expanded',visualVerdict='no_new_intended_notation_clipping_observed',scope='Visual review of this changed full-width crop context and both boundaries; not complete musical certification of the entire source part.',note=notes[band],unannotatedOriginalDetailAlsoViewed=(W/f'{band}-unannotated.png').is_file()))
summary={'physicalPages':[20,29],'changedBands':len(rows),'everyEnumeratedBandViewed':True,'newTargetClippingObserved':0,'unresolvedBoundaryOwnershipQuestions':0,'edgeChanges':dict(collections.Counter(x['edgeChange']for x in rows)),'perPageChangedBands':dict(collections.Counter(x['page']for x in rows)),'oldWholeNeighborIncidences':sum(len(x['oldWholeNeighbors'])for x in rows),'newWholeNeighborIncidences':sum(len(x['newWholeNeighbors'])for x in rows),'wholeNeighborClassRemoved':[x['band']for x in rows if set(x['oldWholeNeighbors'])-set(x['newWholeNeighbors'])],'wholeNeighborsRemaining':[x['band']for x in rows if x['newWholeNeighbors']],'candidateEligibility':'Still rejected by unchanged27 synthetic junction separation cases. This visual subset does not override that result.','limitations':'Remaining partial neighboring staves are conspicuous; no rendered-part/page-turn review or full604-band certification in this task.'}
bindings={'source':old['source'],'sourceSHA256':old['sourceSHA256'],'sourceRectifications':old['rectifications'],'analysisHashes':a['hashes'],'comparisonSHA256':sha(R/'comparison.json'),'contextIndexSHA256':sha(R/'context-index.json'),'sourceRasterHashes':sourceHashes,'nativeSHA256':'87e515434e671bc11f7c304342112401fcd0fc3d800015b8f93f7b29ab013487'}
for f,obj in [('per-band-review.json',rows),('summary.json',summary),('bindings.json',bindings)]: (D/f).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
shutil.copyfile(W/'notes.tsv',D/'notes.tsv')
files={'make-contexts.py':R/'make-contexts.py','review-freeze.py':W/'freeze.py'}
for x in rows:files[f'contexts/{x["band"]}.png']=Path(x['context']['path'])
for p in sorted(W.glob('*-unannotated.png')):files['unannotated/'+p.name]=p
m={n:sha(p)for n,p in sorted(files.items())};(D/'image-archive-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
with zipfile.ZipFile(D/'reviewed-contexts.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for n,p in files.items():z.write(p,n)
 z.write(D/'image-archive-manifest.json','manifest.json')
with zipfile.ZipFile(D/'reviewed-contexts.zip')as z:
 for n,h in m.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
(D/'README.md').write_text('''# Independent visual review: Brahms 93521, changed crops on pages 20–29

All **65 changed full-width crop contexts** were individually viewed against the original source notation. I observed **no newly clipped intended note or marking** at their changed edges. The subset contains 47 contractions, 14 expansions and four changes combining both. Larger changes on pages 24, 26, 28 and 29 were also inspected in six unannotated original-raster details.

This is diagnostic evidence for a rejected candidate, not approval. The combined numbered-line V2 / musical-span V4 candidate still fails all 27 fixed synthetic junction separation cases. That independent ownership failure is preserved in the [regression report](../combined-span-v4-independent-2026-10-03/README.md).

The intended notes, stems, beams, ledger lines, accidentals, articulations, ties/slurs, dynamics and hairpins visible in these changed contexts remain inside the proposed bands. `per-band-review.json` records a separate observation for every enumerated crop, its exact old/new bounds, source-image binding and context coordinates. All 65 supplied overlays were viewed; none is represented only by a sampled contact sheet.

Two full-neighbor classifications disappear: page 24 system 2 Viola and page 28 system 1 Violin II. Both still contain substantial partial neighboring notation. Page 24 system 2 Cello still contains the whole Viola core, and page 28 system 1 Violin I still contains the whole Violin II core. Thus whole-neighbor incidences in this subset drop from four to two, but this is not clean extraction.

Several expansions add neighboring notation with no visible target recovery in the inspected context: page 20 system 3 Violin I includes more lower slurs/staff; page 21 system 3 Cello and page 22 system 2 Cello include more high notes from the next system; page 28 system 3 Viola includes more Cello slur/staff. Small contractions generally reduce existing neighboring staff fragments. The larger page 26 system 1 Violin I contraction retains its low final sharp note, flags and upper ledger notes; page 28 system 2 Violin I retains its high ledger notes, slurs and repeat signs while removing previous-system fragments.

Source PDF SHA256 is `662aabfdecb2d125151c984fe1dc866ea068668ee9bb74f23f286f552603c14a`. Existing saved rectifications are recorded without change. Native candidate SHA256 is `87e515434e671bc11f7c304342112401fcd0fc3d800015b8f93f7b29ab013487`. `bindings.json` identifies the exact source raster for each physical page, baseline/candidate analyses and comparison. `reviewed-contexts.zip` preserves every viewed annotated context plus six unannotated original details; every archived payload hash was checked.

The overlays show old edges as red dashes and new edges in blue. They include 18 source points of context outside the union of the old/new bands and retain full page width; the presentation is capped at 1,440 pixels. The six additional original details are uncapped, unannotated source raster crops. Findings are visual observations, not an exhaustive source-pixel oracle or musical certification. Unchanged crops, other pages, shared-copy placement, final pagination and page turns were outside this review. Production, source guards, PDFs and projects remain unchanged.
''')
manifest={str(p.relative_to(D)):sha(p)for p in sorted(D.rglob('*'))if p.is_file()and p.name!='manifest.json'};(D/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n,h in manifest.items():assert sha(D/n)==h
print(json.dumps({'report':str(D),'summary':summary,'README_SHA256':sha(D/'README.md'),'manifest_SHA256':sha(D/'manifest.json'),'artifacts':len(manifest),'archivePayloads':len(m)},indent=2))
